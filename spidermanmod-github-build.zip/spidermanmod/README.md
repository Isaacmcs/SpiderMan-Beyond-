# Spider-Man: Beyond the Web  (modid `spidermanmod`)
Fan-made beta total-conversion mod for **Minecraft 1.20.1 / Forge 47.x / Java 17**.
Not affiliated with Marvel or Insomniac Games. Status: **written but not yet compiled/playtested** - expect to fix a few compile errors on first build.

## Build / run
1. Easiest: download the Forge 1.20.1 MDK (47.3.x), copy its `gradlew`, `gradlew.bat` and `gradle/` folder into this project, then:
   `./gradlew runClient`  (or `./gradlew build` -> `build/libs/spidermanmod-0.1.0-beta.jar`)
2. Or drop `src/` into the MDK and keep the MDK's own build.gradle.

## Controls / features
| What | How |
|---|---|
| **Mission board** | Press **J** (or choose it on the Outpost Radio). Story line after the origin: Thugs -> Rhino -> Electro -> Vulture -> Doctor Octopus -> Green Goblin -> Kingpin, plus 6 side jobs (thugs, chatting, buying lunch, swinging distance, altitude). Boss missions spawn the boss at its arena when you get within 80 blocks; the HUD shows direction + distance |
| **Villains** | Rhino (telegraphed charge; stuns himself on walls), Electro (lightning arcs, shock pulse, blink), Doctor Octopus (marked tentacle slams, grab), Vulture (dive-bombs, wing-gust), Green Goblin, Kingpin (slam; calls thugs at 75/50/25% HP). Street Thugs roam the city and pick on civilians. Test with `/spidey boss rhino|electro|vulture|octopus|goblin|kingpin` |
| **Money & food** | Money ($) comes from thug bounties, bosses and missions. Vendors (the civilians holding bread) sell Hot Dog, Pizza, Burger, Energy Bar and Coffee - right-click one. No farms in the city. HUD top-right shows $ and the Focus bar. `/spidey money add <n>` for testing |
| **Mobs** | Only this mod's mobs spawn (vanilla/other-mod spawns are blocked, doMobSpawning is switched off). Toggle `disableVanillaMobSpawning` in `config/spidermanmod-common.toml` |
| **More powers** | Upgrade menu (U) now has Movement + Abilities tabs. **Web Wings** (hold Jump while falling; look down to dive), **Focus** (earn by landing hits) powering hotkeys: **G** Focus Heal, **H** Venom Strike, **B** Camouflage, **N** Concussive Blast, **Y** Symbiote Surge (needs the full Symbiote Suit). Passives from the bite: strength, Hero Landing (fall from 6+ blocks = shockwave, no damage), dodge also slows nearby enemies |
| **Origin quest (start here)** | First time you enter the city dimension (`/spidey city`) the story starts. Break into Helix Research Center AFTER DARK (back service door; front is barred), sneak past guards, climb the ladder in the west wall down to the vault, right-click the **Specimen Case**. Alarm! Get 70+ blocks away, walk home to the spawn intersection - on the way something bites your neck. Sleep / wait for morning: you wake with **spider powers**. The top-left HUD tracks the objective with distance + compass direction |
| Spider powers | Wall Climb (unlocked free), Spider-Sense warnings (red action-bar alert when something hostile hunts you), hidden Speed I + Jump Boost I, 15% chance to dodge hits. Wall Run becomes purchasable (needs powers). Wall moves now require powers, not gadgets |
| Web swing | Hold **Web Shooter**, right-click at a block <= 40 blocks away. Right-click again or press **Jump** to release (jump gives a boost). |
| Point Launch | Sneak + right-click with the Web Shooter (needs the upgrade) |
| Web reel | While swinging, hold **Sneak** to shorten the rope and speed up. Releasing with Jump on the upswing gives a bigger launch |
| Web Pull | Hold the Web Shooter, aim at a mob/player, press **V**: yanks them toward you |
| Wall Climb | Needs upgrade + Web Shooter in hand or any suit piece. Sprint (or be airborne) and hold W into a wall: W up, S down, A/D strafe, idle = cling, Jump = leap off, ledge = auto-vault |
| Wall Run | Needs upgrade. Airborne + sprint + W beside a wall: run along it ~2.5 s per jump, Jump = wall-jump away. Camera leans |
| Impact Web | Right-click: knockback + temporary cobweb at the target's feet. Web Capacity upgrades shorten recharge |
| Upgrades menu | Press **U** (rebind in Controls). Earn Hero Tokens: +1 per hostile kill, +25 Green Goblin, +5 from Yuri's quest. Five upgrades: Point Launch, Air Combo, Web Capacity, Wall Climb, Wall Run |
| Dialogue | Use the **Chinatown Outpost Radio** -> Capt. Yuri Watanabe (accept / decline / query branches) |
| Green Goblin | Spawn egg or `/spidey goblin` (op). 300 HP, red boss bar, orbits 6 blocks up, bombs every 2.5 s |
| Weapons | **Web Bomb** (throw; 7 s cobweb ball + slow), **Electro-Web Gauntlets** (melee; right-click shock pulse stuns a forward cone), **Web Blade** (sword, hits slow) |
| Civilians | 16 skins and 5 roles (pedestrian, jogger, vendor who gives bread once, tourist, photographer who follows you and snaps pictures). Up to 30 around you in the city. Wander the city, flee monsters, chat when right-clicked (+1 token once each if you're "Spidey"). Auto-populate the city dimension; `/spidey civilians` or spawn egg elsewhere |
| Suits | Classic (Jump), Advanced (Speed), Symbiote (Strength + Resistance); effects need the full 4-piece set |
| City dimension | `/spidey city` (drops you from y=180 with Slow Falling), `/spidey home` to return |
| Origin testing | `/spidey origin start | skip | reset` (op). `skip` gives powers immediately; use `/time set night` to open the case in the day |
| Tokens (testing) | `/spidey tokens add <n>` (op) |

## Voice lines
`assets/spidermanmod/sounds/voice/*.ogg` are **placeholder beeps**. Replace them with your own mono .ogg files of the same names:
spidey_swing_woohoo / _fast / _joke, spidey_hurt_1 / _2, yuri_intro / _query / _accept / _decline.

## Known limitations (beta)
- Swing physics are client-side; **other players don't see your web line** (only you do).
- Dedicated servers: set `allow-flight=true` in server.properties or long swings can trigger the "flying" kick.
- Biome + dimension are data-driven JSON in 1.20.1 (not code-registered). The city is a flat dimension with a procedural street/building feature (`CityBlockFeature`).
- Suit Customizer is a locked placeholder; `CustomSuitData` already recolours suit item icons when written to a stack's NBT. Worn-armour textures are fixed per suit.
- Item/armour/goblin textures are generated placeholders (`gen_assets.py` ... `gen_assets4.py` in order regenerate them).
- Temporary cobwebs are not saved: a crash can leave a web behind.
- Wall climbing/running: if the camera lean feels backwards, flip the sign in `WallMovementEngine.stepRoll()`.
- Recipes exist for the gadgets, weapons and suits (suits = 4-piece armour shapes from red / white / black wool).
- Origin quest: guards (sneak range 4 blocks, normal 14, alerted 40) drop no tokens. Quest progress is stored per player and survives death. The research center is generated at chunk (6, 6) of the city dimension (blocks ~96..111).
- The Specimen Case block is unbreakable in survival and can be placed in creative (`specimen_case` item) for testing.
- Mob-spawn blocking cancels any NEW non-mod mob joining the world (including /summon and eggs); mobs already saved in an existing world stay. Turn it off in the config if you want vanilla mobs back.
- Boss arenas are street intersections at fixed chunks (see `Quests.java`). Bosses only appear while the matching mission is active.
- Villains reuse a humanoid model with generated placeholder skins.
