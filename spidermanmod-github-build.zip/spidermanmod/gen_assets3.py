"""Run AFTER gen_assets.py and gen_assets2.py. Update 3: origin quest, specimen case, guards, 16 civilian skins."""
import json, os, random
from PIL import Image, ImageDraw

RES = "src/main/resources"
A = f"{RES}/assets/spidermanmod"

def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

# ---------- lang ----------
lp = f"{A}/lang/en_us.json"
lang = json.load(open(lp))
lang.update({
    "block.spidermanmod.specimen_case": "Specimen Case",
    "entity.spidermanmod.security_guard": "Security Guard",
    "gui.spidermanmod.needs_powers": "Needs powers",
    "dialogue.spidermanmod.origin": "Origin",
    "hud.spidermanmod.origin.title": "ORIGIN",
    "hud.spidermanmod.origin.1": "Break into Helix Research Center AFTER DARK. Use the back service door, sneak past the guards, take the ladder down to the vault and open the specimen case.",
    "hud.spidermanmod.origin.2": "ALARM! Get away from the research center - at least 70 blocks!",
    "hud.spidermanmod.origin.3": "You made it out. Head home to the intersection at the city's spawn point.",
    "hud.spidermanmod.origin.4": "Rough night. Get some sleep (or just wait for the next morning).",
    "hud.spidermanmod.origin.go_to_city": "Travel to the city first: /spidey city",
    "origin.started": "You decide to break into Helix Research Center tonight. (Sneak: guards only notice you from 4 blocks away.)",
    "origin.case_idle": "A sealed case in the vault. Something small is moving inside... but you have no reason to open it yet.",
    "origin.case_empty": "The case is empty now.",
    "origin.case_locked": "The case is on a time lock and only releases after nightfall. Come back after dark.",
    "origin.case_opened": "The seal hisses open. Something tiny skitters out of the case and across the floor... then it's gone.",
    "origin.alarm": "Alarms start blaring all over the building!",
    "origin.escaped": "You've shaken them off. Time to head home.",
    "origin.powers": "Gained: Wall Climb, Spider-Sense warnings, enhanced agility and a chance to dodge attacks. Wall Run can now be bought in the upgrade menu (U).",
    "origin.title.alarm": "ALARM!",
    "origin.title.alarm.sub": "Run!",
    "origin.title.bite": "Ow!",
    "origin.title.bite.sub": "Something bit your neck...",
    "origin.title.awaken": "The Next Morning",
    "origin.title.awaken.sub": "Something has changed",
    "message.spidermanmod.spider_sense": "SPIDER-SENSE!",
    "message.spidermanmod.dodged": "Dodged!",
})
role_lines = {
    "jogger": ["Sorry, can't stop - personal best today!", "Fifth lap around the block. Don't ask.", "Fresh air, fast legs, no excuses!"],
    "vendor": ["Hot pretzels! Fresh bread! Get 'em while they're warm.", "Business has been slow since the sirens started.", "Take some bread, on the house."],
    "tourist": ["Is this where all the web-swinging happens?", "I got lost... again. Which way is the harbour?", "My map says there's a research center nearby."],
    "photographer": ["Hold still - I need this shot for the paper!", "Can you swing by that building again? The light's perfect.", "Freelance work is brutal. Hero photos pay rent."],
}
for role, lines in role_lines.items():
    for i, t in enumerate(lines):
        lang[f"civilian.spidermanmod.role.{role}.{i}"] = t
json.dump(lang, open(lp, "w"), indent=2)

# ---------- specimen case block ----------
wj(f"{A}/blockstates/specimen_case.json", {"variants": {"": {"model": "spidermanmod:block/specimen_case"}}})
wj(f"{A}/models/block/specimen_case.json", {
    "parent": "minecraft:block/cube_all",
    "textures": {"all": "spidermanmod:block/specimen_case"},
    "render_type": "minecraft:translucent"})
wj(f"{A}/models/item/specimen_case.json", {"parent": "spidermanmod:block/specimen_case"})

os.makedirs(f"{A}/textures/block", exist_ok=True)
im = Image.new("RGBA", (16, 16), (150, 215, 235, 95)); d = ImageDraw.Draw(im)
d.rectangle([0, 0, 15, 15], outline=(70, 75, 85, 255))               # frame
d.rectangle([1, 1, 14, 14], outline=(110, 118, 130, 255))
for x in range(3, 13, 3): d.line([(x, 2), (x, 13)], fill=(190, 235, 250, 140))   # glass glints
d.ellipse([6, 6, 9, 9], fill=(35, 35, 40, 255))                      # tiny spider body
for dx, dy in [(-2, -1), (-2, 1), (3, -1), (3, 1), (-1, -2), (3, 0), (-2, 0), (4, 0)]:
    d.point((7 + dx, 7 + dy), fill=(35, 35, 40, 255))
d.point((7, 7), fill=(80, 255, 120, 255))                            # glowing mark
im.save(f"{A}/textures/block/specimen_case.png")

# ---------- security guard (64x64, zombie-style UV) ----------
im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
skin, navy, dark = (226, 178, 140, 255), (28, 40, 82, 255), (18, 24, 52, 255)
d.rectangle([0, 0, 31, 15], fill=skin)
d.rectangle([8, 0, 15, 7], fill=navy)                 # cap top
d.rectangle([0, 8, 7, 9], fill=navy); d.rectangle([16, 8, 31, 9], fill=navy)
d.rectangle([8, 8, 15, 9], fill=navy)                 # brim
for x, y in [(9, 11), (10, 11), (13, 11), (14, 11)]: d.point((x, y), fill=(30, 30, 40, 255))
d.rectangle([16, 16, 39, 31], fill=navy)              # uniform
d.rectangle([40, 16, 55, 31], fill=navy)
d.rectangle([0, 16, 15, 31], fill=dark)               # trousers
d.rectangle([21, 18, 22, 19], fill=(235, 200, 60, 255))   # badge
d.rectangle([16, 24, 39, 24], fill=(60, 45, 30, 255))     # belt
im.save(f"{A}/textures/entity/security_guard.png")

# ---------- 16 civilian skins ----------
SKINS = [(255, 224, 189), (234, 192, 134), (198, 134, 66), (141, 85, 36), (255, 205, 148), (224, 172, 105), (172, 112, 66), (110, 70, 40)]
HAIR = [(40, 28, 20), (90, 55, 25), (200, 160, 70), (25, 25, 30), (150, 60, 30), (120, 120, 125), (60, 40, 30), (20, 20, 20)]
SHIRT = [(200, 60, 60), (60, 120, 200), (70, 170, 90), (230, 190, 60), (150, 80, 180), (240, 240, 240), (60, 60, 70), (230, 120, 60)]
PANTS = [(50, 60, 100), (70, 70, 75), (95, 70, 45), (30, 30, 35), (60, 90, 70), (110, 110, 120), (45, 55, 85), (80, 55, 55)]
os.makedirs(f"{A}/textures/entity/civilian", exist_ok=True)
for i in range(16):
    r = random.Random(i * 7919)
    skin, hair = r.choice(SKINS), r.choice(HAIR)
    shirt, pants = r.choice(SHIRT), r.choice(PANTS)
    jacket = r.random() < 0.35
    jacket_c = r.choice(SHIRT)
    cap = r.random() < 0.25
    glasses = r.random() < 0.3
    long_hair = r.random() < 0.4
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 31, 15], fill=skin + (255,))
    d.rectangle([8, 0, 15, 7], fill=hair + (255,))
    d.rectangle([0, 8, 7, 10], fill=hair + (255,)); d.rectangle([16, 8, 31, 10], fill=hair + (255,))
    d.rectangle([8, 8, 15, 9], fill=hair + (255,))
    if long_hair:
        d.rectangle([0, 8, 7, 15], fill=hair + (255,)); d.rectangle([16, 8, 31, 15], fill=hair + (255,))
    if cap:
        c = r.choice(SHIRT) + (255,)
        d.rectangle([8, 0, 15, 7], fill=c); d.rectangle([8, 8, 15, 8], fill=c)
    for x, y in [(9, 11), (10, 11), (13, 11), (14, 11)]: d.point((x, y), fill=(35, 35, 45, 255))
    if glasses: d.rectangle([8, 10, 15, 10], fill=(20, 20, 25, 255))
    d.rectangle([11, 13, 12, 13], fill=(170, 90, 90, 255))
    body = jacket_c if jacket else shirt
    d.rectangle([16, 16, 39, 31], fill=body + (255,))
    if jacket: d.rectangle([26, 16, 29, 31], fill=shirt + (255,))   # shirt under open jacket
    d.rectangle([40, 16, 55, 31], fill=skin + (255,))
    d.rectangle([40, 16, 55, 22 if not jacket else 31], fill=body + (255,))
    d.rectangle([0, 16, 15, 31], fill=pants + (255,))
    im.save(f"{A}/textures/entity/civilian/civilian_{i}.png")
print("update-3 assets generated")
