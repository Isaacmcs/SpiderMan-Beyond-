package com.spidermanmod.swing;

import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-side bookkeeping: who is swinging / wall-crawling and when they last did
 * (for fall-damage grace and voice lines).
 */
public final class SwingTracker {
    private static final Set<UUID> SWINGING = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> WALLING = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Long> LAST_ACTIVE = new ConcurrentHashMap<>();

    private SwingTracker() { }

    public static void start(ServerPlayer p) {
        SWINGING.add(p.getUUID());
        touch(p);
    }

    public static void stop(ServerPlayer p) {
        SWINGING.remove(p.getUUID());
        touch(p);
    }

    public static void startWall(ServerPlayer p) {
        WALLING.add(p.getUUID());
        touch(p);
    }

    public static void stopWall(ServerPlayer p) {
        WALLING.remove(p.getUUID());
        touch(p);
    }

    public static void touch(ServerPlayer p) {
        LAST_ACTIVE.put(p.getUUID(), p.level().getGameTime());
    }

    public static boolean isSwinging(ServerPlayer p) {
        return SWINGING.contains(p.getUUID());
    }

    public static boolean isWalling(ServerPlayer p) {
        return WALLING.contains(p.getUUID());
    }

    /** True if the player swung, zipped or crawled a wall within the last {@code ticks} ticks. */
    public static boolean swungWithin(ServerPlayer p, long ticks) {
        Long last = LAST_ACTIVE.get(p.getUUID());
        return last != null && p.level().getGameTime() - last <= ticks;
    }

    public static void forget(UUID id) {
        SWINGING.remove(id);
        WALLING.remove(id);
        LAST_ACTIVE.remove(id);
    }
}
