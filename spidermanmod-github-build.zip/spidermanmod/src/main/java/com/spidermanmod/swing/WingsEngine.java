package com.spidermanmod.swing;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.WallStatePacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Web Wings (Marvel's Spider-Man 2): hold Jump while falling to spread a web-wing and glide.
 * Look down to dive and build speed, look up to flare and slow down. Needs the Web Wings upgrade.
 */
public final class WingsEngine {
    private static final int MIN_AIR_TICKS = 8;

    private static boolean gliding;
    private static int airTicks;

    private WingsEngine() { }

    public static boolean isGliding() { return gliding; }

    public static void reset() {
        gliding = false;
        airTicks = 0;
    }

    public static void tick(Player p, MoveInput in) {
        if (p.onGround() || p.isInWater()) airTicks = 0; else airTicks++;

        boolean unlocked = ClientUpgradeCache.DATA.isUnlocked(PlayerUpgrades.WEB_WINGS);
        boolean blocked = !unlocked || !p.isAlive() || p.onGround() || p.isInWater() || p.isInLava() || p.isPassenger()
                || p.isFallFlying() || p.getAbilities().flying
                || SwingPhysicsEngine.isActive() || WallMovementEngine.isActive();
        if (blocked || !in.jumpHeld() || airTicks < MIN_AIR_TICKS) {
            stop();
            return;
        }

        Vec3 v = p.getDeltaMovement();
        if (!gliding) {
            if (v.y > -0.05) return;           // only open the wings once you're actually falling
            gliding = true;
            ModNetwork.CHANNEL.sendToServer(new WallStatePacket(true)); // suppress fall damage on the server
        }

        Vec3 look = p.getLookAngle();
        Vec3 h = new Vec3(look.x, 0, look.z);
        h = h.lengthSqr() < 1.0E-4 ? Vec3.ZERO : h.normalize();

        float pitch = p.getXRot(); // positive = looking down
        double target = 0.7 + Math.max(0.0, pitch) / 90.0 * 0.6;
        double speed = Math.sqrt(v.x * v.x + v.z * v.z);
        speed += (target - speed) * 0.08;

        double sink = pitch > 0 ? -(0.1 + pitch / 90.0 * 0.45) : -0.08 + (-pitch / 90.0) * 0.12;
        double vy = v.y + (sink - v.y) * 0.25;

        p.setDeltaMovement(h.x * speed, vy, h.z * speed);
        p.fallDistance = 0.0F;
    }

    private static void stop() {
        if (!gliding) return;
        gliding = false;
        ModNetwork.CHANNEL.sendToServer(new WallStatePacket(false));
    }
}
