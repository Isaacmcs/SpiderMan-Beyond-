package com.spidermanmod.swing;

/** Snapshot of the local player's movement keys for one client tick. */
public record MoveInput(boolean forward, boolean back, boolean left, boolean right,
                        boolean sneak, boolean sprint, boolean jumpPressed, boolean jumpHeld) {
}
