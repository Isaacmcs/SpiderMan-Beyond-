package com.spidermanmod.swing;

import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.SwingStatePacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side pendulum swing physics for the local player (movement is client-authoritative in vanilla).
 *
 * Each tick:
 *  1. Rope tension  - if the player is farther than the rope length from the anchor, the outward radial
 *                     velocity is removed and a restoring pull is added (a rigid-rope pendulum).
 *  2. Reeling       - holding Sneak shortens the rope, which drags you in and speeds the swing up.
 *  3. Momentum      - horizontal air drag is cancelled (minus a tiny bleed) so arcs keep their speed, and the
 *                     downswing is "pumped" along the current heading for forward momentum.
 *  4. Release       - Jump lets go. Releasing while rising on the upswing gives a bigger launch.
 *  5. Clamp         - speed is capped so the server never sees an implausible move.
 */
public final class SwingPhysicsEngine {
    public static final double MIN_ROPE = 4.0;
    public static final double MIN_REELED_ROPE = 3.0;

    private static final double AIR_DRAG = 0.91;      // vanilla horizontal air friction per tick
    private static final double RETENTION = 0.992;    // net horizontal retention (<1 = slow bleed)
    private static final double PUMP = 0.03;          // downswing acceleration
    private static final double STEER = 0.01;         // look-direction steering
    private static final double REEL_SPEED = 0.4;     // rope shortening per tick while sneaking
    private static final double MAX_HORIZONTAL = 1.7; // blocks / tick
    private static final double MAX_TOTAL = 2.1;

    private static boolean active;
    private static Vec3 anchor = Vec3.ZERO;
    private static double ropeLength;
    private static int ticksActive;
    private static boolean reeling;

    private SwingPhysicsEngine() { }

    public static boolean isActive() { return active; }
    public static Vec3 getAnchor() { return anchor; }
    public static double getRopeLength() { return ropeLength; }
    public static int getTicksActive() { return ticksActive; }
    public static boolean isReeling() { return reeling; }

    public static void attach(Player player, Vec3 anchorPoint) {
        anchor = anchorPoint;
        Vec3 pivot = pivot(player);
        ropeLength = Math.max(MIN_ROPE, pivot.distanceTo(anchorPoint));
        ticksActive = 0;
        reeling = false;
        active = true;

        // Kick-off: a small zip toward the anchor and a hop so the swing starts from the ground too.
        Vec3 dir = anchorPoint.subtract(pivot).normalize();
        player.setDeltaMovement(player.getDeltaMovement().add(dir.scale(0.35)).add(0, 0.25, 0));
        player.fallDistance = 0.0F;

        // Web "splat" at the anchor.
        for (int i = 0; i < 12; i++) {
            player.level().addParticle(ParticleTypes.ITEM_SNOWBALL, anchorPoint.x, anchorPoint.y, anchorPoint.z,
                    (player.getRandom().nextDouble() - 0.5) * 0.25,
                    (player.getRandom().nextDouble() - 0.5) * 0.25,
                    (player.getRandom().nextDouble() - 0.5) * 0.25);
        }
        ModNetwork.CHANNEL.sendToServer(new SwingStatePacket(true));
    }

    public static void release(Player player, boolean jumpBoost) {
        if (!active) return;
        active = false;
        reeling = false;
        if (jumpBoost) {
            Vec3 v = player.getDeltaMovement();
            boolean rising = v.y > 0.1;                  // "perfect release" on the upswing
            double mult = rising ? 1.2 : 1.05;
            double up = rising ? 0.55 : 0.4;
            player.setDeltaMovement(clamp(new Vec3(v.x * mult, v.y + up, v.z * mult)));
        }
        ModNetwork.CHANNEL.sendToServer(new SwingStatePacket(false));
    }

    /** Drop state without telling the server (logout / world change). */
    public static void reset() {
        active = false;
        reeling = false;
    }

    public static void tick(Player player, MoveInput input) {
        if (!active) return;
        ticksActive++;

        if (!player.isAlive() || player.isInWater() || player.isInLava() || player.isPassenger()
                || player.isFallFlying() || player.getAbilities().flying || !WebShooterItem.isHolding(player)) {
            release(player, false);
            return;
        }
        if (input.jumpPressed() && ticksActive > 3) {
            release(player, true);
            return;
        }

        reeling = input.sneak() && ropeLength > MIN_REELED_ROPE;
        if (reeling) {
            ropeLength = Math.max(MIN_REELED_ROPE, ropeLength - REEL_SPEED);
        }

        Vec3 vel = constrain(pivot(player), player.getDeltaMovement(), reeling);
        if (!player.onGround()) {
            vel = preserveMomentum(player, vel);
        }
        vel = clamp(vel);

        player.setDeltaMovement(vel);
        player.fallDistance = 0.0F;
    }

    private static Vec3 constrain(Vec3 pos, Vec3 vel, boolean reel) {
        Vec3 toAnchor = anchor.subtract(pos);
        double dist = toAnchor.length();
        if (dist <= ropeLength || dist < 1.0E-4) return vel;

        Vec3 dir = toAnchor.scale(1.0 / dist);       // unit vector toward the anchor
        double radial = vel.dot(dir);                // < 0 means moving away from the anchor
        if (radial < 0) {
            vel = vel.subtract(dir.scale(radial));   // tension cancels the outward component
        }
        double excess = dist - ropeLength;
        double gain = reel ? 0.3 : 0.15;
        double cap = reel ? 0.9 : 0.6;
        return vel.add(dir.scale(Math.min(excess * gain, cap)));
    }

    private static Vec3 preserveMomentum(Player player, Vec3 vel) {
        Vec3 out = new Vec3(vel.x / AIR_DRAG * RETENTION, vel.y, vel.z / AIR_DRAG * RETENTION);

        if (vel.y < -0.05) {
            Vec3 h = new Vec3(vel.x, 0, vel.z);
            if (h.lengthSqr() > 1.0E-4) {
                out = out.add(h.normalize().scale(PUMP));
            }
        }
        Vec3 look = player.getLookAngle();
        return out.add(look.x * STEER, 0, look.z * STEER);
    }

    private static Vec3 clamp(Vec3 v) {
        double h = Math.sqrt(v.x * v.x + v.z * v.z);
        if (h > MAX_HORIZONTAL) {
            double s = MAX_HORIZONTAL / h;
            v = new Vec3(v.x * s, v.y, v.z * s);
        }
        double total = v.length();
        return total > MAX_TOTAL ? v.scale(MAX_TOTAL / total) : v;
    }

    private static Vec3 pivot(Player p) {
        return p.position().add(0, p.getBbHeight() * 0.65, 0);
    }
}
