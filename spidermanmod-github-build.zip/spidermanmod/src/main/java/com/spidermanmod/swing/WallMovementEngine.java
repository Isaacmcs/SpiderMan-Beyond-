package com.spidermanmod.swing;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.WallStatePacket;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side wall climbing and wall running (movement is client-authoritative in vanilla).
 * Both need their upgrade AND spider powers (gained from the origin quest's spider bite).
 *
 * WALL CLIMB  - sprint (or be airborne) and hold W while facing a wall to cling to it.
 *               W = climb, S = climb down, A/D = strafe along the wall, idle/Sneak = cling,
 *               Jump = leap away from the wall. Reaching a ledge vaults you over the top.
 * WALL RUN    - airborne + sprint + W with a wall at your side: you run along it, gaining speed and
 *               rising briefly, for up to ~2.5 s per jump (resets on landing). Jump = wall-jump away.
 */
public final class WallMovementEngine {
    public enum Mode { NONE, CLIMB, RUN }

    private static final int MAX_RUN_TICKS = 50;
    private static final double CLIMB_SPEED = 0.24;
    private static final double STRAFE_SPEED = 0.14;
    private static final double MIN_RUN_ENTRY_SPEED = 0.15;
    private static final double MAX_RUN_SPEED = 0.85;

    private static Mode mode = Mode.NONE;
    private static Vec3 wallNormal = Vec3.ZERO; // horizontal unit vector pointing INTO the wall
    private static int runTicks;
    private static int cooldown;
    private static double runSpeed;
    private static float wallSide;              // +1 wall on the right, -1 on the left
    private static float roll;

    private WallMovementEngine() { }

    public static Mode getMode() { return mode; }
    public static boolean isActive() { return mode != Mode.NONE; }

    /** Smoothed camera roll in degrees; call once per frame. Flip the sign here if the tilt feels backwards. */
    public static float stepRoll() {
        float target = mode == Mode.RUN ? -wallSide * 7.0F : 0.0F;
        roll += (target - roll) * 0.15F;
        return roll;
    }

    public static void reset() {
        mode = Mode.NONE;
        runTicks = 0;
        cooldown = 0;
        roll = 0;
    }

    public static boolean isSpidey(Player p) {
        return ClientUpgradeCache.DATA.hasSpiderPowers();
    }

    public static void tick(Player p, MoveInput in) {
        if (cooldown > 0) cooldown--;
        if (p.onGround()) runTicks = 0;

        boolean allowed = p.isAlive() && !p.isInWater() && !p.isInLava() && !p.isPassenger() && !p.isFallFlying()
                && !p.getAbilities().flying && !SwingPhysicsEngine.isActive() && isSpidey(p);
        PlayerUpgrades u = ClientUpgradeCache.DATA;
        boolean canClimb = allowed && u.isWallClimbUnlocked();
        boolean canRun = allowed && u.isWallRunUnlocked();
        if (!canClimb && !canRun) {
            stop();
            return;
        }

        Vec3 look = p.getLookAngle();
        Vec3 lookH = new Vec3(look.x, 0, look.z);
        if (lookH.lengthSqr() < 1.0E-4) {
            stop();
            return;
        }
        lookH = lookH.normalize();
        Vec3 right = new Vec3(-lookH.z, 0, lookH.x);

        // Which walls are touching us, and where are they relative to where we look?
        Direction facing = null;
        double facingDot = 0.55;
        Direction flank = null;
        double flankScore = -1.0;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            if (!hasWall(p, d)) continue;
            double dot = lookH.x * d.getStepX() + lookH.z * d.getStepZ();
            if (dot > facingDot) {
                facing = d;
                facingDot = dot;
            } else if (Math.abs(dot) < 0.7 && 1.0 - Math.abs(dot) > flankScore) {
                flank = d;
                flankScore = 1.0 - Math.abs(dot);
            }
        }

        switch (mode) {
            case NONE -> {
                if (cooldown == 0 && in.forward()) {
                    if (canClimb && facing != null && (in.sprint() || !p.onGround())) {
                        start(Mode.CLIMB, facing);
                    } else if (canRun && flank != null && in.sprint() && !p.onGround()
                            && runTicks < MAX_RUN_TICKS && horizontalSpeed(p) > MIN_RUN_ENTRY_SPEED) {
                        runSpeed = Math.max(0.45, horizontalSpeed(p));
                        start(Mode.RUN, flank);
                    }
                }
            }
            case CLIMB -> climb(p, in, facing, lookH, right, canClimb);
            case RUN -> run(p, in, flank, lookH, right, canRun);
        }
    }

    private static void climb(Player p, MoveInput in, Direction facing, Vec3 lookH, Vec3 right, boolean canClimb) {
        if (!canClimb) {
            stop();
            return;
        }
        if (facing == null) {
            // Wall ended. If we were pushing up, vault over the ledge.
            if (in.forward() && !p.onGround()) {
                p.setDeltaMovement(lookH.x * 0.22, 0.32, lookH.z * 0.22);
            }
            cooldown = 5;
            stop();
            return;
        }
        wallNormal = new Vec3(facing.getStepX(), 0, facing.getStepZ());

        if (in.jumpPressed()) { // leap away from the wall
            p.setDeltaMovement(-wallNormal.x * 0.55, 0.62, -wallNormal.z * 0.55);
            cooldown = 8;
            stop();
            return;
        }
        if (p.onGround() && in.back()) { // climbed back down to the floor
            cooldown = 5;
            stop();
            return;
        }

        double vy = in.sneak() ? 0.0 : in.forward() ? CLIMB_SPEED : in.back() ? -CLIMB_SPEED : 0.0;
        double strafe = (in.right() ? 1.0 : 0.0) - (in.left() ? 1.0 : 0.0);
        Vec3 vel = right.scale(strafe * STRAFE_SPEED).add(wallNormal.scale(0.08)).add(0, vy, 0);
        p.setDeltaMovement(vel);
        p.fallDistance = 0.0F;
    }

    private static void run(Player p, MoveInput in, Direction flank, Vec3 lookH, Vec3 right, boolean canRun) {
        if (!canRun || flank == null || !in.forward() || p.onGround() || in.sneak() || runTicks >= MAX_RUN_TICKS) {
            cooldown = 4;
            stop();
            return;
        }
        wallNormal = new Vec3(flank.getStepX(), 0, flank.getStepZ());
        wallSide = (float) Math.signum(wallNormal.dot(right));
        Vec3 tangent = tangent(wallNormal, lookH);

        if (in.jumpPressed()) { // wall jump: away from the wall, a bit forward, and up
            p.setDeltaMovement(-wallNormal.x * 0.55 + tangent.x * 0.45, 0.58, -wallNormal.z * 0.55 + tangent.z * 0.45);
            cooldown = 6;
            stop();
            return;
        }

        runSpeed = Math.min(MAX_RUN_SPEED, runSpeed + 0.012);
        double vy = runTicks < 8 ? 0.14 : runTicks < 35 ? 0.0 : -0.05;
        Vec3 vel = tangent.scale(runSpeed).add(wallNormal.scale(0.06)).add(0, vy, 0);
        p.setDeltaMovement(vel);
        p.fallDistance = 0.0F;
        runTicks++;
    }

    private static void start(Mode newMode, Direction wall) {
        mode = newMode;
        wallNormal = new Vec3(wall.getStepX(), 0, wall.getStepZ());
        ModNetwork.CHANNEL.sendToServer(new WallStatePacket(true));
    }

    private static void stop() {
        if (mode == Mode.NONE) return;
        mode = Mode.NONE;
        ModNetwork.CHANNEL.sendToServer(new WallStatePacket(false));
    }

    private static boolean hasWall(Player p, Direction d) {
        AABB box = p.getBoundingBox().deflate(0.05, 0.1, 0.05).move(d.getStepX() * 0.2, 0, d.getStepZ() * 0.2);
        return !p.level().noCollision(p, box);
    }

    private static Vec3 tangent(Vec3 normal, Vec3 lookH) {
        Vec3 a = new Vec3(-normal.z, 0, normal.x);
        return a.dot(lookH) >= 0 ? a : a.scale(-1.0);
    }

    private static double horizontalSpeed(Player p) {
        Vec3 v = p.getDeltaMovement();
        return Math.sqrt(v.x * v.x + v.z * v.z);
    }
}
