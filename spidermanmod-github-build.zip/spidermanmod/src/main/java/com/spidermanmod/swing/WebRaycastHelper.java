package com.spidermanmod.swing;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/** Block raycast used to find a web anchor. */
public final class WebRaycastHelper {
    public static final double MAX_RANGE = 40.0;

    private WebRaycastHelper() { }

    public static Optional<BlockHitResult> raycast(Player player, double range) {
        double r = Math.min(range, MAX_RANGE);
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1.0F).scale(r));
        BlockHitResult hit = player.level().clip(
                new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.BLOCK ? Optional.of(hit) : Optional.empty();
    }
}
