package com.spidermanmod.world;

import com.spidermanmod.registry.ModDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.PortalInfo;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.ITeleporter;

import java.util.function.Function;

/** Drops the player into the city dimension high above the streets (with Slow Falling), or back home. */
public class CityTeleporter implements ITeleporter {
    public static final double CITY_SPAWN_Y = 180.0;
    public static final int SLOW_FALL_TICKS = 600;

    private final Vec3 target;

    public CityTeleporter(Vec3 target) {
        this.target = target;
    }

    @Override
    public PortalInfo getPortalInfo(Entity entity, ServerLevel destWorld, Function<ServerLevel, PortalInfo> defaultPortalInfo) {
        return new PortalInfo(target, Vec3.ZERO, entity.getYRot(), entity.getXRot());
    }

    @Override
    public boolean playTeleportSound(ServerPlayer player, ServerLevel sourceWorld, ServerLevel destWorld) {
        return false;
    }

    public static boolean toCity(ServerPlayer player) {
        ServerLevel city = player.server.getLevel(ModDimensions.SPIDERMAN_CITY);
        if (city == null) return false;
        if (player.level().dimension() == ModDimensions.SPIDERMAN_CITY) {
            player.teleportTo(city, 0.5, CITY_SPAWN_Y, 0.5, player.getYRot(), player.getXRot());
        } else {
            player.changeDimension(city, new CityTeleporter(new Vec3(0.5, CITY_SPAWN_Y, 0.5)));
        }
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, SLOW_FALL_TICKS, 0, false, false, true));
        return true;
    }

    public static void toOverworld(ServerPlayer player) {
        ServerLevel overworld = player.server.getLevel(Level.OVERWORLD);
        if (overworld == null) return;
        BlockPos spawn = overworld.getSharedSpawnPos();
        BlockPos top = overworld.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
        Vec3 pos = new Vec3(top.getX() + 0.5, top.getY() + 1.0, top.getZ() + 0.5);
        if (player.level().dimension() == Level.OVERWORLD) {
            player.teleportTo(overworld, pos.x, pos.y, pos.z, player.getYRot(), player.getXRot());
        } else {
            player.changeDimension(overworld, new CityTeleporter(pos));
        }
    }
}
