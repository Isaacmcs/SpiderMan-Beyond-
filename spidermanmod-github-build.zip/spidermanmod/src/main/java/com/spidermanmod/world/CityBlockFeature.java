package com.spidermanmod.world;

import com.mojang.serialization.Codec;
import com.spidermanmod.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Procedural city block: each 16x16 chunk gets a 3-wide road on its west/north edge, sidewalks, and either a
 * building (4-40+ floors, glass-and-pillar facade, flat roof with parapet) or a small park.
 * Everything stays inside the origin chunk, so neighbouring chunks line up into a street grid.
 * Ground level is y=62 (top flat layer), see data/spidermanmod/dimension/spiderman_city.json.
 */
public class CityBlockFeature extends Feature<NoneFeatureConfiguration> {
    public static final int GROUND_Y = 62;
    private static final int FLOOR_HEIGHT = 4;

    /** Chunk that holds Helix Research Center (the origin quest's break-in target). */
    public static final int RESEARCH_CHUNK_X = 6;
    public static final int RESEARCH_CHUNK_Z = 6;
    /** Guard posts (local x, z) on the research centre's ground floor. */
    public static final int[][] GUARD_SPAWNS = {{8, 7}, {12, 8}, {8, 12}, {12, 12}};

    public static BlockPos researchCenter() {
        return new BlockPos(RESEARCH_CHUNK_X * 16 + 9, GROUND_Y + 1, RESEARCH_CHUNK_Z * 16 + 9);
    }

    /** Where the Specimen Case sits (underground vault). */
    public static BlockPos specimenCase() {
        return new BlockPos(RESEARCH_CHUNK_X * 16 + 10, 52, RESEARCH_CHUNK_Z * 16 + 9);
    }

    public static BlockPos guardSpawn(int i) {
        return new BlockPos(RESEARCH_CHUNK_X * 16 + GUARD_SPAWNS[i][0], GROUND_Y + 1, RESEARCH_CHUNK_Z * 16 + GUARD_SPAWNS[i][1]);
    }

    private static final BlockState ASPHALT = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState LINE = Blocks.YELLOW_CONCRETE.defaultBlockState();
    private static final BlockState SIDEWALK = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    private static final BlockState LOT_FLOOR = Blocks.SMOOTH_STONE.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS_BLOCK.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private static final Block[] WALLS = {
            Blocks.STONE_BRICKS, Blocks.BRICKS, Blocks.GRAY_CONCRETE, Blocks.WHITE_CONCRETE,
            Blocks.DEEPSLATE_BRICKS, Blocks.SMOOTH_SANDSTONE, Blocks.TERRACOTTA
    };
    private static final Block[] GLASS = {
            Blocks.GLASS, Blocks.LIGHT_BLUE_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS, Blocks.GRAY_STAINED_GLASS
    };

    public CityBlockFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        int ox = origin.getX();
        int oz = origin.getZ();

        long chunkSeed = level.getSeed() ^ ((long) (ox >> 4) * 341873128712L + (long) (oz >> 4) * 132897987541L);
        RandomSource rand = RandomSource.create(chunkSeed);
        boolean research = (ox >> 4) == RESEARCH_CHUNK_X && (oz >> 4) == RESEARCH_CHUNK_Z;
        boolean park = !research && rand.nextInt(100) < 12;

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        // 1. streets, sidewalks and lot floor
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                level.setBlock(pos.set(ox + lx, GROUND_Y, oz + lz), groundAt(lx, lz, park), 2);
            }
        }

        // 2. street lamps on the sidewalk corner
        for (int dy = 1; dy <= 4; dy++) {
            level.setBlock(pos.set(ox + 3, GROUND_Y + dy, oz + 3), Blocks.IRON_BARS.defaultBlockState(), 2);
        }
        level.setBlock(pos.set(ox + 3, GROUND_Y + 5, oz + 3), Blocks.SEA_LANTERN.defaultBlockState(), 2);

        if (research) {
            buildResearchCenter(level, ox, oz, rand, pos);
        } else if (park) {
            buildPark(level, ox, oz, rand, pos);
        } else {
            buildTower(level, ox, oz, rand, pos);
        }
        return true;
    }

    private static BlockState groundAt(int lx, int lz, boolean park) {
        if (lx < 3 || lz < 3) {
            boolean marking = (lx == 1 && lz >= 3 && lz % 4 < 2) || (lz == 1 && lx >= 3 && lx % 4 < 2);
            return marking ? LINE : ASPHALT;
        }
        if (lx == 3 || lz == 3 || lx == 15 || lz == 15) return SIDEWALK;
        return park ? GRASS : LOT_FLOOR;
    }

    private void buildPark(WorldGenLevel level, int ox, int oz, RandomSource rand, BlockPos.MutableBlockPos pos) {
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState leaves = Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
        for (int i = 0; i < 4; i++) {
            int tx = 6 + rand.nextInt(7);
            int tz = 6 + rand.nextInt(7);
            int trunk = 4 + rand.nextInt(3);
            for (int dy = 1; dy <= trunk; dy++) {
                level.setBlock(pos.set(ox + tx, GROUND_Y + dy, oz + tz), log, 2);
            }
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    for (int dy = trunk - 1; dy <= trunk + 1; dy++) {
                        if (Math.abs(dx) + Math.abs(dz) + (dy - trunk + 1) > 4) continue;
                        pos.set(ox + tx + dx, GROUND_Y + dy, oz + tz + dz);
                        if (level.getBlockState(pos).isAir()) level.setBlock(pos, leaves, 2);
                    }
                }
            }
        }
    }

    /**
     * Helix Research Center: a glass-and-concrete hall (front door barred, unlocked service door round the back)
     * with lab benches, and below it a vault reached by a ladder in the west wall. The Specimen Case sits in the vault.
     */
    private void buildResearchCenter(WorldGenLevel level, int ox, int oz, RandomSource rand, BlockPos.MutableBlockPos pos) {
        BlockState wall = Blocks.WHITE_CONCRETE.defaultBlockState();
        BlockState trim = Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
        BlockState glass = Blocks.CYAN_STAINED_GLASS.defaultBlockState();
        BlockState lantern = Blocks.SEA_LANTERN.defaultBlockState();
        int height = 12;

        // shell: one tall hall, no interior floors, flat roof + parapet
        for (int dy = 1; dy <= height + 1; dy++) {
            boolean roof = dy == height;
            boolean parapet = dy == height + 1;
            for (int lx = 4; lx <= 14; lx++) {
                for (int lz = 4; lz <= 14; lz++) {
                    boolean onNS = lz == 4 || lz == 14;
                    boolean edge = onNS || lx == 4 || lx == 14;
                    if (!edge) {
                        if (roof) level.setBlock(pos.set(ox + lx, GROUND_Y + dy, oz + lz), wall, 2);
                        continue;
                    }
                    boolean pillar = onNS ? (lx - 4) % 5 == 0 : (lz - 4) % 5 == 0;
                    BlockState s;
                    if (roof || parapet) s = wall;
                    else if (dy == 1) s = trim;
                    else s = pillar ? wall : glass;

                    if (dy <= 2 && lz == 4 && (lx == 9 || lx == 10)) s = Blocks.IRON_BARS.defaultBlockState(); // front: locked
                    if (dy <= 2 && lz == 14 && lx == 9) s = AIR;                                              // service entrance
                    level.setBlock(pos.set(ox + lx, GROUND_Y + dy, oz + lz), s, 2);
                }
            }
        }
        BlockState door = Blocks.SPRUCE_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.SOUTH).setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER);
        level.setBlock(pos.set(ox + 9, GROUND_Y + 1, oz + 14), door, 2);
        level.setBlock(pos.set(ox + 9, GROUND_Y + 2, oz + 14), door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 2);

        // lights hanging from the roof
        int[][] lights = {{7, 7}, {12, 7}, {7, 12}, {12, 12}, {9, 9}};
        for (int[] l : lights) {
            level.setBlock(pos.set(ox + l[0], GROUND_Y + height - 1, oz + l[1]), lantern, 2);
        }

        // lab benches (kept clear of the guard posts, the service door path and the vault ladder)
        for (int i = 0; i < 9; i++) {
            int tx = 7 + rand.nextInt(7);
            int tz = 6 + rand.nextInt(8);
            boolean clear = !(tx == 9 && tz >= 12);
            for (int[] g : GUARD_SPAWNS) {
                if (g[0] == tx && g[1] == tz) clear = false;
            }
            if (!clear) continue;
            level.setBlock(pos.set(ox + tx, GROUND_Y + 1, oz + tz), Blocks.SMOOTH_QUARTZ.defaultBlockState(), 2);
            if (rand.nextBoolean()) {
                BlockState top = rand.nextBoolean() ? Blocks.BREWING_STAND.defaultBlockState() : Blocks.GLASS_PANE.defaultBlockState();
                level.setBlock(pos.set(ox + tx, GROUND_Y + 2, oz + tz), top, 2);
            }
        }

        // vault: 8x9 room carved into the stone below, plus a ladder niche (x=5) reaching up through the floor
        BlockState yellow = Blocks.YELLOW_CONCRETE.defaultBlockState();
        BlockState white = Blocks.WHITE_CONCRETE.defaultBlockState();
        for (int x = 6; x <= 13; x++) {
            for (int z = 5; z <= 13; z++) {
                boolean ring = x == 6 || x == 13 || z == 5 || z == 13;
                level.setBlock(pos.set(ox + x, 51, oz + z), ring ? yellow : white, 2);
                for (int y = 52; y <= 57; y++) {
                    level.setBlock(pos.set(ox + x, y, oz + z), AIR, 2);
                }
            }
        }
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.EAST);
        for (int y = 52; y <= GROUND_Y; y++) {
            level.setBlock(pos.set(ox + 5, y, oz + 8), AIR, 2);
            level.setBlock(pos.set(ox + 5, y, oz + 8), ladder, 2);
        }
        int[][] vaultLights = {{7, 6}, {12, 6}, {7, 12}, {12, 12}};
        for (int[] l : vaultLights) {
            level.setBlock(pos.set(ox + l[0], 57, oz + l[1]), lantern, 2);
        }
        level.setBlock(pos.set(ox + 10, 52, oz + 9), ModBlocks.SPECIMEN_CASE.get().defaultBlockState(), 2);
    }

    private void buildTower(WorldGenLevel level, int ox, int oz, RandomSource rand, BlockPos.MutableBlockPos pos) {
        BlockState wall = WALLS[rand.nextInt(WALLS.length)].defaultBlockState();
        BlockState glass = GLASS[rand.nextInt(GLASS.length)].defaultBlockState();

        int floors = 4 + rand.nextInt(18);
        if (rand.nextInt(6) == 0) floors += 8 + rand.nextInt(26); // occasional skyscraper
        int maxFloors = (level.getMaxBuildHeight() - GROUND_Y - 8) / FLOOR_HEIGHT;
        floors = Math.min(floors, maxFloors);
        int height = floors * FLOOR_HEIGHT;

        for (int dy = 1; dy <= height + 1; dy++) {
            boolean floorLevel = dy % FLOOR_HEIGHT == 0;
            boolean parapet = dy == height + 1;
            for (int lx = 4; lx <= 14; lx++) {
                for (int lz = 4; lz <= 14; lz++) {
                    boolean onNS = lz == 4 || lz == 14;
                    boolean edge = onNS || lx == 4 || lx == 14;
                    if (!edge) {
                        if (floorLevel && !parapet) level.setBlock(pos.set(ox + lx, GROUND_Y + dy, oz + lz), wall, 2);
                        continue;
                    }
                    BlockState s;
                    if (floorLevel || parapet) {
                        s = wall;
                    } else {
                        boolean pillar = onNS ? (lx - 4) % 5 == 0 : (lz - 4) % 5 == 0;
                        s = pillar ? wall : glass;
                    }
                    if (dy <= 2 && lz == 4 && (lx == 9 || lx == 10)) s = AIR; // entrance
                    level.setBlock(pos.set(ox + lx, GROUND_Y + dy, oz + lz), s, 2);
                }
            }
        }

        if (floors >= 14) { // antenna on the tall ones
            for (int dy = 2; dy <= 7; dy++) {
                level.setBlock(pos.set(ox + 9, GROUND_Y + height + dy, oz + 9), Blocks.IRON_BARS.defaultBlockState(), 2);
            }
            level.setBlock(pos.set(ox + 9, GROUND_Y + height + 8, oz + 9), Blocks.SEA_LANTERN.defaultBlockState(), 2);
        }
    }
}
