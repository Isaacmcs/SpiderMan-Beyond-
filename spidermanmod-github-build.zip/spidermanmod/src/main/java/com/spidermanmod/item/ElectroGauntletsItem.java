package com.spidermanmod.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Melee weapon. Hits stagger the target; right-click releases a forward shock pulse that damages and
 * stuns everything in a short cone.
 */
public class ElectroGauntletsItem extends Item {
    private static final double PULSE_RANGE = 5.0;
    private static final float PULSE_DAMAGE = 6.0F;
    private static final int COOLDOWN = 50;

    private final Multimap<Attribute, AttributeModifier> attributes;

    public ElectroGauntletsItem(Properties properties) {
        super(properties);
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", 5.0,
                AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.0,
                AttributeModifier.Operation.ADDITION));
        this.attributes = b.build();
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return slot == EquipmentSlot.MAINHAND ? attributes : super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1));
        if (target.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getBbHeight() * 0.5,
                    target.getZ(), 10, 0.3, 0.4, 0.3, 0.2);
        }
        stack.hurtAndBreak(1, attacker, e -> e.broadcastBreakEvent(EquipmentSlot.MAINHAND));
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        if (level instanceof ServerLevel sl) {
            Vec3 look = player.getLookAngle();
            Vec3 origin = player.getEyePosition();

            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(PULSE_RANGE, 2.0, PULSE_RANGE), t -> t != player && t.isAlive())) {
                Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(origin);
                double dist = to.length();
                if (dist > PULSE_RANGE || dist < 1.0E-3 || to.normalize().dot(look) < 0.4) continue; // forward cone only

                e.hurt(player.damageSources().playerAttack(player), PULSE_DAMAGE);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 5)); // stun
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1));
                e.knockback(0.4, -look.x, -look.z);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(),
                        16, 0.4, 0.5, 0.4, 0.3);
            }
            for (int i = 1; i <= 10; i++) { // visible arc in front of the player
                Vec3 p = origin.add(look.scale(i * 0.5)).add(0, -0.3, 0);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 3, 0.15, 0.15, 0.15, 0.1);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 0.6F, 1.6F);
            player.getCooldowns().addCooldown(this, COOLDOWN);
            stack.hurtAndBreak(2, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
