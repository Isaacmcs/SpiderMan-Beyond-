package com.spidermanmod.item;

import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.ImpactWebEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Throws an Impact Web. Web Capacity upgrades shorten the recharge. */
public class ImpactWebItem extends Item {
    public ImpactWebItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.5F, 0.8F);

        if (!level.isClientSide) {
            ImpactWebEntity web = new ImpactWebEntity(level, player);
            web.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.8F, 1.0F);
            level.addFreshEntity(web);

            int capacity = PlayerUpgrades.get(player).map(PlayerUpgrades::getWebCapacityLevel).orElse(0);
            player.getCooldowns().addCooldown(this, Math.max(8, 50 - 8 * capacity));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
