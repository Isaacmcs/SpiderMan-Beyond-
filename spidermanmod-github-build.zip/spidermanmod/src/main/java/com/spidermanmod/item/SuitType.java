package com.spidermanmod.item;

import com.spidermanmod.SpiderManMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

/** The three preset suits; each doubles as its own ArmorMaterial. Colours are 0xRRGGBB. */
public enum SuitType implements ArmorMaterial {
    CLASSIC("classic", 0xC8102E, 0x1F3A93, 0xFFFFFF, 20, new int[]{1, 3, 2, 1}, 0.0F),
    ADVANCED("advanced", 0xB71C1C, 0xF2F2F2, 0xFFFFFF, 30, new int[]{2, 5, 4, 2}, 0.5F),
    SYMBIOTE("symbiote", 0x0D0D0D, 0x2B2B2B, 0xFFFFFF, 38, new int[]{3, 6, 5, 3}, 1.5F);

    private final String id;
    private final int primary;
    private final int secondary;
    private final int lens;
    private final int durabilityMultiplier;
    /** helmet, chestplate, leggings, boots */
    private final int[] defense;
    private final float toughness;

    SuitType(String id, int primary, int secondary, int lens, int durabilityMultiplier, int[] defense, float toughness) {
        this.id = id;
        this.primary = primary;
        this.secondary = secondary;
        this.lens = lens;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.toughness = toughness;
    }

    public String id() { return id; }

    public CustomSuitData defaults() {
        return new CustomSuitData(primary, secondary, lens);
    }

    /** Passive effects while the FULL suit is worn (refreshed every few ticks). */
    public void applyEffects(Player player) {
        switch (this) {
            case ADVANCED -> player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 1, true, false, false));
            case SYMBIOTE -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 1, true, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, true, false, false));
            }
            case CLASSIC -> player.addEffect(new MobEffectInstance(MobEffects.JUMP, 40, 1, true, false, false));
        }
    }

    // ---- ArmorMaterial ----
    private static final int[] BASE_DURABILITY = {11, 16, 15, 13}; // helmet, chest, legs, boots

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return defense[type.ordinal()];
    }

    @Override
    public int getEnchantmentValue() { return 15; }

    @Override
    public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }

    @Override
    public Ingredient getRepairIngredient() { return Ingredient.of(Items.STRING); }

    @Override
    public String getName() { return SpiderManMod.MODID + ":" + id; }

    @Override
    public float getToughness() { return toughness; }

    @Override
    public float getKnockbackResistance() { return this == SYMBIOTE ? 0.1F : 0.0F; }
}
