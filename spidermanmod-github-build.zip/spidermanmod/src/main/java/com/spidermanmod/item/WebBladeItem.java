package com.spidermanmod.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

/** Fast iron-tier blade whose hits leave enemies tangled (Slowness II). */
public class WebBladeItem extends SwordItem {
    public WebBladeItem(Properties properties) {
        super(Tiers.IRON, 2, -1.8F, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 1));
        return super.hurtEnemy(stack, target, attacker);
    }
}
