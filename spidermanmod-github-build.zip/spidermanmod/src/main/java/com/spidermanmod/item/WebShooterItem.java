package com.spidermanmod.item;

import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.swing.SwingPhysicsEngine;
import com.spidermanmod.swing.SwingTracker;
import com.spidermanmod.swing.WebRaycastHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/**
 * Right-click: attach a web line to the block you're looking at (up to 40 blocks) and start swinging.
 *              Right-click again (or press Jump) to let go.
 * Sneak + right-click: Point Launch - zip toward the target (requires the Point Launch upgrade).
 */
public class WebShooterItem extends Item {
    public static final double RANGE = WebRaycastHelper.MAX_RANGE;

    public WebShooterItem(Properties properties) {
        super(properties);
    }

    public static boolean isHolding(Player player) {
        return player.getMainHandItem().getItem() instanceof WebShooterItem
                || player.getOffhandItem().getItem() instanceof WebShooterItem;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                pointLaunch(sp);
            }
            player.getCooldowns().addCooldown(this, 20);
        } else {
            if (level.isClientSide) {
                toggleSwing(player);
            }
            player.getCooldowns().addCooldown(this, 5);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Client side only: swing physics are client-authoritative. */
    private static void toggleSwing(Player player) {
        if (SwingPhysicsEngine.isActive()) {
            SwingPhysicsEngine.release(player, false);
            return;
        }
        Optional<BlockHitResult> hit = WebRaycastHelper.raycast(player, RANGE);
        if (hit.isPresent()) {
            SwingPhysicsEngine.attach(player, hit.get().getLocation());
        } else {
            player.displayClientMessage(Component.translatable("message.spidermanmod.no_anchor"), true);
        }
    }

    /** Server side: pull the player toward the anchor point. */
    private static void pointLaunch(ServerPlayer player) {
        boolean unlocked = PlayerUpgrades.get(player).map(PlayerUpgrades::isPointLaunchUnlocked).orElse(false);
        if (!unlocked) {
            player.displayClientMessage(Component.translatable("message.spidermanmod.point_locked"), true);
            return;
        }
        Optional<BlockHitResult> hit = WebRaycastHelper.raycast(player, RANGE);
        if (hit.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.spidermanmod.no_anchor"), true);
            return;
        }
        Vec3 anchor = hit.get().getLocation();
        Vec3 to = anchor.subtract(player.position().add(0, player.getBbHeight() * 0.5, 0));
        double dist = to.length();
        if (dist < 1.0E-3) return;

        Vec3 pull = to.normalize().scale(Math.min(2.4, 0.7 + dist * 0.055)).add(0, 0.25, 0);
        player.setDeltaMovement(pull);
        player.hurtMarked = true; // forces the velocity to be sent to the client
        player.fallDistance = 0.0F;
        SwingTracker.touch(player);
        player.level().playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT,
                SoundSource.PLAYERS, 0.8F, 1.4F);
    }
}
