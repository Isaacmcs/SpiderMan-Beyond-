package com.spidermanmod.item;

import com.spidermanmod.SpiderManMod;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** One piece of a preset Spider-Man suit. Wearing all four pieces of the same suit grants its passive effects. */
public class SpiderSuitItem extends ArmorItem {
    private final SuitType suit;

    public SpiderSuitItem(SuitType suit, Type type, Properties properties) {
        super(suit, type, properties);
        this.suit = suit;
    }

    public SuitType getSuit() {
        return suit;
    }

    public static boolean isWearingFullSuit(Player player, SuitType suit) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!(player.getItemBySlot(slot).getItem() instanceof SpiderSuitItem s) || s.suit != suit) {
                return false;
            }
        }
        return true;
    }

    /** True if the player wears any piece of any Spider-Man suit. */
    public static boolean isWearingAnyPiece(Player player) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (player.getItemBySlot(slot).getItem() instanceof SpiderSuitItem) return true;
        }
        return false;
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        // Run once per tick (from the chestplate only), server side, and only for a complete set.
        if (level.isClientSide || getType() != Type.CHESTPLATE) return;
        if (isWearingFullSuit(player, suit)) {
            suit.applyEffects(player);
        }
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        int layer = slot == EquipmentSlot.LEGS ? 2 : 1;
        return SpiderManMod.MODID + ":textures/models/armor/" + suit.id() + "_layer_" + layer + ".png";
    }
}
