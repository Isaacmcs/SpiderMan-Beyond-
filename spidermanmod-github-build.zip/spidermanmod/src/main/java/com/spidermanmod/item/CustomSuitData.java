package com.spidermanmod.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

import java.util.Optional;

/**
 * NBT-serialisable colour data for the (future) Suit Customizer: primary, secondary and lens colours,
 * each stored as 0xRRGGBB. Already used by the item colour handler, so writing it to a suit stack recolours it.
 */
public record CustomSuitData(int primary, int secondary, int lens) {
    public static final String TAG = "SuitData";

    public static CustomSuitData ofRgb(int pr, int pg, int pb, int sr, int sg, int sb, int lr, int lg, int lb) {
        return new CustomSuitData(pack(pr, pg, pb), pack(sr, sg, sb), pack(lr, lg, lb));
    }

    public static int pack(int r, int g, int b) {
        return ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    public int[] primaryRgb() { return unpack(primary); }
    public int[] secondaryRgb() { return unpack(secondary); }
    public int[] lensRgb() { return unpack(lens); }

    private static int[] unpack(int c) {
        return new int[]{(c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF};
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("Primary", primary);
        tag.putInt("Secondary", secondary);
        tag.putInt("Lens", lens);
        return tag;
    }

    public static CustomSuitData load(CompoundTag tag) {
        return new CustomSuitData(tag.getInt("Primary"), tag.getInt("Secondary"), tag.getInt("Lens"));
    }

    public void writeTo(ItemStack stack) {
        stack.getOrCreateTag().put(TAG, save());
    }

    public static Optional<CustomSuitData> fromStack(ItemStack stack) {
        CompoundTag root = stack.getTag();
        if (root == null || !root.contains(TAG, 10)) return Optional.empty();
        return Optional.of(load(root.getCompound(TAG)));
    }
}
