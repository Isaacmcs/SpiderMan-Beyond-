package com.spidermanmod.item;

import com.spidermanmod.entity.WebBombEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Throwable area-control gadget: bursts into a cluster of cobwebs and slows everything nearby. */
public class WebBombItem extends Item {
    public WebBombItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.6F, 0.6F);

        if (!level.isClientSide) {
            WebBombEntity bomb = new WebBombEntity(level, player);
            bomb.shootFromRotation(player, player.getXRot(), player.getYRot(), -10.0F, 1.2F, 1.0F);
            level.addFreshEntity(bomb);
            player.getCooldowns().addCooldown(this, 60);
        }
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
