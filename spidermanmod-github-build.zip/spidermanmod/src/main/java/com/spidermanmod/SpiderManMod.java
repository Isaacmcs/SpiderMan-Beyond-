package com.spidermanmod;

import com.mojang.logging.LogUtils;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.entity.DoctorOctopusEntity;
import com.spidermanmod.entity.ElectroEntity;
import com.spidermanmod.entity.KingpinEntity;
import com.spidermanmod.entity.RhinoEntity;
import com.spidermanmod.entity.StreetThugEntity;
import com.spidermanmod.entity.VultureEntity;
import com.spidermanmod.entity.GreenGoblinEntity;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.entity.SecurityGuardEntity;
import com.spidermanmod.registry.ModBlocks;
import com.spidermanmod.registry.ModCreativeTabs;
import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.registry.ModFeatures;
import com.spidermanmod.registry.ModItems;
import com.spidermanmod.registry.ModSounds;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Spider-Man: Beyond the Web - entry point.
 *
 * NOTE: biomes and dimensions are data-driven in 1.20.1, so the "city_district" biome and the
 * "spiderman_city" dimension live in src/main/resources/data/spidermanmod/... (see ModBiomes / ModDimensions
 * for the resource keys). Everything else is registered on the mod event bus below.
 */
@Mod(SpiderManMod.MODID)
public class SpiderManMod {
    public static final String MODID = "spidermanmod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SpiderManMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModSounds.SOUNDS.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SpiderConfig.SPEC);

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModFeatures.FEATURES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::registerCapabilities);
        modBus.addListener(this::registerAttributes);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }

    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(PlayerUpgrades.class);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.GREEN_GOBLIN.get(), GreenGoblinEntity.createAttributes().build());
        event.put(ModEntities.CIVILIAN.get(), CivilianEntity.createAttributes().build());
        event.put(ModEntities.SECURITY_GUARD.get(), SecurityGuardEntity.createAttributes().build());
        event.put(ModEntities.STREET_THUG.get(), StreetThugEntity.createAttributes().build());
        event.put(ModEntities.RHINO.get(), RhinoEntity.createAttributes().build());
        event.put(ModEntities.ELECTRO.get(), ElectroEntity.createAttributes().build());
        event.put(ModEntities.DOCTOR_OCTOPUS.get(), DoctorOctopusEntity.createAttributes().build());
        event.put(ModEntities.VULTURE.get(), VultureEntity.createAttributes().build());
        event.put(ModEntities.KINGPIN.get(), KingpinEntity.createAttributes().build());
    }
}
