package com.spidermanmod;

import net.minecraftforge.common.ForgeConfigSpec;

/** config/spidermanmod-common.toml */
public final class SpiderConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue DISABLE_VANILLA_MOBS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        DISABLE_VANILLA_MOBS = b.comment(
                        "If true, only mobs from Spider-Man: Beyond the Web can spawn (civilians, thugs, guards, villains).",
                        "Vanilla/other-mod mobs are blocked from spawning, and the doMobSpawning gamerule is switched off.")
                .define("disableVanillaMobSpawning", true);
        SPEC = b.build();
    }

    private SpiderConfig() { }
}
