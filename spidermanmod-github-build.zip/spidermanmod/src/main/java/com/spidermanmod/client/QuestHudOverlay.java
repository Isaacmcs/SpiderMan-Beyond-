package com.spidermanmod.client;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.quest.OriginQuest;
import com.spidermanmod.quest.QuestDef;
import com.spidermanmod.quest.QuestType;
import com.spidermanmod.quest.Quests;
import com.spidermanmod.registry.ModDimensions;
import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

import java.util.List;

/**
 * Top-left objective tracker. Before the powers it follows the origin story; afterwards it shows your
 * active story mission (or, failing that, a side job) with progress and the direction of the target.
 */
public class QuestHudOverlay {
    private static final String[] COMPASS = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};
    private static final int WIDTH = 190;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, screenWidth, screenHeight) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.screen != null) return;

        PlayerUpgrades d = ClientUpgradeCache.DATA;
        int stage = d.getOriginStage();

        String header;
        String text;
        String progress = null;
        BlockPos target = null;
        String targetName = "Target";

        if (stage >= OriginQuest.INFILTRATE && stage < OriginQuest.COMPLETE) {
            header = Component.translatable("hud.spidermanmod.origin.title").getString();
            text = Component.translatable("hud.spidermanmod.origin." + stage).getString();
            if (stage == OriginQuest.GO_HOME) {
                target = OriginQuest.HOME;
                targetName = "Home";
            } else if (stage <= OriginQuest.ESCAPE) {
                target = CityBlockFeature.researchCenter();
                targetName = "Helix Research Center";
            }
        } else if (stage >= OriginQuest.COMPLETE) {
            QuestDef q = tracked(d);
            if (q == null) return;
            header = q.main() ? "STORY MISSION" : "SIDE JOB";
            text = q.title() + " - " + q.objective();
            if (q.count() > 1 && q.type() != QuestType.ALTITUDE) {
                progress = d.getQuestProgress(q.id()) + " / " + q.count();
            }
            if (q.type() == QuestType.BOSS) {
                target = q.arena();
                targetName = "Boss arena";
            }
        } else {
            return;
        }

        Font font = mc.font;
        List<FormattedCharSequence> lines = font.split(FormattedText.of(text), WIDTH);

        String where = null;
        if (target != null && mc.level != null && mc.level.dimension() == ModDimensions.SPIDERMAN_CITY) {
            double dx = target.getX() + 0.5 - mc.player.getX();
            double dz = target.getZ() + 0.5 - mc.player.getZ();
            int idx = Math.floorMod(Math.round((float) (Math.toDegrees(Math.atan2(dz, dx)) / 45.0)), 8);
            where = targetName + ": " + (int) Math.sqrt(dx * dx + dz * dz) + " m " + COMPASS[idx];
        } else if (target != null) {
            where = Component.translatable("hud.spidermanmod.origin.go_to_city").getString();
        }

        int x = 8;
        int y = 8;
        int extra = (progress != null ? 11 : 0) + (where != null ? 11 : 0);
        int h = 14 + lines.size() * 10 + extra + 4;
        g.fill(x - 4, y - 4, x + WIDTH + 4, y + h, 0xB00A0A10);
        g.fill(x - 4, y - 4, x - 2, y + h, 0xFFD32F2F);
        g.drawString(font, header, x, y, 0xFFFF5252);
        int ly = y + 12;
        for (FormattedCharSequence line : lines) {
            g.drawString(font, line, x, ly, 0xFFFFFFFF);
            ly += 10;
        }
        if (progress != null) {
            g.drawString(font, progress, x, ly + 1, 0xFF9CCC65);
            ly += 11;
        }
        if (where != null) {
            g.drawString(font, where, x, ly + 1, 0xFFFFD54F);
        }
    };

    private static QuestDef tracked(PlayerUpgrades d) {
        QuestDef side = null;
        for (QuestDef q : Quests.ALL) {
            if (d.getQuestState(q.id()) != PlayerUpgrades.QUEST_ACTIVE) continue;
            if (q.main()) return q;
            if (side == null) side = q;
        }
        return side;
    }
}
