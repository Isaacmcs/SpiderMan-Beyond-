package com.spidermanmod.client;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.SecurityGuardEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SecurityGuardRenderer extends HumanoidMobRenderer<SecurityGuardEntity, HumanoidModel<SecurityGuardEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderManMod.MODID, "textures/entity/security_guard.png");

    public SecurityGuardRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(SecurityGuardEntity entity) {
        return TEXTURE;
    }
}
