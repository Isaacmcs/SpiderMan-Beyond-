package com.spidermanmod.client;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Top-right: your money, and the Focus meter once Focus Heal is unlocked. */
public class StatusHudOverlay {
    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, screenWidth, screenHeight) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        PlayerUpgrades d = ClientUpgradeCache.DATA;
        if (!d.hasSpiderPowers() && d.getMoney() <= 0) return;

        Font font = mc.font;
        String money = "$" + d.getMoney();
        g.drawString(font, money, screenWidth - font.width(money) - 8, 8, 0xFF7CFC7C);

        if (d.isUnlocked(PlayerUpgrades.FOCUS_HEAL)) {
            int w = 80;
            int x = screenWidth - w - 8;
            int y = 21;
            int filled = (int) (w * d.getFocus() / (double) PlayerUpgrades.MAX_FOCUS);
            g.fill(x - 1, y - 1, x + w + 1, y + 6, 0xFF000000);
            g.fill(x, y, x + w, y + 5, 0xFF3A3A44);
            g.fill(x, y, x + filled, y + 5, 0xFFFFC107);
            g.drawString(font, "FOCUS", x, y + 8, 0xFFBDBDBD);
        }
    };
}
