package com.spidermanmod.client;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.item.CustomSuitData;
import com.spidermanmod.item.SpiderSuitItem;
import com.spidermanmod.entity.DoctorOctopusEntity;
import com.spidermanmod.entity.ElectroEntity;
import com.spidermanmod.entity.KingpinEntity;
import com.spidermanmod.entity.RhinoEntity;
import com.spidermanmod.entity.StreetThugEntity;
import com.spidermanmod.entity.VultureEntity;
import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.registry.ModItems;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;
import org.lwjgl.glfw.GLFW;

/** Mod-bus client events: renderers, key mappings, suit tinting. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping OPEN_UPGRADES =
            new KeyMapping("key.spidermanmod.upgrades", GLFW.GLFW_KEY_U, "key.categories.spidermanmod");
    public static final KeyMapping WEB_PULL =
            new KeyMapping("key.spidermanmod.web_pull", GLFW.GLFW_KEY_V, "key.categories.spidermanmod");

    public static final KeyMapping JOURNAL =
            new KeyMapping("key.spidermanmod.journal", GLFW.GLFW_KEY_J, "key.categories.spidermanmod");
    /** Order matches ability.Ability: Focus Heal, Venom Strike, Camouflage, Concussive Blast, Symbiote Surge. */
    public static final KeyMapping[] ABILITY_KEYS = {
            new KeyMapping("key.spidermanmod.ability.focus_heal", GLFW.GLFW_KEY_G, "key.categories.spidermanmod"),
            new KeyMapping("key.spidermanmod.ability.venom_strike", GLFW.GLFW_KEY_H, "key.categories.spidermanmod"),
            new KeyMapping("key.spidermanmod.ability.camouflage", GLFW.GLFW_KEY_B, "key.categories.spidermanmod"),
            new KeyMapping("key.spidermanmod.ability.concussive_blast", GLFW.GLFW_KEY_N, "key.categories.spidermanmod"),
            new KeyMapping("key.spidermanmod.ability.symbiote_surge", GLFW.GLFW_KEY_Y, "key.categories.spidermanmod")
    };

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_UPGRADES);
        event.register(WEB_PULL);
        event.register(JOURNAL);
        for (KeyMapping k : ABILITY_KEYS) event.register(k);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.IMPACT_WEB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.PUMPKIN_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.WEB_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.GREEN_GOBLIN.get(), GreenGoblinRenderer::new);
        event.registerEntityRenderer(ModEntities.CIVILIAN.get(), CivilianRenderer::new);
        event.registerEntityRenderer(ModEntities.SECURITY_GUARD.get(), SecurityGuardRenderer::new);
        event.registerEntityRenderer(ModEntities.STREET_THUG.get(), ctx -> new HumanoidVillainRenderer<StreetThugEntity>(ctx, "street_thug", 1.0F));
        event.registerEntityRenderer(ModEntities.RHINO.get(), ctx -> new HumanoidVillainRenderer<RhinoEntity>(ctx, "rhino", 1.35F));
        event.registerEntityRenderer(ModEntities.ELECTRO.get(), ctx -> new HumanoidVillainRenderer<ElectroEntity>(ctx, "electro", 1.0F));
        event.registerEntityRenderer(ModEntities.DOCTOR_OCTOPUS.get(), ctx -> new HumanoidVillainRenderer<DoctorOctopusEntity>(ctx, "doctor_octopus", 1.1F));
        event.registerEntityRenderer(ModEntities.VULTURE.get(), ctx -> new HumanoidVillainRenderer<VultureEntity>(ctx, "vulture", 1.0F));
        event.registerEntityRenderer(ModEntities.KINGPIN.get(), ctx -> new HumanoidVillainRenderer<KingpinEntity>(ctx, "kingpin", 1.4F));
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("origin_quest", QuestHudOverlay.OVERLAY);
        event.registerAboveAll("spider_status", StatusHudOverlay.OVERLAY);
    }

    /** Suit icons use the leather-armour sprites: layer0 = primary colour, layer1 (trim) = secondary colour. */
    @SubscribeEvent
    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        Item[] pieces = ModItems.SUIT_PIECES.stream().map(RegistryObject::get).toArray(Item[]::new);
        event.register((stack, tintIndex) -> {
            if (!(stack.getItem() instanceof SpiderSuitItem suit)) return 0xFFFFFFFF;
            CustomSuitData data = CustomSuitData.fromStack(stack).orElseGet(() -> suit.getSuit().defaults());
            return 0xFF000000 | (tintIndex == 0 ? data.primary() : data.secondary());
        }, pieces);
    }
}
