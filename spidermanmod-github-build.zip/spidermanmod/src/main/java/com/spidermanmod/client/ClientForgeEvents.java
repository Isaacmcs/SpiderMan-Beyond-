package com.spidermanmod.client;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.client.screen.QuestJournalScreen;
import com.spidermanmod.client.screen.UpgradeMenuScreen;
import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.UseAbilityPacket;
import com.spidermanmod.network.WebPullPacket;
import com.spidermanmod.swing.MoveInput;
import com.spidermanmod.swing.SwingPhysicsEngine;
import com.spidermanmod.swing.WallMovementEngine;
import com.spidermanmod.swing.WingsEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge-bus client events: movement engines, keys, camera effects. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static boolean wasJumpDown;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (ClientModEvents.OPEN_UPGRADES.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new UpgradeMenuScreen());
        }
        while (ClientModEvents.JOURNAL.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new QuestJournalScreen());
        }
        while (ClientModEvents.WEB_PULL.consumeClick()) {
            if (mc.player != null && mc.screen == null && WebShooterItem.isHolding(mc.player)) {
                ModNetwork.CHANNEL.sendToServer(new WebPullPacket());
            }
        }
        for (int i = 0; i < ClientModEvents.ABILITY_KEYS.length; i++) {
            while (ClientModEvents.ABILITY_KEYS[i].consumeClick()) {
                if (mc.player != null && mc.screen == null) ModNetwork.CHANNEL.sendToServer(new UseAbilityPacket(i));
            }
        }

        if (mc.player == null) {
            SwingPhysicsEngine.reset();
            WallMovementEngine.reset();
            WingsEngine.reset();
            return;
        }
        if (mc.isPaused()) return;

        Options o = mc.options;
        boolean jumpDown = o.keyJump.isDown();
        boolean jumpPressed = jumpDown && !wasJumpDown;
        wasJumpDown = jumpDown;

        MoveInput input = new MoveInput(o.keyUp.isDown(), o.keyDown.isDown(), o.keyLeft.isDown(), o.keyRight.isDown(),
                o.keyShift.isDown(), o.keySprint.isDown(), jumpPressed, jumpDown);

        SwingPhysicsEngine.tick(mc.player, input);
        WallMovementEngine.tick(mc.player, input);
        WingsEngine.tick(mc.player, input);
    }

    /** Camera lean while wall-running. */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        event.setRoll(event.getRoll() + WallMovementEngine.stepRoll());
    }

    /** Speed feel: widen the FOV while swinging, wall-running or gliding. */
    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        if (!SwingPhysicsEngine.isActive() && !WallMovementEngine.isActive() && !WingsEngine.isGliding()) return;
        Vec3 v = event.getPlayer().getDeltaMovement();
        double speed = Math.sqrt(v.x * v.x + v.z * v.z);
        event.setNewFovModifier(event.getNewFovModifier() * (1.0F + (float) Math.min(0.25, speed * 0.12)));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        SwingPhysicsEngine.reset();
        WallMovementEngine.reset();
        WingsEngine.reset();
    }
}
