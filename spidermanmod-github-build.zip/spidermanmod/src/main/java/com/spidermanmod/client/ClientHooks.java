package com.spidermanmod.client;

import com.spidermanmod.client.screen.NPCDialogueScreen;
import com.spidermanmod.client.screen.QuestJournalScreen;
import com.spidermanmod.client.screen.ShopScreen;
import com.spidermanmod.dialogue.QuestDialogues;
import net.minecraft.client.Minecraft;
import com.spidermanmod.network.OpenDialoguePacket;
import net.minecraft.network.chat.Component;

/** Client-only entry points that common classes reach through DistExecutor. */
public class ClientHooks {
    /** Opens a server-triggered story dialogue by id. */
    public static void openDialogue(String id) {
        Minecraft mc = Minecraft.getInstance();
        switch (id) {
            case OpenDialoguePacket.ORIGIN_INTRO -> mc.setScreen(new NPCDialogueScreen(
                    Component.translatable("dialogue.spidermanmod.origin"), QuestDialogues.originIntro(), QuestDialogues.ORIGIN_START));
            case OpenDialoguePacket.ORIGIN_BITE -> mc.setScreen(new NPCDialogueScreen(
                    Component.translatable("dialogue.spidermanmod.origin"), QuestDialogues.originBite(), QuestDialogues.ORIGIN_START));
            case OpenDialoguePacket.ORIGIN_AWAKEN -> mc.setScreen(new NPCDialogueScreen(
                    Component.translatable("dialogue.spidermanmod.origin"), QuestDialogues.originAwaken(), QuestDialogues.ORIGIN_START));
            case OpenDialoguePacket.JOURNAL -> mc.setScreen(new QuestJournalScreen());
            case OpenDialoguePacket.SHOP -> mc.setScreen(new ShopScreen());
            default -> { }
        }
    }

    public static void openYuriDialogue() {
        Minecraft.getInstance().setScreen(new NPCDialogueScreen(
                Component.literal("Chinatown Outpost"), QuestDialogues.yuriChinatownOutpost(), QuestDialogues.YURI_START));
    }
}
