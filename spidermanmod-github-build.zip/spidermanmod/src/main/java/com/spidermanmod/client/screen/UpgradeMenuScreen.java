package com.spidermanmod.client.screen;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.PurchaseUpgradePacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Dark HUD-style upgrade menu: two tabs (Movement / Abilities), token count, and a locked Suit Customizer. */
public class UpgradeMenuScreen extends Screen {
    private static final int W = 360;
    private static final int H = 236;
    private static final int RED = 0xFFD32F2F;
    private static final int ROW_H = 26;
    private static final int ROW_GAP = 2;
    private static final int MAX_ROWS = 6;

    /** node id -> translation stem */
    private static final String[] NAMES = {"point_launch", "air_combo", "web_capacity", "wall_climb", "wall_run",
            "web_wings", "focus_heal", "venom_strike", "camouflage", "concussive_blast", "symbiote_surge"};
    private static final int[][] PAGES = {
            {PlayerUpgrades.POINT_LAUNCH, PlayerUpgrades.AIR_COMBO, PlayerUpgrades.WEB_CAPACITY,
                    PlayerUpgrades.WALL_CLIMB, PlayerUpgrades.WALL_RUN, PlayerUpgrades.WEB_WINGS},
            {PlayerUpgrades.FOCUS_HEAL, PlayerUpgrades.VENOM_STRIKE, PlayerUpgrades.CAMOUFLAGE,
                    PlayerUpgrades.CONCUSSIVE_BLAST, PlayerUpgrades.SYMBIOTE_SURGE}};

    private int left;
    private int top;
    private int page;
    private final Button[] nodeButtons = new Button[MAX_ROWS];
    private Button customizerBtn;

    public UpgradeMenuScreen() {
        super(Component.translatable("gui.spidermanmod.upgrades.title"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        int bx = left + W - 106;

        for (int i = 0; i < MAX_ROWS; i++) {
            final int row = i;
            nodeButtons[i] = addRenderableWidget(Button.builder(Component.empty(), b -> buy(row))
                    .bounds(bx, rowY(i) + 3, 96, 20).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.spidermanmod.tab.movement"), b -> page = 0)
                .bounds(left + W - 156, top + 4, 72, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.spidermanmod.tab.abilities"), b -> page = 1)
                .bounds(left + W - 80, top + 4, 72, 20).build());

        customizerBtn = addRenderableWidget(Button.builder(Component.translatable("gui.spidermanmod.suit_customizer"), b -> { })
                .bounds(left + 12, top + H - 28, W - 24, 20).build());
        customizerBtn.active = false; // reserved for the full release

        refresh();
    }

    private int rowY(int index) {
        return top + 34 + index * (ROW_H + ROW_GAP);
    }

    private void buy(int row) {
        if (row < PAGES[page].length) {
            ModNetwork.CHANNEL.sendToServer(new PurchaseUpgradePacket(PAGES[page][row]));
        }
    }

    private void refresh() {
        PlayerUpgrades d = ClientUpgradeCache.DATA;
        for (int i = 0; i < MAX_ROWS; i++) {
            Button b = nodeButtons[i];
            if (i >= PAGES[page].length) {
                b.visible = false;
                continue;
            }
            b.visible = true;
            int node = PAGES[page][i];
            int cost = d.costOf(node);
            boolean leveled = node == PlayerUpgrades.WEB_CAPACITY;
            if (cost == PlayerUpgrades.NEEDS_POWERS) {
                b.setMessage(Component.translatable("gui.spidermanmod.needs_powers"));
                b.active = false;
            } else if (cost < 0) {
                b.setMessage(Component.translatable(leveled ? "gui.spidermanmod.maxed" : "gui.spidermanmod.unlocked"));
                b.active = false;
            } else {
                b.setMessage(Component.translatable(leveled ? "gui.spidermanmod.upgrade" : "gui.spidermanmod.unlock", cost));
                b.active = d.getHeroTokens() >= cost;
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        PlayerUpgrades d = ClientUpgradeCache.DATA;

        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, RED);
        g.fill(left, top, left + W, top + H, 0xF00A0A10);
        g.fill(left, top, left + W, top + 28, 0xFF16080B);
        g.fill(left, top + 28, left + W, top + 29, RED);
        g.drawString(font, title, left + 12, top + 10, 0xFFFF5252);
        Component tokens = Component.translatable("gui.spidermanmod.tokens", d.getHeroTokens());
        g.drawString(font, tokens, left + 104, top + 10, 0xFFFFD54F);

        for (int i = 0; i < PAGES[page].length; i++) {
            int node = PAGES[page][i];
            String stem = "gui.spidermanmod.node." + NAMES[node];
            Component name = node == PlayerUpgrades.WEB_CAPACITY
                    ? Component.translatable(stem, d.getWebCapacityLevel(), PlayerUpgrades.MAX_WEB_CAPACITY)
                    : Component.translatable(stem);
            drawNode(g, i, d.isUnlocked(node), name, Component.translatable(stem + ".desc"));
        }

        refresh();
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawNode(GuiGraphics g, int index, boolean owned, Component name, Component desc) {
        int y = rowY(index);
        g.fill(left + 10, y, left + W - 10, y + ROW_H, 0xFF14141C);
        g.fill(left + 10, y, left + 12, y + ROW_H, owned ? 0xFF43A047 : 0xFF5A1A1F);
        g.fill(left + 20, y + 7, left + 32, y + 19, owned ? 0xFF43A047 : 0xFF3A1216);
        g.fill(left + 22, y + 9, left + 30, y + 17, owned ? 0xFF81C784 : 0xFF14141C);

        g.drawString(font, name, left + 42, y + 4, 0xFFFFFFFF);
        g.drawString(font, desc, left + 42, y + 15, 0xFF9E9E9E);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
