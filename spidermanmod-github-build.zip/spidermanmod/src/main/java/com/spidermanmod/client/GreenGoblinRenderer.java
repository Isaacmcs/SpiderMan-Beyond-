package com.spidermanmod.client;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.GreenGoblinEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GreenGoblinRenderer extends HumanoidMobRenderer<GreenGoblinEntity, HumanoidModel<GreenGoblinEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SpiderManMod.MODID, "textures/entity/green_goblin.png");

    public GreenGoblinRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(GreenGoblinEntity entity) {
        return TEXTURE;
    }
}
