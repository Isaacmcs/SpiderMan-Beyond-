package com.spidermanmod.client;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.CivilianEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CivilianRenderer extends HumanoidMobRenderer<CivilianEntity, HumanoidModel<CivilianEntity>> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[CivilianEntity.VARIANTS];

    static {
        for (int i = 0; i < TEXTURES.length; i++) {
            TEXTURES[i] = new ResourceLocation(SpiderManMod.MODID, "textures/entity/civilian/civilian_" + i + ".png");
        }
    }

    public CivilianRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(CivilianEntity entity) {
        return TEXTURES[entity.getVariant()];
    }
}
