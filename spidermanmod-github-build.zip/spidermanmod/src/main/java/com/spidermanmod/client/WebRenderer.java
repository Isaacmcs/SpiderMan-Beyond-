package com.spidermanmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.spidermanmod.SpiderManMod;
import com.spidermanmod.swing.SwingPhysicsEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/** Draws the live web line from the player's wrist to the anchor as a camera-facing ribbon. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID, value = Dist.CLIENT)
public class WebRenderer {
    private static final int SEGMENTS = 16;
    private static final double HALF_WIDTH = 0.025;

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || !SwingPhysicsEngine.isActive()) return;

        float partial = event.getPartialTick();
        Vec3 cam = event.getCamera().getPosition();
        boolean firstPerson = mc.options.getCameraType().isFirstPerson();

        Vec3 start = wristPosition(player, partial, firstPerson);
        Vec3 end = SwingPhysicsEngine.getAnchor();
        Vec3 line = end.subtract(start);
        double length = line.length();
        if (length < 0.1) return;
        Vec3 lineDir = line.scale(1.0 / length);

        // A slack rope sags; a taut one (distance ~ rope length) is straight.
        double slack = Math.max(0.0, SwingPhysicsEngine.getRopeLength() - length);
        double sag = Math.min(2.0, slack * 0.5);

        PoseStack poseStack = event.getPoseStack();
        Matrix4f matrix = poseStack.last().pose();

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();

        // "Twang": a fresh web vibrates and settles; a reeled-in web glows slightly.
        double wobble = Math.exp(-SwingPhysicsEngine.getTicksActive() / 5.0) * 0.35;
        double phase = (SwingPhysicsEngine.getTicksActive() + partial) * 1.3;
        float tint = SwingPhysicsEngine.isReeling() ? 0.75F : 1.0F;

        BufferBuilder buffer = Tesselator.getInstance().getBuilder();
        buffer.begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);

        for (int i = 0; i <= SEGMENTS; i++) {
            double t = i / (double) SEGMENTS;
            Vec3 p = start.add(line.scale(t)).add(0, -sag * 4.0 * t * (1.0 - t), 0);
            Vec3 rel = p.subtract(cam);

            Vec3 perp = lineDir.cross(rel);
            if (perp.lengthSqr() < 1.0E-6) continue;
            perp = perp.normalize();
            if (wobble > 0.01) {
                p = p.add(perp.scale(Math.sin(t * Math.PI * 3.0 + phase) * wobble * Math.sin(t * Math.PI)));
                rel = p.subtract(cam);
            }
            Vec3 side = perp.scale(HALF_WIDTH);

            buffer.vertex(matrix, (float) (rel.x + side.x), (float) (rel.y + side.y), (float) (rel.z + side.z))
                    .color(1.0F, 1.0F, tint, 0.92F).endVertex();
            buffer.vertex(matrix, (float) (rel.x - side.x), (float) (rel.y - side.y), (float) (rel.z - side.z))
                    .color(0.82F, 0.86F, 0.92F * tint, 0.92F).endVertex();
        }
        Tesselator.getInstance().end();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** Approximate world position of the shooting wrist. */
    private static Vec3 wristPosition(LocalPlayer p, float partial, boolean firstPerson) {
        double x = Mth.lerp(partial, p.xo, p.getX());
        double y = Mth.lerp(partial, p.yo, p.getY());
        double z = Mth.lerp(partial, p.zo, p.getZ());

        float yawDeg = firstPerson ? Mth.lerp(partial, p.yRotO, p.getYRot()) : Mth.lerp(partial, p.yBodyRotO, p.yBodyRot);
        double yaw = Math.toRadians(yawDeg);
        Vec3 forward = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        double hand = p.getMainArm() == HumanoidArm.RIGHT ? 1.0 : -1.0;

        double height = firstPerson ? p.getEyeHeight() - 0.4 : p.getBbHeight() * 0.62;
        double rightOffset = firstPerson ? 0.35 : 0.4;
        double forwardOffset = firstPerson ? 0.45 : 0.3;

        return new Vec3(x, y + height, z)
                .add(right.scale(rightOffset * hand))
                .add(forward.scale(forwardOffset));
    }
}
