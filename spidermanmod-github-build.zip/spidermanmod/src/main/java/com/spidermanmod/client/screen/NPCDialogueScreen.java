package com.spidermanmod.client.screen;

import com.spidermanmod.dialogue.DialogueNode;
import com.spidermanmod.dialogue.DialogueOption;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Dark, red-bordered dialogue frame with typewriter text, voice playback and selectable replies. */
public class NPCDialogueScreen extends Screen {
    private static final int RED = 0xFFD32F2F;

    private final Map<String, DialogueNode> nodes;
    private final String startId;

    private DialogueNode current;
    private SoundInstance voice;
    private final List<Button> choiceButtons = new ArrayList<>();

    private int boxX;
    private int boxY;
    private int boxW;
    private int boxH;
    private int textY;
    private int textWidth;
    private int revealed;

    public NPCDialogueScreen(Component title, Map<String, DialogueNode> nodes, String startId) {
        super(title);
        this.nodes = nodes;
        this.startId = startId;
    }

    @Override
    protected void init() {
        if (current == null) {
            goTo(startId);
        } else {
            layout(); // window resized: rebuild without replaying the voice line
        }
    }

    private void goTo(String id) {
        DialogueNode next = id == null ? null : nodes.get(id);
        if (next == null) {
            onClose();
            return;
        }
        current = next;
        revealed = 0;
        playVoice();
        layout();
    }

    private void choose(DialogueOption option) {
        if (option.action() != null) option.action().run();
        goTo(option.targetId());
    }

    private void layout() {
        clearWidgets();
        choiceButtons.clear();

        boxW = Math.min(width - 40, 440);
        boxX = (width - boxW) / 2;
        textWidth = boxW - 28;

        int lines = font.split(FormattedText.of(current.text()), textWidth).size();
        List<DialogueOption> options = current.options().isEmpty()
                ? List.of(new DialogueOption("Close", null))
                : current.options();

        boxH = 34 + lines * 11 + 10 + options.size() * 24 + 8;
        boxY = height - boxH - 24;
        textY = boxY + 32;

        int y = textY + lines * 11 + 10;
        int number = 1;
        for (DialogueOption option : options) {
            Button button = Button.builder(Component.literal(number++ + ". " + option.text()), b -> choose(option))
                    .bounds(boxX + 14, y, boxW - 28, 20).build();
            button.visible = false; // shown once the line finished typing
            choiceButtons.add(addRenderableWidget(button));
            y += 24;
        }
    }

    private void playVoice() {
        var soundManager = Minecraft.getInstance().getSoundManager();
        if (voice != null) soundManager.stop(voice);
        voice = null;
        if (current.voice() != null) {
            voice = SimpleSoundInstance.forUI(current.voice().get(), 1.0F);
            soundManager.play(voice);
        }
    }

    @Override
    public void tick() {
        int full = current == null ? 0 : current.text().length();
        if (revealed < full) revealed = Math.min(full, revealed + 2);
        boolean done = revealed >= full;
        for (Button b : choiceButtons) b.visible = done;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Click the box while typing to skip the animation.
        if (current != null && revealed < current.text().length()) {
            revealed = current.text().length();
            tick();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        if (current == null) return;

        // frame: red border, near-black body, darker header strip
        g.fill(boxX - 2, boxY - 2, boxX + boxW + 2, boxY + boxH + 2, RED);
        g.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xF00A0A0F);
        g.fill(boxX, boxY, boxX + boxW, boxY + 22, 0xFF1A0A0C);
        g.fill(boxX, boxY + 22, boxX + boxW, boxY + 23, RED);

        g.drawString(font, current.speaker().toUpperCase(Locale.ROOT), boxX + 14, boxY + 7, 0xFFFF5252);
        g.drawString(font, title, boxX + boxW - 14 - font.width(title), boxY + 7, 0xFF8A8A8A);

        String visible = current.text().substring(0, Math.min(revealed, current.text().length()));
        int y = textY;
        for (FormattedCharSequence line : font.split(FormattedText.of(visible), textWidth)) {
            g.drawString(font, line, boxX + 14, y, 0xFFFFFFFF);
            y += 11;
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void removed() {
        if (voice != null) Minecraft.getInstance().getSoundManager().stop(voice);
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
