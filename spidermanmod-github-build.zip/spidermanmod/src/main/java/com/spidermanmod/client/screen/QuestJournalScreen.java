package com.spidermanmod.client.screen;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.QuestAcceptPacket;
import com.spidermanmod.quest.QuestDef;
import com.spidermanmod.quest.Quests;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/** Mission board: story missions and side jobs, with accept button, objectives and rewards. */
public class QuestJournalScreen extends Screen {
    private static final int W = 420;
    private static final int H = 232;
    private static final int ROWS = 8;
    private static final int LIST_W = 176;
    private static final int RED = 0xFFD32F2F;

    private int left;
    private int top;
    private int page;
    private QuestDef selected;
    private final List<Button> rows = new ArrayList<>();
    private Button prevBtn;
    private Button nextBtn;
    private Button acceptBtn;

    public QuestJournalScreen() {
        super(Component.literal("MISSION BOARD"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        rows.clear();

        for (int i = 0; i < ROWS; i++) {
            final int slot = i;
            rows.add(addRenderableWidget(Button.builder(Component.empty(), b -> select(slot))
                    .bounds(left + 10, top + 34 + i * 21, LIST_W, 19).build()));
        }
        prevBtn = addRenderableWidget(Button.builder(Component.literal("<"), b -> { if (page > 0) page--; })
                .bounds(left + 10, top + H - 28, 40, 20).build());
        nextBtn = addRenderableWidget(Button.builder(Component.literal(">"), b -> { if ((page + 1) * ROWS < Quests.ALL.size()) page++; })
                .bounds(left + LIST_W - 30, top + H - 28, 40, 20).build());
        acceptBtn = addRenderableWidget(Button.builder(Component.literal("Accept mission"), b -> accept())
                .bounds(left + LIST_W + 26, top + H - 28, W - LIST_W - 36, 20).build());
        refresh();
    }

    private void select(int slot) {
        int idx = page * ROWS + slot;
        if (idx < Quests.ALL.size()) selected = Quests.ALL.get(idx);
    }

    private void accept() {
        if (selected != null) ModNetwork.CHANNEL.sendToServer(new QuestAcceptPacket(selected.id()));
    }

    private void refresh() {
        PlayerUpgrades d = ClientUpgradeCache.DATA;
        for (int i = 0; i < ROWS; i++) {
            Button b = rows.get(i);
            int idx = page * ROWS + i;
            if (idx >= Quests.ALL.size()) {
                b.visible = false;
                continue;
            }
            b.visible = true;
            QuestDef q = Quests.ALL.get(idx);
            int state = d.getQuestState(q.id());
            ChatFormatting color = state == PlayerUpgrades.QUEST_DONE ? ChatFormatting.GREEN
                    : state == PlayerUpgrades.QUEST_ACTIVE ? ChatFormatting.YELLOW
                    : Quests.isAvailable(q, d) ? ChatFormatting.WHITE : ChatFormatting.DARK_GRAY;
            String prefix = state == PlayerUpgrades.QUEST_DONE ? "[x] " : state == PlayerUpgrades.QUEST_ACTIVE ? "[>] " : q.main() ? "* " : "- ";
            b.setMessage(Component.literal(prefix + q.title()).withStyle(color));
        }
        prevBtn.active = page > 0;
        nextBtn.active = (page + 1) * ROWS < Quests.ALL.size();
        acceptBtn.active = selected != null && Quests.isAvailable(selected, d);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        PlayerUpgrades d = ClientUpgradeCache.DATA;

        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, RED);
        g.fill(left, top, left + W, top + H, 0xF00A0A10);
        g.fill(left, top, left + W, top + 28, 0xFF16080B);
        g.fill(left, top + 28, left + W, top + 29, RED);
        g.drawString(font, title, left + 12, top + 10, 0xFFFF5252);
        String money = "$" + d.getMoney();
        g.drawString(font, money, left + W - 12 - font.width(money), top + 10, 0xFF7CFC7C);
        g.drawString(font, "* story   - side job", left + 120, top + 10, 0xFF8A8A8A);

        int dx = left + LIST_W + 26;
        int dw = W - LIST_W - 36;
        g.fill(dx - 6, top + 34, left + W - 8, top + H - 34, 0xFF12121A);

        if (selected == null) {
            g.drawString(font, "Select a mission.", dx, top + 42, 0xFF9E9E9E);
        } else {
            g.drawString(font, selected.main() ? "STORY MISSION" : "SIDE JOB", dx, top + 40, 0xFFFF5252);
            g.drawString(font, selected.title(), dx, top + 52, 0xFFFFFFFF);

            int y = top + 66;
            for (FormattedCharSequence line : font.split(FormattedText.of(selected.description()), dw)) {
                g.drawString(font, line, dx, y, 0xFFBDBDBD);
                y += 10;
            }
            y += 4;
            g.drawString(font, "Objective: " + selected.objective(), dx, y, 0xFFFFD54F);
            y += 11;

            int state = d.getQuestState(selected.id());
            if (state == PlayerUpgrades.QUEST_ACTIVE && selected.count() > 1) {
                g.drawString(font, "Progress: " + d.getQuestProgress(selected.id()) + " / " + selected.count(), dx, y, 0xFF9CCC65);
                y += 11;
            }
            g.drawString(font, "Reward: $" + selected.rewardMoney() + " + " + selected.rewardTokens() + " tokens", dx, y, 0xFF7CFC7C);
            y += 11;

            String status;
            int color;
            if (state == PlayerUpgrades.QUEST_DONE) { status = "Completed"; color = 0xFF66BB6A; }
            else if (state == PlayerUpgrades.QUEST_ACTIVE) { status = "In progress"; color = 0xFFFFEE58; }
            else if (Quests.isAvailable(selected, d)) { status = "Available"; color = 0xFFFFFFFF; }
            else { status = "Locked: " + requirement(selected); color = 0xFFEF5350; }
            for (FormattedCharSequence line : font.split(FormattedText.of(status), dw)) {
                g.drawString(font, line, dx, y, color);
                y += 10;
            }
        }

        refresh();
        super.render(g, mouseX, mouseY, partialTick);
    }

    private static String requirement(QuestDef q) {
        if (q.requires().equals("origin")) return "needs spider powers (finish the origin story)";
        QuestDef pre = Quests.byId(q.requires());
        return pre == null ? "unknown" : "finish \"" + pre.title() + "\" first";
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
