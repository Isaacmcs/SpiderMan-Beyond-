package com.spidermanmod.client.screen;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.network.BuyFoodPacket;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.shop.ShopItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Street vendor: buy food with money. */
public class ShopScreen extends Screen {
    private static final int W = 320;
    private static final int ROW_H = 30;
    private static final int RED = 0xFFD32F2F;

    private int left;
    private int top;
    private int height0;
    private final List<Button> buyButtons = new ArrayList<>();

    public ShopScreen() {
        super(Component.literal("STREET VENDOR"));
    }

    @Override
    protected void init() {
        height0 = 44 + ShopItems.ALL.size() * ROW_H + 12;
        left = (width - W) / 2;
        top = (height - height0) / 2;
        buyButtons.clear();

        for (int i = 0; i < ShopItems.ALL.size(); i++) {
            final int index = i;
            buyButtons.add(addRenderableWidget(Button.builder(Component.literal("Buy"), b -> ModNetwork.CHANNEL.sendToServer(new BuyFoodPacket(index)))
                    .bounds(left + W - 66, top + 38 + i * ROW_H + 4, 54, 20).build()));
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int money = ClientUpgradeCache.DATA.getMoney();

        g.fill(left - 2, top - 2, left + W + 2, top + height0 + 2, RED);
        g.fill(left, top, left + W, top + height0, 0xF00A0A10);
        g.fill(left, top, left + W, top + 28, 0xFF16080B);
        g.fill(left, top + 28, left + W, top + 29, RED);
        g.drawString(font, title, left + 12, top + 10, 0xFFFF5252);
        String wallet = "Wallet: $" + money;
        g.drawString(font, wallet, left + W - 12 - font.width(wallet), top + 10, 0xFF7CFC7C);

        for (int i = 0; i < ShopItems.ALL.size(); i++) {
            ShopItems.Entry e = ShopItems.ALL.get(i);
            int y = top + 38 + i * ROW_H;
            g.fill(left + 10, y, left + W - 10, y + ROW_H - 2, 0xFF14141C);
            g.drawString(font, e.name() + "  -  $" + e.price(), left + 18, y + 5, 0xFFFFFFFF);
            g.drawString(font, e.desc(), left + 18, y + 16, 0xFF9E9E9E);
            buyButtons.get(i).active = money >= e.price();
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
