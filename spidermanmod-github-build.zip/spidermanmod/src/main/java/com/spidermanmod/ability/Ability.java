package com.spidermanmod.ability;

import com.spidermanmod.capability.PlayerUpgrades;

/** Hotkey powers. Each costs Focus (earned by fighting) and has a cooldown in ticks. */
public enum Ability {
    FOCUS_HEAL("Focus Heal", PlayerUpgrades.FOCUS_HEAL, 50, 40),
    VENOM_STRIKE("Venom Strike", PlayerUpgrades.VENOM_STRIKE, 40, 80),
    CAMOUFLAGE("Camouflage", PlayerUpgrades.CAMOUFLAGE, 50, 200),
    CONCUSSIVE_BLAST("Concussive Blast", PlayerUpgrades.CONCUSSIVE_BLAST, 30, 60),
    SYMBIOTE_SURGE("Symbiote Surge", PlayerUpgrades.SYMBIOTE_SURGE, 100, 400);

    public final String display;
    public final int node;
    public final int focusCost;
    public final int cooldownTicks;

    Ability(String display, int node, int focusCost, int cooldownTicks) {
        this.display = display;
        this.node = node;
        this.focusCost = focusCost;
        this.cooldownTicks = cooldownTicks;
    }

    public String id() {
        return name().toLowerCase(java.util.Locale.ROOT);
    }
}
