package com.spidermanmod.ability;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.item.SpiderSuitItem;
import com.spidermanmod.item.SuitType;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-side power activation. Inspired by the games and films:
 *  Focus Heal (PS4 Focus), Venom Strike (bio-electric stun), Camouflage (invisibility),
 *  Concussive Blast (suit power shockwave), Symbiote Surge (needs the full Symbiote Suit).
 */
public final class AbilityManager {
    private static final Map<String, Long> COOLDOWNS = new ConcurrentHashMap<>();

    private AbilityManager() { }

    public static void use(ServerPlayer player, int ordinal) {
        Ability[] all = Ability.values();
        if (ordinal < 0 || ordinal >= all.length) return;
        Ability a = all[ordinal];

        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null) return;
        if (!u.isUnlocked(a.node)) {
            msg(player, a.display + " is not unlocked (upgrade menu: U).");
            return;
        }

        long now = player.level().getGameTime();
        String key = player.getUUID() + ":" + ordinal;
        Long next = COOLDOWNS.get(key);
        if (next != null && now < next) {
            msg(player, a.display + " is recharging (" + ((next - now + 19) / 20) + "s).");
            return;
        }
        if (a == Ability.SYMBIOTE_SURGE && !SpiderSuitItem.isWearingFullSuit(player, SuitType.SYMBIOTE)) {
            msg(player, "Symbiote Surge needs the full Symbiote Suit.");
            return;
        }
        if (u.getFocus() < a.focusCost) {
            msg(player, "Not enough Focus (" + u.getFocus() + "/" + a.focusCost + "). Land hits to build it.");
            return;
        }

        u.setFocus(u.getFocus() - a.focusCost);
        COOLDOWNS.put(key, now + a.cooldownTicks);
        ServerLevel level = player.serverLevel();

        switch (a) {
            case FOCUS_HEAL -> {
                player.heal(8.0F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.5, player.getZ(), 8, 0.4, 0.4, 0.4, 0.0);
                sound(player, SoundEvents.BREWING_STAND_BREW, 1.0F, 1.4F);
            }
            case VENOM_STRIKE -> {
                for (LivingEntity e : nearby(player, 5.0)) {
                    e.hurt(player.damageSources().playerAttack(player), 8.0F);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 4));
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 14, 0.4, 0.5, 0.4, 0.3);
                }
                ring(level, player.position(), 5.0, ParticleTypes.ELECTRIC_SPARK);
                sound(player, SoundEvents.TRIDENT_THUNDER, 0.8F, 1.3F);
            }
            case CAMOUFLAGE -> {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 200, 0, true, false, true));
                level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 1.0, player.getZ(), 20, 0.4, 0.6, 0.4, 0.02);
                sound(player, SoundEvents.ENDERMAN_TELEPORT, 0.6F, 1.5F);
            }
            case CONCUSSIVE_BLAST -> {
                for (LivingEntity e : nearby(player, 6.0)) {
                    Vec3 away = e.position().subtract(player.position());
                    if (away.lengthSqr() < 1.0E-4) continue;
                    e.hurt(player.damageSources().playerAttack(player), 4.0F);
                    e.setDeltaMovement(away.normalize().scale(1.8).add(0, 0.5, 0));
                    e.hurtMarked = true;
                }
                ring(level, player.position(), 6.0, ParticleTypes.CLOUD);
                sound(player, SoundEvents.WARDEN_SONIC_BOOM, 0.6F, 1.6F);
            }
            case SYMBIOTE_SURGE -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 2));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 1));
                level.sendParticles(ParticleTypes.SMOKE, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.5, 0.8, 0.5, 0.05);
                sound(player, SoundEvents.ENDERMAN_SCREAM, 0.5F, 0.5F);
            }
        }
        CapabilityEvents.sync(player);
    }

    private static Iterable<LivingEntity> nearby(ServerPlayer player, double radius) {
        return player.serverLevel().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                e -> e != player && e.isAlive() && !(e instanceof com.spidermanmod.entity.CivilianEntity)
                        && e.distanceToSqr(player) <= radius * radius);
    }

    private static void ring(ServerLevel level, Vec3 c, double radius, ParticleOptions particle) {
        for (int i = 0; i < 32; i++) {
            double ang = i / 32.0 * Math.PI * 2;
            level.sendParticles(particle, c.x + Math.cos(ang) * radius, c.y + 0.2, c.z + Math.sin(ang) * radius, 1, 0, 0, 0, 0);
        }
    }

    private static void sound(ServerPlayer p, SoundEvent s, float vol, float pitch) {
        p.level().playSound(null, p.blockPosition(), s, SoundSource.PLAYERS, vol, pitch);
    }

    private static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }
}
