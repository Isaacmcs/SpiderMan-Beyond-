package com.spidermanmod.capability;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.LazyOptional;

import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent per-player progression: tokens, unlocked powers, money, Focus, origin stage and quest log. */
public class PlayerUpgrades {
    // ---- upgrade node ids (also used by the GUI and packets) ----
    public static final int POINT_LAUNCH = 0;
    public static final int AIR_COMBO = 1;
    public static final int WEB_CAPACITY = 2;
    public static final int WALL_CLIMB = 3;
    public static final int WALL_RUN = 4;
    public static final int WEB_WINGS = 5;
    public static final int FOCUS_HEAL = 6;
    public static final int VENOM_STRIKE = 7;
    public static final int CAMOUFLAGE = 8;
    public static final int CONCUSSIVE_BLAST = 9;
    public static final int SYMBIOTE_SURGE = 10;
    public static final int NODE_COUNT = 11;

    public static final int POINT_LAUNCH_COST = 5;
    public static final int AIR_COMBO_COST = 8;
    public static final int WALL_CLIMB_COST = 6;
    public static final int WALL_RUN_COST = 10;
    /** Token cost of the bitmask-stored nodes (index = node id; 0-4 unused). */
    private static final int[] MASK_COSTS = {0, 0, 0, 0, 0, 8, 4, 10, 8, 6, 12};
    public static final int MAX_WEB_CAPACITY = 5;
    public static final int MAX_FOCUS = 100;

    /** Origin quest stages (see quest.OriginQuest). Stage 5 = the player has spider powers. */
    public static final int ORIGIN_COMPLETE = 5;
    /** costOf() result for nodes that are locked until the player has spider powers. */
    public static final int NEEDS_POWERS = -2;

    /** Quest states in the log. 0 (absent) = not taken. */
    public static final int QUEST_ACTIVE = 2;
    public static final int QUEST_DONE = 3;

    private int heroTokens;
    private boolean pointLaunchUnlocked;
    private boolean airComboUnlocked;
    private int webCapacityLevel;
    private boolean wallClimbUnlocked;
    private boolean wallRunUnlocked;
    private int unlockMask;               // bits for nodes 5..10
    private boolean yuriQuestAccepted;
    private int originStage;
    private long originStamp;             // server-side: day number when the 'rest' stage began
    private int money;
    private int focus;
    private final Map<String, int[]> quests = new LinkedHashMap<>(); // id -> {state, progress}

    public static LazyOptional<PlayerUpgrades> get(Player player) {
        return player.getCapability(ModCapabilities.PLAYER_UPGRADES);
    }

    // ---- tokens ----
    public int getHeroTokens() { return heroTokens; }
    public void setHeroTokens(int v) { heroTokens = Math.max(0, v); }
    public void addTokens(int amount) { setHeroTokens(heroTokens + amount); }

    // ---- money ----
    public int getMoney() { return money; }
    public void setMoney(int v) { money = Math.max(0, v); }
    public void addMoney(int amount) { setMoney(money + amount); }
    public boolean spendMoney(int amount) {
        if (amount <= 0 || money < amount) return false;
        money -= amount;
        return true;
    }

    // ---- focus ----
    public int getFocus() { return focus; }
    public void setFocus(int v) { focus = Math.max(0, Math.min(MAX_FOCUS, v)); }
    public void addFocus(int amount) { setFocus(focus + amount); }

    // ---- simple flags ----
    public boolean isPointLaunchUnlocked() { return pointLaunchUnlocked; }
    public void setPointLaunchUnlocked(boolean v) { pointLaunchUnlocked = v; }
    public boolean isAirComboUnlocked() { return airComboUnlocked; }
    public void setAirComboUnlocked(boolean v) { airComboUnlocked = v; }
    public int getWebCapacityLevel() { return webCapacityLevel; }
    public void setWebCapacityLevel(int v) { webCapacityLevel = Math.max(0, Math.min(MAX_WEB_CAPACITY, v)); }
    public boolean isWallClimbUnlocked() { return wallClimbUnlocked; }
    public void setWallClimbUnlocked(boolean v) { wallClimbUnlocked = v; }
    public boolean isWallRunUnlocked() { return wallRunUnlocked; }
    public void setWallRunUnlocked(boolean v) { wallRunUnlocked = v; }
    public boolean isYuriQuestAccepted() { return yuriQuestAccepted; }
    public void setYuriQuestAccepted(boolean v) { yuriQuestAccepted = v; }

    // ---- origin ----
    public int getOriginStage() { return originStage; }
    public void setOriginStage(int v) { originStage = Math.max(0, Math.min(ORIGIN_COMPLETE, v)); }
    public boolean hasSpiderPowers() { return originStage >= ORIGIN_COMPLETE; }
    public long getOriginStamp() { return originStamp; }
    public void setOriginStamp(long v) { originStamp = v; }

    // ---- nodes ----
    private static boolean isMaskNode(int node) { return node >= WEB_WINGS && node < NODE_COUNT; }

    public boolean isUnlocked(int node) {
        return switch (node) {
            case POINT_LAUNCH -> pointLaunchUnlocked;
            case AIR_COMBO -> airComboUnlocked;
            case WEB_CAPACITY -> webCapacityLevel > 0;
            case WALL_CLIMB -> wallClimbUnlocked;
            case WALL_RUN -> wallRunUnlocked;
            default -> isMaskNode(node) && (unlockMask & (1 << node)) != 0;
        };
    }

    public int webCapacityCost() { return 3 + 2 * webCapacityLevel; }

    /** Token cost of a node, -1 if owned/maxed, NEEDS_POWERS (-2) if locked behind the spider bite. */
    public int costOf(int node) {
        return switch (node) {
            case POINT_LAUNCH -> pointLaunchUnlocked ? -1 : POINT_LAUNCH_COST;
            case AIR_COMBO -> airComboUnlocked ? -1 : AIR_COMBO_COST;
            case WEB_CAPACITY -> webCapacityLevel >= MAX_WEB_CAPACITY ? -1 : webCapacityCost();
            case WALL_CLIMB -> wallClimbUnlocked ? -1 : (hasSpiderPowers() ? WALL_CLIMB_COST : NEEDS_POWERS);
            case WALL_RUN -> wallRunUnlocked ? -1 : (hasSpiderPowers() ? WALL_RUN_COST : NEEDS_POWERS);
            default -> {
                if (!isMaskNode(node)) yield -1;
                if (isUnlocked(node)) yield -1;
                yield hasSpiderPowers() ? MASK_COSTS[node] : NEEDS_POWERS;
            }
        };
    }

    /** Server-side purchase. Returns true when the upgrade was bought. */
    public boolean tryPurchase(int node) {
        int cost = costOf(node);
        if (cost < 0 || heroTokens < cost) return false;
        heroTokens -= cost;
        switch (node) {
            case POINT_LAUNCH -> pointLaunchUnlocked = true;
            case AIR_COMBO -> airComboUnlocked = true;
            case WEB_CAPACITY -> webCapacityLevel++;
            case WALL_CLIMB -> wallClimbUnlocked = true;
            case WALL_RUN -> wallRunUnlocked = true;
            default -> unlockMask |= (1 << node);
        }
        return true;
    }

    // ---- quest log ----
    public int getQuestState(String id) {
        int[] q = quests.get(id);
        return q == null ? 0 : q[0];
    }

    public int getQuestProgress(String id) {
        int[] q = quests.get(id);
        return q == null ? 0 : q[1];
    }

    public void setQuest(String id, int state, int progress) {
        quests.put(id, new int[]{state, progress});
    }

    // ---- persistence ----
    public CompoundTag saveNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("HeroTokens", heroTokens);
        tag.putBoolean("PointLaunch", pointLaunchUnlocked);
        tag.putBoolean("AirCombo", airComboUnlocked);
        tag.putInt("WebCapacity", webCapacityLevel);
        tag.putBoolean("WallClimb", wallClimbUnlocked);
        tag.putBoolean("WallRun", wallRunUnlocked);
        tag.putInt("UnlockMask", unlockMask);
        tag.putBoolean("YuriQuest", yuriQuestAccepted);
        tag.putInt("OriginStage", originStage);
        tag.putLong("OriginStamp", originStamp);
        tag.putInt("Money", money);
        tag.putInt("Focus", focus);
        ListTag list = new ListTag();
        for (Map.Entry<String, int[]> e : quests.entrySet()) {
            CompoundTag q = new CompoundTag();
            q.putString("Id", e.getKey());
            q.putInt("State", e.getValue()[0]);
            q.putInt("Progress", e.getValue()[1]);
            list.add(q);
        }
        tag.put("Quests", list);
        return tag;
    }

    public void loadNBT(CompoundTag tag) {
        heroTokens = tag.getInt("HeroTokens");
        pointLaunchUnlocked = tag.getBoolean("PointLaunch");
        airComboUnlocked = tag.getBoolean("AirCombo");
        setWebCapacityLevel(tag.getInt("WebCapacity"));
        wallClimbUnlocked = tag.getBoolean("WallClimb");
        wallRunUnlocked = tag.getBoolean("WallRun");
        unlockMask = tag.getInt("UnlockMask");
        yuriQuestAccepted = tag.getBoolean("YuriQuest");
        setOriginStage(tag.getInt("OriginStage"));
        originStamp = tag.getLong("OriginStamp");
        money = Math.max(0, tag.getInt("Money"));
        setFocus(tag.getInt("Focus"));
        quests.clear();
        for (Tag t : tag.getList("Quests", Tag.TAG_COMPOUND)) {
            CompoundTag q = (CompoundTag) t;
            quests.put(q.getString("Id"), new int[]{q.getInt("State"), q.getInt("Progress")});
        }
    }

    public void copyFrom(PlayerUpgrades other) {
        loadNBT(other.saveNBT());
    }
}
