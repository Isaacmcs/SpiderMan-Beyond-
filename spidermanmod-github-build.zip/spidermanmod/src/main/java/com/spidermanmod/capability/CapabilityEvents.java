package com.spidermanmod.capability;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.SyncUpgradesPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class CapabilityEvents {
    private static final ResourceLocation ID = new ResourceLocation(SpiderManMod.MODID, "player_upgrades");

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(ID, new PlayerUpgradesProvider());
        }
    }

    /** Keep upgrades across death and the End-return trip. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        PlayerUpgrades.get(event.getOriginal()).ifPresent(old ->
                PlayerUpgrades.get(event.getEntity()).ifPresent(fresh -> fresh.copyFrom(old)));
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) sync(sp);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) sync(sp);
    }

    @SubscribeEvent
    public static void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) sync(sp);
    }

    public static void sync(ServerPlayer player) {
        PlayerUpgrades.get(player).ifPresent(u ->
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncUpgradesPacket(u)));
    }
}
