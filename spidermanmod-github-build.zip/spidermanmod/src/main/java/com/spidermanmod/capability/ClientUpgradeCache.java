package com.spidermanmod.capability;

/** Client-side mirror of the local player's upgrades (filled by SyncUpgradesPacket). No client-only imports. */
public class ClientUpgradeCache {
    public static final PlayerUpgrades DATA = new PlayerUpgrades();
}
