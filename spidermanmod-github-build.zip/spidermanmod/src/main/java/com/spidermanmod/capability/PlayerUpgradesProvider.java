package com.spidermanmod.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerUpgradesProvider implements ICapabilitySerializable<CompoundTag> {
    private final PlayerUpgrades upgrades = new PlayerUpgrades();
    private final LazyOptional<PlayerUpgrades> optional = LazyOptional.of(() -> upgrades);

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return ModCapabilities.PLAYER_UPGRADES.orEmpty(cap, optional);
    }

    @Override
    public CompoundTag serializeNBT() {
        return upgrades.saveNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        upgrades.loadNBT(nbt);
    }
}
