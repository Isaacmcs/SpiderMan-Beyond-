package com.spidermanmod.capability;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public class ModCapabilities {
    public static final Capability<PlayerUpgrades> PLAYER_UPGRADES =
            CapabilityManager.get(new CapabilityToken<>() { });
}
