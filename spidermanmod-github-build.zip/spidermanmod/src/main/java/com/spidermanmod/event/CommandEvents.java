package com.spidermanmod.event;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.entity.GreenGoblinEntity;
import com.spidermanmod.quest.OriginQuest;
import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.world.CityTeleporter;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * /spidey city            - teleport to the Spider-Man city dimension (anyone)
 * /spidey home            - back to the overworld spawn (anyone)
 * /spidey tokens add <n>  - give Hero Tokens (op)
 * /spidey goblin          - summon the Green Goblin above you (op)
 * /spidey civilians       - spawn 5 civilians around you (op)
 * /spidey origin <start|skip|reset> - origin quest testing (op)
 */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class CommandEvents {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("spidey")
                .then(Commands.literal("city").executes(c -> city(c.getSource().getPlayerOrException())))
                .then(Commands.literal("home").executes(c -> home(c.getSource().getPlayerOrException())))
                .then(Commands.literal("tokens").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("add")
                                .then(Commands.argument("amount", IntegerArgumentType.integer(1, 1000))
                                        .executes(c -> tokens(c, IntegerArgumentType.getInteger(c, "amount"))))))
                .then(Commands.literal("origin").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("start").executes(c -> origin(c.getSource().getPlayerOrException(), 0)))
                        .then(Commands.literal("skip").executes(c -> origin(c.getSource().getPlayerOrException(), 1)))
                        .then(Commands.literal("reset").executes(c -> origin(c.getSource().getPlayerOrException(), 2))))
                .then(Commands.literal("boss").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("name", StringArgumentType.word())
                                .executes(c -> boss(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "name")))))
                .then(Commands.literal("money").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("add")
                                .then(Commands.argument("amount", IntegerArgumentType.integer(1, 100000))
                                        .executes(c -> money(c, IntegerArgumentType.getInteger(c, "amount"))))))
                .then(Commands.literal("civilians").requires(s -> s.hasPermission(2))
                        .executes(c -> civilians(c.getSource().getPlayerOrException())))
                .then(Commands.literal("goblin").requires(s -> s.hasPermission(2))
                        .executes(c -> goblin(c.getSource().getPlayerOrException()))));
    }

    private static int city(ServerPlayer player) {
        if (!CityTeleporter.toCity(player)) {
            player.sendSystemMessage(Component.literal("The Spider-Man city dimension is not loaded."));
            return 0;
        }
        return 1;
    }

    private static int home(ServerPlayer player) {
        CityTeleporter.toOverworld(player);
        return 1;
    }

    private static int tokens(CommandContext<CommandSourceStack> ctx, int amount) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        PlayerUpgrades.get(player).ifPresent(u -> u.addTokens(amount));
        CapabilityEvents.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Gave " + amount + " Hero Tokens."), false);
        return amount;
    }

    /** 0 = (re)start the origin quest, 1 = skip straight to having powers, 2 = reset to a fresh start. */
    private static int origin(ServerPlayer player, int mode) {
        switch (mode) {
            case 0 -> { OriginQuest.reset(player); OriginQuest.start(player); }
            case 1 -> OriginQuest.skip(player);
            default -> OriginQuest.reset(player);
        }
        return 1;
    }

    private static int money(CommandContext<CommandSourceStack> ctx, int amount) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        PlayerUpgrades.get(player).ifPresent(u -> u.addMoney(amount));
        CapabilityEvents.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Gave $" + amount + "."), false);
        return amount;
    }

    /** /spidey boss rhino|electro|vulture|octopus|goblin|kingpin */
    private static int boss(ServerPlayer player, String name) {
        String key = switch (name) {
            case "rhino", "electro", "vulture", "kingpin" -> name;
            case "octopus", "ock", "doctor_octopus" -> "doctor_octopus";
            case "goblin", "green_goblin" -> "green_goblin";
            default -> null;
        };
        if (key == null) {
            player.sendSystemMessage(Component.literal("Bosses: rhino, electro, vulture, octopus, goblin, kingpin"));
            return 0;
        }
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(SpiderManMod.MODID, key));
        ServerLevel level = player.serverLevel();
        if (type == null || !(type.create(level) instanceof Mob boss)) return 0;
        boolean flying = key.equals("vulture") || key.equals("green_goblin");
        double x = player.getX() + player.getLookAngle().x * 8;
        double z = player.getZ() + player.getLookAngle().z * 8;
        boss.moveTo(x, player.getY() + (flying ? 8 : 0), z, player.getYRot() + 180.0F, 0.0F);
        boss.finalizeSpawn(level, level.getCurrentDifficultyAt(boss.blockPosition()), MobSpawnType.COMMAND, null, null);
        level.addFreshEntity(boss);
        boss.setTarget(player);
        return 1;
    }

    private static int civilians(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        for (int i = 0; i < 10; i++) {
            CivilianEntity.spawnAt(level, player.blockPosition().offset(level.random.nextInt(9) - 4, 0, level.random.nextInt(9) - 4));
        }
        return 10;
    }

    private static int goblin(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        GreenGoblinEntity goblin = ModEntities.GREEN_GOBLIN.get().create(level);
        if (goblin == null) return 0;
        goblin.moveTo(player.getX(), player.getY() + 8, player.getZ(), player.getYRot(), 0.0F);
        goblin.finalizeSpawn(level, level.getCurrentDifficultyAt(goblin.blockPosition()), MobSpawnType.COMMAND, null, null);
        level.addFreshEntity(goblin);
        return 1;
    }
}
