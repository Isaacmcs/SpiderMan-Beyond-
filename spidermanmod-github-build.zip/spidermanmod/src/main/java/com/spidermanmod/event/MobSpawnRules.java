package com.spidermanmod.event;

import com.spidermanmod.SpiderConfig;
import com.spidermanmod.SpiderManMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.GameRules;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * "Only Spider-Man mobs spawn": newly created mobs from any other mod/vanilla are blocked from joining the world
 * (natural spawns, chunk-generation animals, structures, spawners, eggs, /summon), and the doMobSpawning gamerule is
 * turned off. Mobs already saved in an existing world are left alone. Toggle in config/spidermanmod-common.toml.
 */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class MobSpawnRules {

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (!SpiderConfig.DISABLE_VANILLA_MOBS.get() || event.getLevel().isClientSide() || event.loadedFromDisk()) return;
        Entity e = event.getEntity();
        if (!(e instanceof Mob)) return;
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        if (key != null && !key.getNamespace().equals(SpiderManMod.MODID)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLevelLoad(LevelEvent.Load event) {
        if (SpiderConfig.DISABLE_VANILLA_MOBS.get() && event.getLevel() instanceof ServerLevel level) {
            level.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false, level.getServer());
        }
    }
}
