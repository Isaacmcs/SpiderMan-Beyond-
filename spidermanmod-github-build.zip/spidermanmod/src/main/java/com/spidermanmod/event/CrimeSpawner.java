package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.StreetThugEntity;
import com.spidermanmod.registry.ModDimensions;
import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** The city has crime: groups of street thugs keep turning up on the streets around you (vanilla mobs are off). */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class CrimeSpawner {
    private static final int CHECK_INTERVAL = 100;
    private static final int MAX_NEARBY = 8;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) return;
        if (!(event.level instanceof ServerLevel level) || level.dimension() != ModDimensions.SPIDERMAN_CITY) return;
        if (level.getGameTime() % CHECK_INTERVAL != 0) return;

        RandomSource rand = level.getRandom();
        for (ServerPlayer player : level.players()) {
            int nearby = level.getEntitiesOfClass(StreetThugEntity.class, player.getBoundingBox().inflate(48.0)).size();
            if (nearby >= MAX_NEARBY) continue;

            int wanted = 2 + rand.nextInt(2); // a small gang
            for (int attempt = 0; attempt < 12 && wanted > 0; attempt++) {
                double angle = rand.nextDouble() * Math.PI * 2;
                double dist = 24.0 + rand.nextDouble() * 18.0;
                int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
                int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
                BlockPos ground = new BlockPos(x, CityBlockFeature.GROUND_Y, z);
                if (!level.hasChunkAt(ground)) continue;

                Block b = level.getBlockState(ground).getBlock();
                boolean street = b == Blocks.LIGHT_GRAY_CONCRETE || b == Blocks.GRAY_CONCRETE;
                if (!street || !level.getBlockState(ground.above()).isAir() || !level.getBlockState(ground.above(2)).isAir()) continue;

                StreetThugEntity thug = ModEntities.STREET_THUG.get().create(level);
                if (thug == null) continue;
                thug.moveTo(x + 0.5, ground.getY() + 1, z + 0.5, rand.nextFloat() * 360.0F, 0.0F);
                thug.finalizeSpawn(level, level.getCurrentDifficultyAt(ground), MobSpawnType.EVENT, null, null);
                level.addFreshEntity(thug);
                wanted--;
            }
        }
    }
}
