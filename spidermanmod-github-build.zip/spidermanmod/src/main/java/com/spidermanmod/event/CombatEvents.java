package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.entity.GreenGoblinEntity;
import com.spidermanmod.entity.SecurityGuardEntity;
import com.spidermanmod.entity.VillainBoss;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Focus gain, the Air Combo upgrade and Hero Token rewards. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class CombatEvents {
    public static final int GOBLIN_TOKENS = 25;
    public static final int BOSS_TOKENS = 10;
    public static final int FOCUS_PER_HIT = 8;
    public static final int FOCUS_PER_KILL = 20;

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer attacker)) return;
        LivingEntity target = event.getEntity();
        if (target == attacker) return;

        PlayerUpgrades u = PlayerUpgrades.get(attacker).orElse(null);
        if (u == null) return;

        if (!(target instanceof CivilianEntity)) { // landing hits builds Focus
            u.addFocus(FOCUS_PER_HIT);
            CapabilityEvents.sync(attacker);
        }

        // Air Combo: airborne hits deal +50% damage and juggle both fighters upward.
        if (!u.isAirComboUnlocked() || attacker.onGround() || attacker.isInWater()) return;
        event.setAmount(event.getAmount() * 1.5F);

        Vec3 tv = target.getDeltaMovement();
        target.setDeltaMovement(tv.x, Math.max(tv.y, 0.35), tv.z);
        target.hurtMarked = true;

        Vec3 av = attacker.getDeltaMovement();
        attacker.setDeltaMovement(av.x, Math.max(av.y, 0.2), av.z);
        attacker.hurtMarked = true;
        attacker.fallDistance = 0.0F;
    }

    /** Tokens: +1 per hostile, +10 per supervillain, +25 for the Green Goblin. Focus: +20 per kill. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) return;
        LivingEntity dead = event.getEntity();

        int reward;
        if (dead instanceof GreenGoblinEntity) reward = GOBLIN_TOKENS;
        else if (dead instanceof VillainBoss) reward = BOSS_TOKENS;
        else if (dead instanceof SecurityGuardEntity) reward = 0; // just doing their job
        else if (dead instanceof Enemy) reward = 1;
        else return;

        PlayerUpgrades.get(killer).ifPresent(u -> {
            u.addTokens(reward);
            u.addFocus(FOCUS_PER_KILL);
        });
        CapabilityEvents.sync(killer);
        if (reward > 0) {
            killer.displayClientMessage(Component.translatable("message.spidermanmod.tokens_gained", reward), true);
        }
    }
}
