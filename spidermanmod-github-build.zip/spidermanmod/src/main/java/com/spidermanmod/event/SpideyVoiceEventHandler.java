package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.item.SpiderSuitItem;
import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.registry.ModSounds;
import com.spidermanmod.swing.SwingTracker;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Dynamic voice lines: swing quips (10-15 s random cooldown) and pain reactions. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class SpideyVoiceEventHandler {
    private static final double FAST_SPEED = 1.1;  // blocks / tick
    private static final double MIN_SPEED = 0.55;

    private static final Map<UUID, Vec3> LAST_POS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> NEXT_SWING_LINE = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> NEXT_HURT_LINE = new ConcurrentHashMap<>();

    public static void forget(UUID id) {
        LAST_POS.remove(id);
        NEXT_SWING_LINE.remove(id);
        NEXT_HURT_LINE.remove(id);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;

        Vec3 now = player.position();
        Vec3 last = LAST_POS.put(player.getUUID(), now);
        if (last == null || !SwingTracker.isSwinging(player)) return;

        double speed = now.distanceTo(last);
        long time = player.level().getGameTime();
        if (speed < MIN_SPEED || time < NEXT_SWING_LINE.getOrDefault(player.getUUID(), 0L)) return;

        SoundEvent line;
        if (speed >= FAST_SPEED) {
            line = ModSounds.SPIDEY_SWING_FAST.get();
        } else {
            line = player.getRandom().nextBoolean() ? ModSounds.SPIDEY_SWING_WOOHOO.get() : ModSounds.SPIDEY_SWING_JOKE.get();
        }
        play(player, line);
        NEXT_SWING_LINE.put(player.getUUID(), time + 200 + player.getRandom().nextInt(101)); // 10-15 s
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getAmount() <= 0 || !isSpidey(player)) return;

        long time = player.level().getGameTime();
        if (time < NEXT_HURT_LINE.getOrDefault(player.getUUID(), 0L)) return;
        NEXT_HURT_LINE.put(player.getUUID(), time + 30);

        play(player, player.getRandom().nextBoolean() ? ModSounds.SPIDEY_HURT_1.get() : ModSounds.SPIDEY_HURT_2.get());
    }

    /** "Spidey" = wearing any suit piece or holding the Web Shooter. */
    public static boolean isSpidey(ServerPlayer player) {
        return WebShooterItem.isHolding(player) || SpiderSuitItem.isWearingAnyPiece(player);
    }

    private static void play(ServerPlayer player, SoundEvent sound) {
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), sound, SoundSource.PLAYERS, 1.0F, 1.0F);
    }
}
