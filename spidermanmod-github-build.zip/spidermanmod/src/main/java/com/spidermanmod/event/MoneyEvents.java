package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Bounties: criminals drop cash. Spend it on food from vendors. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class MoneyEvents {

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) return;
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(event.getEntity().getType());
        if (key == null || !key.getNamespace().equals(SpiderManMod.MODID)) return;

        int cash = switch (key.getPath()) {
            case "street_thug" -> 4 + killer.getRandom().nextInt(9);
            case "rhino", "electro", "vulture" -> 150;
            case "doctor_octopus" -> 200;
            case "green_goblin" -> 250;
            case "kingpin" -> 400;
            default -> 0;
        };
        if (cash <= 0) return;

        PlayerUpgrades.get(killer).ifPresent(u -> u.addMoney(cash));
        CapabilityEvents.sync(killer);
        killer.displayClientMessage(Component.literal("+$" + cash), true);
    }
}
