package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.registry.ModDimensions;
import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** Keeps the city streets busy: tops up civilians (up to 30) around every player in the city dimension. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class CivilianSpawner {
    private static final int CHECK_INTERVAL = 40;
    private static final int MAX_NEARBY = 30;
    private static final int SPAWNS_PER_CHECK = 3;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) return;
        if (!(event.level instanceof ServerLevel level) || level.dimension() != ModDimensions.SPIDERMAN_CITY) return;
        if (level.getGameTime() % CHECK_INTERVAL != 0) return;

        RandomSource rand = level.getRandom();
        for (ServerPlayer player : level.players()) {
            int nearby = level.getEntitiesOfClass(CivilianEntity.class, player.getBoundingBox().inflate(48.0)).size();
            int spawned = 0;

            for (int attempt = 0; attempt < 16 && spawned < SPAWNS_PER_CHECK && nearby + spawned < MAX_NEARBY; attempt++) {
                double angle = rand.nextDouble() * Math.PI * 2;
                double dist = 16.0 + rand.nextDouble() * 30.0;
                int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
                int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
                BlockPos ground = new BlockPos(x, CityBlockFeature.GROUND_Y, z);
                if (!level.hasChunkAt(ground)) continue;

                Block b = level.getBlockState(ground).getBlock();
                boolean street = b == Blocks.LIGHT_GRAY_CONCRETE || b == Blocks.GRAY_CONCRETE;
                if (!street || !level.getBlockState(ground.above()).isAir() || !level.getBlockState(ground.above(2)).isAir()) continue;

                if (CivilianEntity.spawnAt(level, ground.above()) != null) spawned++;
            }
        }
    }
}
