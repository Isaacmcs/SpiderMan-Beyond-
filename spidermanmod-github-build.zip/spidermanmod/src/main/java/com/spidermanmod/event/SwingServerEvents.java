package com.spidermanmod.event;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.swing.SwingTracker;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side upkeep: no fall damage while/just after swinging or wall-crawling, cleanup on logout. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class SwingServerEvents {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;

        if (SwingTracker.isSwinging(player)) {
            if (!WebShooterItem.isHolding(player)) { // item swapped away without the client telling us
                SwingTracker.stop(player);
            } else {
                player.fallDistance = 0.0F;
                SwingTracker.touch(player);
            }
        }
        if (SwingTracker.isWalling(player)) {
            player.fallDistance = 0.0F;
            SwingTracker.touch(player);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && SwingTracker.swungWithin(player, 40)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        SwingTracker.forget(event.getEntity().getUUID());
        SpideyVoiceEventHandler.forget(event.getEntity().getUUID());
    }
}
