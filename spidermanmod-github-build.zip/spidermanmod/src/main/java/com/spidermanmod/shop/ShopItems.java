package com.spidermanmod.shop;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.quest.QuestManager;
import com.spidermanmod.quest.QuestType;
import com.spidermanmod.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.function.Supplier;

/** What the street vendors sell. Food costs money - there are no farms in the city. */
public final class ShopItems {
    public record Entry(Supplier<Item> item, int price, String name, String desc) { }

    public static final List<Entry> ALL = List.of(
            new Entry(ModItems.ENERGY_BAR, 5, "Energy Bar", "Restores 4 hunger - quick to eat"),
            new Entry(ModItems.HOT_DOG, 6, "Hot Dog", "Restores 6 hunger"),
            new Entry(ModItems.PIZZA_SLICE, 10, "Pizza Slice", "Restores 8 hunger"),
            new Entry(ModItems.BURGER, 14, "Burger", "Restores 10 hunger"),
            new Entry(ModItems.COFFEE, 4, "Coffee", "Small snack + Speed for a minute"));

    private ShopItems() { }

    public static void buy(ServerPlayer player, int index) {
        if (index < 0 || index >= ALL.size()) return;

        boolean vendorNearby = !player.serverLevel().getEntitiesOfClass(CivilianEntity.class,
                player.getBoundingBox().inflate(8.0), c -> c.getRole() == CivilianEntity.Role.VENDOR).isEmpty();
        if (!vendorNearby) {
            player.displayClientMessage(Component.literal("You're too far from the vendor."), true);
            return;
        }

        Entry e = ALL.get(index);
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null) return;
        if (!u.spendMoney(e.price())) {
            player.displayClientMessage(Component.literal("Not enough money ($" + e.price() + ")."), true);
            return;
        }

        ItemStack stack = new ItemStack(e.item().get());
        if (!player.addItem(stack)) player.drop(stack, false);
        player.displayClientMessage(Component.literal("Bought " + e.name() + " for $" + e.price() + "."), true);
        CapabilityEvents.sync(player);
        QuestManager.progress(player, QuestType.BUY, "", 1);
    }
}
