package com.spidermanmod.network;

import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.swing.SwingTracker;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "I'm (no longer) wall-climbing / wall-running" so fall damage can be suppressed. */
public class WallStatePacket {
    private final boolean active;

    public WallStatePacket(boolean active) {
        this.active = active;
    }

    public static void encode(WallStatePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.active);
    }

    public static WallStatePacket decode(FriendlyByteBuf buf) {
        return new WallStatePacket(buf.readBoolean());
    }

    public static void handle(WallStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            boolean allowed = PlayerUpgrades.get(player)
                    .map(u -> u.isWallClimbUnlocked() || u.isWallRunUnlocked() || u.isUnlocked(PlayerUpgrades.WEB_WINGS)).orElse(false);
            if (msg.active && allowed) {
                SwingTracker.startWall(player);
            } else {
                SwingTracker.stopWall(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
