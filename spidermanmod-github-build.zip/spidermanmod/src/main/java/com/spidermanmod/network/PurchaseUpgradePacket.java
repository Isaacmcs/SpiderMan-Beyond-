package com.spidermanmod.network;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: buy an upgrade node (validated on the server). */
public class PurchaseUpgradePacket {
    private final int node;

    public PurchaseUpgradePacket(int node) {
        this.node = node;
    }

    public static void encode(PurchaseUpgradePacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.node);
    }

    public static PurchaseUpgradePacket decode(FriendlyByteBuf buf) {
        return new PurchaseUpgradePacket(buf.readVarInt());
    }

    public static void handle(PurchaseUpgradePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            PlayerUpgrades.get(player).ifPresent(u -> {
                if (!u.tryPurchase(msg.node)) {
                    player.displayClientMessage(Component.translatable("message.spidermanmod.cannot_buy"), true);
                }
            });
            CapabilityEvents.sync(player);
        });
        ctx.get().setPacketHandled(true);
    }
}
