package com.spidermanmod.network;

import com.spidermanmod.ability.AbilityManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: a power hotkey was pressed (ordinal of ability.Ability). */
public class UseAbilityPacket {
    private final int ability;

    public UseAbilityPacket(int ability) {
        this.ability = ability;
    }

    public static void encode(UseAbilityPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.ability);
    }

    public static UseAbilityPacket decode(FriendlyByteBuf buf) {
        return new UseAbilityPacket(buf.readVarInt());
    }

    public static void handle(UseAbilityPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) AbilityManager.use(player, msg.ability);
        });
        ctx.get().setPacketHandled(true);
    }
}
