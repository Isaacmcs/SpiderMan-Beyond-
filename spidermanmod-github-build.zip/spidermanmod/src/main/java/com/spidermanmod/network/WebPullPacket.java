package com.spidermanmod.network;

import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.swing.WebRaycastHelper;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/** Client -> server: Web Pull. Yanks the living entity under the crosshair toward the player. */
public class WebPullPacket {
    public static final double RANGE = 24.0;
    private static final int COOLDOWN = 40;
    private static final Map<UUID, Long> NEXT_USE = new ConcurrentHashMap<>();

    public static void encode(WebPullPacket msg, FriendlyByteBuf buf) { }

    public static WebPullPacket decode(FriendlyByteBuf buf) {
        return new WebPullPacket();
    }

    public static void handle(WebPullPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null || !WebShooterItem.isHolding(player)) return;

            long now = player.level().getGameTime();
            if (now < NEXT_USE.getOrDefault(player.getUUID(), 0L)) return;

            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getViewVector(1.0F);
            Vec3 end = eye.add(look.scale(RANGE));
            AABB search = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
            EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, search,
                    e -> e instanceof LivingEntity && e.isPickable() && !e.isSpectator(), RANGE * RANGE);
            if (hit == null) return;

            // A wall between you and the target blocks the web.
            Optional<BlockHitResult> block = WebRaycastHelper.raycast(player, RANGE);
            if (block.isPresent() && block.get().getLocation().distanceToSqr(eye) < hit.getLocation().distanceToSqr(eye)) {
                return;
            }

            LivingEntity target = (LivingEntity) hit.getEntity();
            Vec3 to = player.position().add(0, 0.3, 0).subtract(target.position());
            double len = to.length();
            if (len < 1.0E-3) return;

            double resist = 1.0 - Math.min(1.0, target.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
            Vec3 pull = to.normalize().scale(Math.min(1.5, 0.45 + len * 0.07)).add(0, 0.22, 0).scale(resist);
            target.setDeltaMovement(pull);
            target.hurtMarked = true;
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));

            ServerLevel level = player.serverLevel();
            Vec3 from = player.getEyePosition().add(0, -0.4, 0);
            Vec3 line = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(from);
            int steps = (int) Math.max(4, line.length() * 2);
            for (int i = 0; i <= steps; i++) {
                Vec3 p = from.add(line.scale(i / (double) steps));
                level.sendParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT, SoundSource.PLAYERS, 0.8F, 1.7F);
            NEXT_USE.put(player.getUUID(), now + COOLDOWN);
        });
        ctx.get().setPacketHandled(true);
    }
}
