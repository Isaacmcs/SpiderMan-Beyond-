package com.spidermanmod.network;

import com.spidermanmod.capability.ClientUpgradeCache;
import com.spidermanmod.capability.PlayerUpgrades;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: mirrors the player's whole progression (small) for the GUI, HUD and client-side engines. */
public class SyncUpgradesPacket {
    private final CompoundTag tag;

    public SyncUpgradesPacket(PlayerUpgrades u) {
        this.tag = u.saveNBT();
    }

    private SyncUpgradesPacket(CompoundTag tag) {
        this.tag = tag;
    }

    public static void encode(SyncUpgradesPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.tag);
    }

    public static SyncUpgradesPacket decode(FriendlyByteBuf buf) {
        CompoundTag t = buf.readNbt();
        return new SyncUpgradesPacket(t == null ? new CompoundTag() : t);
    }

    public static void handle(SyncUpgradesPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientUpgradeCache.DATA.loadNBT(msg.tag));
        ctx.get().setPacketHandled(true);
    }
}
