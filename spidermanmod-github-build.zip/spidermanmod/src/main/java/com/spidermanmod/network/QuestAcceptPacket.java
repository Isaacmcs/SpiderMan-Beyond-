package com.spidermanmod.network;

import com.spidermanmod.quest.QuestManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: accept a mission from the mission board. */
public class QuestAcceptPacket {
    private final String questId;

    public QuestAcceptPacket(String questId) {
        this.questId = questId;
    }

    public static void encode(QuestAcceptPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.questId, 64);
    }

    public static QuestAcceptPacket decode(FriendlyByteBuf buf) {
        return new QuestAcceptPacket(buf.readUtf(64));
    }

    public static void handle(QuestAcceptPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) QuestManager.accept(player, msg.questId);
        });
        ctx.get().setPacketHandled(true);
    }
}
