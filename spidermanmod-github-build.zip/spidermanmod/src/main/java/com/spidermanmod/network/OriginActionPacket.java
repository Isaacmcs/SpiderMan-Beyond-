package com.spidermanmod.network;

import com.spidermanmod.quest.OriginQuest;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

/** Client -> server: a dialogue choice in the origin story. */
public class OriginActionPacket {
    public static final int START = 0;
    public static final int JOURNAL = 1;

    private final int action;

    public OriginActionPacket(int action) {
        this.action = action;
    }

    public static void encode(OriginActionPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.action);
    }

    public static OriginActionPacket decode(FriendlyByteBuf buf) {
        return new OriginActionPacket(buf.readVarInt());
    }

    public static void handle(OriginActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (msg.action == START) {
                OriginQuest.start(player);
            } else if (msg.action == JOURNAL) {
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenDialoguePacket(OpenDialoguePacket.JOURNAL));
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
