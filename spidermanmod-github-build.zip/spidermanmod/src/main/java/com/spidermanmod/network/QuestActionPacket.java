package com.spidermanmod.network;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: a dialogue option triggered a quest action. */
public class QuestActionPacket {
    public static final int ACCEPT_YURI = 0;
    public static final int YURI_REWARD_TOKENS = 5;

    private final int action;

    public QuestActionPacket(int action) {
        this.action = action;
    }

    public static void encode(QuestActionPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.action);
    }

    public static QuestActionPacket decode(FriendlyByteBuf buf) {
        return new QuestActionPacket(buf.readVarInt());
    }

    public static void handle(QuestActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (msg.action == ACCEPT_YURI) {
                PlayerUpgrades.get(player).ifPresent(u -> {
                    if (u.isYuriQuestAccepted()) {
                        player.displayClientMessage(Component.translatable("message.spidermanmod.quest_already"), false);
                    } else {
                        u.setYuriQuestAccepted(true);
                        u.addTokens(YURI_REWARD_TOKENS);
                        player.displayClientMessage(Component.translatable("message.spidermanmod.quest_accepted",
                                YURI_REWARD_TOKENS), false);
                    }
                });
                CapabilityEvents.sync(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
