package com.spidermanmod.network;

import com.spidermanmod.SpiderManMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SpiderManMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static boolean registered;

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CHANNEL.registerMessage(id++, SyncUpgradesPacket.class, SyncUpgradesPacket::encode,
                SyncUpgradesPacket::decode, SyncUpgradesPacket::handle);
        CHANNEL.registerMessage(id++, PurchaseUpgradePacket.class, PurchaseUpgradePacket::encode,
                PurchaseUpgradePacket::decode, PurchaseUpgradePacket::handle);
        CHANNEL.registerMessage(id++, SwingStatePacket.class, SwingStatePacket::encode,
                SwingStatePacket::decode, SwingStatePacket::handle);
        CHANNEL.registerMessage(id++, QuestActionPacket.class, QuestActionPacket::encode,
                QuestActionPacket::decode, QuestActionPacket::handle);
        CHANNEL.registerMessage(id++, WallStatePacket.class, WallStatePacket::encode,
                WallStatePacket::decode, WallStatePacket::handle);
        CHANNEL.registerMessage(id++, OpenDialoguePacket.class, OpenDialoguePacket::encode,
                OpenDialoguePacket::decode, OpenDialoguePacket::handle);
        CHANNEL.registerMessage(id++, OriginActionPacket.class, OriginActionPacket::encode,
                OriginActionPacket::decode, OriginActionPacket::handle);
        CHANNEL.registerMessage(id++, UseAbilityPacket.class, UseAbilityPacket::encode,
                UseAbilityPacket::decode, UseAbilityPacket::handle);
        CHANNEL.registerMessage(id++, QuestAcceptPacket.class, QuestAcceptPacket::encode,
                QuestAcceptPacket::decode, QuestAcceptPacket::handle);
        CHANNEL.registerMessage(id++, BuyFoodPacket.class, BuyFoodPacket::encode,
                BuyFoodPacket::decode, BuyFoodPacket::handle);
        CHANNEL.registerMessage(id++, WebPullPacket.class, WebPullPacket::encode,
                WebPullPacket::decode, WebPullPacket::handle);
    }
}
