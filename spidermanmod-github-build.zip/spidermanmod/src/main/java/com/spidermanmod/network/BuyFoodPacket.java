package com.spidermanmod.network;

import com.spidermanmod.shop.ShopItems;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: buy item #index from the nearby food vendor. */
public class BuyFoodPacket {
    private final int index;

    public BuyFoodPacket(int index) {
        this.index = index;
    }

    public static void encode(BuyFoodPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.index);
    }

    public static BuyFoodPacket decode(FriendlyByteBuf buf) {
        return new BuyFoodPacket(buf.readVarInt());
    }

    public static void handle(BuyFoodPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) ShopItems.buy(player, msg.index);
        });
        ctx.get().setPacketHandled(true);
    }
}
