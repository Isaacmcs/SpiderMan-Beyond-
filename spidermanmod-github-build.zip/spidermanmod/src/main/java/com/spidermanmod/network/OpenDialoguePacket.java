package com.spidermanmod.network;

import com.spidermanmod.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: open a scripted dialogue (story beats triggered by the server). */
public class OpenDialoguePacket {
    public static final String ORIGIN_INTRO = "origin_intro";
    public static final String ORIGIN_BITE = "origin_bite";
    public static final String ORIGIN_AWAKEN = "origin_awaken";
    public static final String JOURNAL = "journal";
    public static final String SHOP = "shop";

    private final String dialogueId;

    public OpenDialoguePacket(String dialogueId) {
        this.dialogueId = dialogueId;
    }

    public static void encode(OpenDialoguePacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.dialogueId, 64);
    }

    public static OpenDialoguePacket decode(FriendlyByteBuf buf) {
        return new OpenDialoguePacket(buf.readUtf(64));
    }

    public static void handle(OpenDialoguePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openDialogue(msg.dialogueId)));
        ctx.get().setPacketHandled(true);
    }
}
