package com.spidermanmod.network;

import com.spidermanmod.item.WebShooterItem;
import com.spidermanmod.swing.SwingTracker;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "I am (no longer) swinging". Swing physics run on the client; the server only tracks the flag. */
public class SwingStatePacket {
    private final boolean swinging;

    public SwingStatePacket(boolean swinging) {
        this.swinging = swinging;
    }

    public static void encode(SwingStatePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.swinging);
    }

    public static SwingStatePacket decode(FriendlyByteBuf buf) {
        return new SwingStatePacket(buf.readBoolean());
    }

    public static void handle(SwingStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            if (msg.swinging && WebShooterItem.isHolding(player)) {
                SwingTracker.start(player);
            } else {
                SwingTracker.stop(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
