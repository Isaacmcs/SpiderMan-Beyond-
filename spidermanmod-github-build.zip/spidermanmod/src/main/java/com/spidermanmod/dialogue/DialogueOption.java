package com.spidermanmod.dialogue;

import org.jetbrains.annotations.Nullable;

/**
 * A selectable reply.
 *
 * @param text     button label
 * @param targetId id of the next node, or null to end the conversation
 * @param action   optional code run (client side) when the option is chosen
 */
public record DialogueOption(String text, @Nullable String targetId, @Nullable Runnable action) {
    public DialogueOption(String text, @Nullable String targetId) {
        this(text, targetId, null);
    }
}
