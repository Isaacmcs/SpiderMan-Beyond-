package com.spidermanmod.dialogue;

import net.minecraft.sounds.SoundEvent;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

/**
 * One line of dialogue.
 *
 * @param id      unique id inside its tree
 * @param speaker title shown above the text (e.g. "Capt. Yuri Watanabe")
 * @param text    what the speaker says
 * @param voice   optional voice clip (a Supplier so RegistryObjects can be passed directly)
 * @param options replies; an empty list shows a single "Close" button
 */
public record DialogueNode(String id, String speaker, String text,
                           @Nullable Supplier<SoundEvent> voice, List<DialogueOption> options) {
}
