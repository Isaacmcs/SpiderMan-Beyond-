package com.spidermanmod.dialogue;

import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.OriginActionPacket;
import com.spidermanmod.network.QuestActionPacket;
import com.spidermanmod.registry.ModSounds;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Scripted conversations. */
public final class QuestDialogues {
    public static final String YURI_START = "start";
    private static final String YURI = "Capt. Yuri Watanabe";

    public static final String ORIGIN_START = "start";
    private static final String YOU = "You";

    private QuestDialogues() { }

    /** Pitch: Helix Research Center, tonight. Accepting starts the origin quest. */
    public static Map<String, DialogueNode> originIntro() {
        Runnable begin = () -> ModNetwork.CHANNEL.sendToServer(new OriginActionPacket(OriginActionPacket.START));
        Map<String, DialogueNode> t = new LinkedHashMap<>();

        t.put("start", new DialogueNode("start", YOU,
                "Everyone's whispering about Helix Research Center - a private lab on the east side, rumoured to be "
                        + "breeding something in a sealed vault under the main hall. Security is thin after dark. "
                        + "You've got a hoodie, a flashlight and a really bad idea.",
                null,
                List.of(
                        new DialogueOption("Sneak in tonight.", "plan", begin),
                        new DialogueOption("Not yet. Maybe another night.", null))));

        t.put("plan", new DialogueNode("plan", YOU,
                "The front door is barred, but there's a service door round the back. Guards notice sneaking people "
                        + "much later than people who stroll in whistling. The vault is underground - find the ladder. "
                        + "And the specimen case only releases after nightfall.",
                null,
                List.of(new DialogueOption("Let's do this.", null))));
        return t;
    }

    /** The bite on the way home. */
    public static Map<String, DialogueNode> originBite() {
        Map<String, DialogueNode> t = new LinkedHashMap<>();
        t.put("start", new DialogueNode("start", YOU,
                "Halfway home, something sharp stings the back of your neck. You slap at it on instinct - and your "
                        + "fist closes around a tiny, squirming body. You pull it off and, before you can think, crush it. "
                        + "A small green smear on your palm. It must have crawled out of the case and onto you.",
                null,
                List.of(new DialogueOption("Shake it off.", "tired"))));
        t.put("tired", new DialogueNode("tired", YOU,
                "Your head swims and your skin prickles. Whatever that was, it can wait until morning. "
                        + "Get home and get some sleep.",
                null,
                List.of(new DialogueOption("Go to bed.", null))));
        return t;
    }

    /** The next morning. */
    public static Map<String, DialogueNode> originAwaken() {
        Map<String, DialogueNode> t = new LinkedHashMap<>();
        t.put("start", new DialogueNode("start", YOU,
                "You wake before the alarm. Every sound in the building is razor-sharp - the pipes, the street, a "
                        + "heartbeat two floors down. You grab the bedpost to steady yourself and the wood splinters under your fingers.",
                null,
                List.of(new DialogueOption("What is happening to me?", "changes"))));
        t.put("changes", new DialogueNode("changes", YOU,
                "You press a palm to the wall and it simply... holds. Your reflexes feel wired to something that "
                        + "warns you before danger arrives. Climbing, leaping, sensing - it's all there.",
                null,
                List.of(new DialogueOption("Time to find out what this body can do.", null))));
        return t;
    }

    /**
     * Captain Yuri Watanabe at the Chinatown Outpost.
     * start -> accept | decline | query ;  query -> accept | decline ;  decline -> reconsider (accept) | end
     */
    public static Map<String, DialogueNode> yuriChinatownOutpost() {
        Runnable acceptQuest = () -> ModNetwork.CHANNEL.sendToServer(new QuestActionPacket(QuestActionPacket.ACCEPT_YURI));
        Runnable openBoard = () -> ModNetwork.CHANNEL.sendToServer(new OriginActionPacket(OriginActionPacket.JOURNAL));

        Map<String, DialogueNode> t = new LinkedHashMap<>();

        t.put("start", new DialogueNode("start", YURI,
                "Spider-Man. Good timing. Chinatown's been hit three nights running and my officers are stretched "
                        + "thin. I could use someone who can be on a rooftop in ten seconds flat.",
                ModSounds.YURI_INTRO,
                List.of(
                        new DialogueOption("I'm in. What do you need?", "accepted", acceptQuest),
                        new DialogueOption("What exactly is going on out there?", "query"),
                        new DialogueOption("Show me the mission board.", null, openBoard),
                        new DialogueOption("Not tonight, Captain.", "declined"))));

        t.put("query", new DialogueNode("query", YURI,
                "Crews are hitting shops after closing and vanishing across the rooftops. Whoever's planning it knows "
                        + "our patrol routes. Ground units can't keep up - you can.",
                ModSounds.YURI_QUERY,
                List.of(
                        new DialogueOption("Okay, that's my kind of problem. Count me in.", "accepted", acceptQuest),
                        new DialogueOption("Sounds risky. Let me think about it.", "declined"))));

        t.put("accepted", new DialogueNode("accepted", YURI,
                "Appreciate it. Sweep the district, take down anyone who looks like trouble, and keep the civilians "
                        + "clear. I'll have a few Hero Tokens waiting for the effort - spend them on upgrades.",
                ModSounds.YURI_ACCEPT,
                List.of(new DialogueOption("On it. Swinging out now.", null))));

        t.put("declined", new DialogueNode("declined", YURI,
                "Understood. The offer stands - the outpost radio's always on if you change your mind.",
                ModSounds.YURI_DECLINE,
                List.of(
                        new DialogueOption("Actually... I'll do it.", "accepted", acceptQuest),
                        new DialogueOption("Thanks, Captain. Stay safe.", null))));

        return t;
    }
}
