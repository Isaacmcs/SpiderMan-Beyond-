package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;

/** Resource key for the data-driven biome at data/spidermanmod/worldgen/biome/city_district.json */
public class ModBiomes {
    public static final ResourceKey<Biome> CITY_DISTRICT =
            ResourceKey.create(Registries.BIOME, new ResourceLocation(SpiderManMod.MODID, "city_district"));
}
