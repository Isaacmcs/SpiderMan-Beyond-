package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SpiderManMod.MODID);

    public static final RegistryObject<SoundEvent> SPIDEY_SWING_WOOHOO = reg("spidey_swing_woohoo");
    public static final RegistryObject<SoundEvent> SPIDEY_SWING_FAST = reg("spidey_swing_fast");
    public static final RegistryObject<SoundEvent> SPIDEY_SWING_JOKE = reg("spidey_swing_joke");
    public static final RegistryObject<SoundEvent> SPIDEY_HURT_1 = reg("spidey_hurt_1");
    public static final RegistryObject<SoundEvent> SPIDEY_HURT_2 = reg("spidey_hurt_2");
    public static final RegistryObject<SoundEvent> YURI_INTRO = reg("yuri_intro");
    public static final RegistryObject<SoundEvent> YURI_QUERY = reg("yuri_query");
    public static final RegistryObject<SoundEvent> YURI_ACCEPT = reg("yuri_accept");
    public static final RegistryObject<SoundEvent> YURI_DECLINE = reg("yuri_decline");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SpiderManMod.MODID, name)));
    }
}
