package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.block.SpecimenCaseBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SpiderManMod.MODID);

    /** Unbreakable in survival; glows; right-click is handled by the origin quest. */
    public static final RegistryObject<Block> SPECIMEN_CASE = BLOCKS.register("specimen_case",
            () -> new SpecimenCaseBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(-1.0F, 3600000.0F)
                    .noLootTable()
                    .noOcclusion()
                    .lightLevel(state -> 8)
                    .sound(SoundType.GLASS)));
}
