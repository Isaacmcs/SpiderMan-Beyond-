package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.entity.CivilianEntity;
import com.spidermanmod.entity.DoctorOctopusEntity;
import com.spidermanmod.entity.ElectroEntity;
import com.spidermanmod.entity.KingpinEntity;
import com.spidermanmod.entity.GreenGoblinEntity;
import com.spidermanmod.entity.ImpactWebEntity;
import com.spidermanmod.entity.PumpkinBombEntity;
import com.spidermanmod.entity.RhinoEntity;
import com.spidermanmod.entity.SecurityGuardEntity;
import com.spidermanmod.entity.StreetThugEntity;
import com.spidermanmod.entity.VultureEntity;
import com.spidermanmod.entity.WebBombEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpiderManMod.MODID);

    public static final RegistryObject<EntityType<ImpactWebEntity>> IMPACT_WEB = ENTITY_TYPES.register("impact_web",
            () -> EntityType.Builder.<ImpactWebEntity>of(ImpactWebEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("impact_web"));

    public static final RegistryObject<EntityType<PumpkinBombEntity>> PUMPKIN_BOMB = ENTITY_TYPES.register("pumpkin_bomb",
            () -> EntityType.Builder.<PumpkinBombEntity>of(PumpkinBombEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F).clientTrackingRange(4).updateInterval(10).build("pumpkin_bomb"));

    public static final RegistryObject<EntityType<GreenGoblinEntity>> GREEN_GOBLIN = ENTITY_TYPES.register("green_goblin",
            () -> EntityType.Builder.<GreenGoblinEntity>of(GreenGoblinEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.0F).clientTrackingRange(10).build("green_goblin"));

    public static final RegistryObject<EntityType<WebBombEntity>> WEB_BOMB = ENTITY_TYPES.register("web_bomb",
            () -> EntityType.Builder.<WebBombEntity>of(WebBombEntity::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F).clientTrackingRange(4).updateInterval(10).build("web_bomb"));

    public static final RegistryObject<EntityType<SecurityGuardEntity>> SECURITY_GUARD = ENTITY_TYPES.register("security_guard",
            () -> EntityType.Builder.<SecurityGuardEntity>of(SecurityGuardEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build("security_guard"));

    public static final RegistryObject<EntityType<StreetThugEntity>> STREET_THUG = ENTITY_TYPES.register("street_thug",
            () -> EntityType.Builder.<StreetThugEntity>of(StreetThugEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8).build("street_thug"));

    public static final RegistryObject<EntityType<RhinoEntity>> RHINO = ENTITY_TYPES.register("rhino",
            () -> EntityType.Builder.<RhinoEntity>of(RhinoEntity::new, MobCategory.MONSTER)
                    .sized(1.0F, 2.6F).clientTrackingRange(10).build("rhino"));

    public static final RegistryObject<EntityType<ElectroEntity>> ELECTRO = ENTITY_TYPES.register("electro",
            () -> EntityType.Builder.<ElectroEntity>of(ElectroEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).fireImmune().build("electro"));

    public static final RegistryObject<EntityType<DoctorOctopusEntity>> DOCTOR_OCTOPUS = ENTITY_TYPES.register("doctor_octopus",
            () -> EntityType.Builder.<DoctorOctopusEntity>of(DoctorOctopusEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.1F).clientTrackingRange(10).build("doctor_octopus"));

    public static final RegistryObject<EntityType<VultureEntity>> VULTURE = ENTITY_TYPES.register("vulture",
            () -> EntityType.Builder.<VultureEntity>of(VultureEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 1.95F).clientTrackingRange(10).build("vulture"));

    public static final RegistryObject<EntityType<KingpinEntity>> KINGPIN = ENTITY_TYPES.register("kingpin",
            () -> EntityType.Builder.<KingpinEntity>of(KingpinEntity::new, MobCategory.MONSTER)
                    .sized(1.0F, 2.7F).clientTrackingRange(10).build("kingpin"));

    public static final RegistryObject<EntityType<CivilianEntity>> CIVILIAN = ENTITY_TYPES.register("civilian",
            () -> EntityType.Builder.<CivilianEntity>of(CivilianEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("civilian"));
}
