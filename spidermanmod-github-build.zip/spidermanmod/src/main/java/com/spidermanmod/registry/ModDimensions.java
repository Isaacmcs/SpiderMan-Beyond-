package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/** Resource key for data/spidermanmod/dimension/spiderman_city.json */
public class ModDimensions {
    public static final ResourceKey<Level> SPIDERMAN_CITY =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(SpiderManMod.MODID, "spiderman_city"));
}
