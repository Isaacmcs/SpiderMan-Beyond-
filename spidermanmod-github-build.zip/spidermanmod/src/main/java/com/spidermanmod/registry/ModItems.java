package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.item.ElectroGauntletsItem;
import com.spidermanmod.item.ImpactWebItem;
import com.spidermanmod.item.OutpostRadioItem;
import com.spidermanmod.item.SpiderSuitItem;
import com.spidermanmod.item.SuitType;
import com.spidermanmod.item.WebBladeItem;
import com.spidermanmod.item.WebBombItem;
import com.spidermanmod.item.WebShooterItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SpiderManMod.MODID);

    public static final RegistryObject<Item> WEB_SHOOTER =
            ITEMS.register("web_shooter", () -> new WebShooterItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> IMPACT_WEB =
            ITEMS.register("impact_web", () -> new ImpactWebItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> OUTPOST_RADIO =
            ITEMS.register("outpost_radio", () -> new OutpostRadioItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> GREEN_GOBLIN_SPAWN_EGG =
            ITEMS.register("green_goblin_spawn_egg",
                    () -> new ForgeSpawnEggItem(ModEntities.GREEN_GOBLIN, 0x2E7D32, 0x6A1B9A, new Item.Properties()));

    public static final RegistryObject<Item> WEB_BOMB =
            ITEMS.register("web_bomb", () -> new WebBombItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> ELECTRO_GAUNTLETS =
            ITEMS.register("electro_gauntlets", () -> new ElectroGauntletsItem(new Item.Properties().durability(300)));
    public static final RegistryObject<Item> WEB_BLADE =
            ITEMS.register("web_blade", () -> new WebBladeItem(new Item.Properties().durability(350)));
    // ---- street food (bought from vendors with money) ----
    public static final RegistryObject<Item> HOT_DOG = ITEMS.register("hot_dog",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6F).build())));
    public static final RegistryObject<Item> PIZZA_SLICE = ITEMS.register("pizza_slice",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationMod(0.7F).build())));
    public static final RegistryObject<Item> BURGER = ITEMS.register("burger",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(10).saturationMod(0.8F).build())));
    public static final RegistryObject<Item> ENERGY_BAR = ITEMS.register("energy_bar",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.5F).fast().build())));
    public static final RegistryObject<Item> COFFEE = ITEMS.register("coffee",
            () -> new Item(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(2).saturationMod(0.2F)
                    .alwaysEat().effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 0), 1.0F).build())));

    public static final RegistryObject<Item> SPECIMEN_CASE =
            ITEMS.register("specimen_case", () -> new BlockItem(ModBlocks.SPECIMEN_CASE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CIVILIAN_SPAWN_EGG =
            ITEMS.register("civilian_spawn_egg",
                    () -> new ForgeSpawnEggItem(ModEntities.CIVILIAN, 0x4A90E2, 0xF5C16C, new Item.Properties()));

    /** Every piece of every suit (3 suits x 4 slots), registered as e.g. "classic_helmet", "symbiote_boots". */
    public static final List<RegistryObject<Item>> SUIT_PIECES = new ArrayList<>();

    static {
        for (SuitType suit : SuitType.values()) {
            for (ArmorItem.Type slot : ArmorItem.Type.values()) {
                String name = suit.id() + "_" + slot.getName();
                SUIT_PIECES.add(ITEMS.register(name, () -> new SpiderSuitItem(suit, slot, new Item.Properties())));
            }
        }
    }
}
