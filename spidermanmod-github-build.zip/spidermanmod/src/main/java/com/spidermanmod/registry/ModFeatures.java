package com.spidermanmod.registry;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, SpiderManMod.MODID);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> CITY_BLOCK =
            FEATURES.register("city_block", () -> new CityBlockFeature(NoneFeatureConfiguration.CODEC));
}
