package com.spidermanmod.quest;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.CivilianEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * What the spider bite gives you (passives): agility, strength, Spider-Sense warnings and dodges,
 * and the Hero Landing - fall from high up and slam down with a shockwave instead of taking damage.
 */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class PowerEvents {
    private static final double DODGE_CHANCE = 0.15;
    private static final UUID STRENGTH_ID = UUID.fromString("5b1c1f9e-7d57-4d3d-a0aa-1e6a0a5e11aa");
    private static final Map<UUID, Long> NEXT_SENSE = new ConcurrentHashMap<>();

    private static boolean hasPowers(ServerPlayer p) {
        return PlayerUpgrades.get(p).map(PlayerUpgrades::hasSpiderPowers).orElse(false);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player) || player.tickCount % 20 != 0) return;

        AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
        if (!hasPowers(player)) {
            if (attack != null && attack.getModifier(STRENGTH_ID) != null) attack.removeModifier(STRENGTH_ID);
            return;
        }

        // Enhanced strength + agility (hidden effects, no icons).
        if (attack != null && attack.getModifier(STRENGTH_ID) == null) {
            attack.addTransientModifier(new AttributeModifier(STRENGTH_ID, "Spider strength", 2.0, AttributeModifier.Operation.ADDITION));
        }
        player.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, 0, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0, true, false, false));

        // Spider-Sense: something hostile within 10 blocks is hunting you.
        long now = player.level().getGameTime();
        if (now < NEXT_SENSE.getOrDefault(player.getUUID(), 0L)) return;
        boolean danger = !player.serverLevel().getEntitiesOfClass(Monster.class,
                player.getBoundingBox().inflate(10.0), m -> m.getTarget() == player).isEmpty();
        if (danger) {
            NEXT_SENSE.put(player.getUUID(), now + 100);
            player.displayClientMessage(Component.translatable("message.spidermanmod.spider_sense")
                    .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
            player.level().playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.0F, 1.8F);
        }
    }

    /** Spider-Sense dodge: sometimes you simply aren't where the attack lands - and time seems to slow around you. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !hasPowers(player)) return;
        if (event.getSource().getEntity() == null || event.getSource().getEntity() == player) return;
        if (player.getRandom().nextDouble() < DODGE_CHANCE) {
            event.setCanceled(true);
            player.displayClientMessage(Component.translatable("message.spidermanmod.dodged"), true);
            for (Monster m : player.serverLevel().getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(8.0))) {
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1)); // "bullet-time" beat
            }
        }
    }

    /** Hero Landing. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !hasPowers(player)) return;

        float dist = event.getDistance();
        if (dist > 6.0F) {
            ServerLevel level = player.serverLevel();
            double radius = Math.min(8.0, 3.0 + dist * 0.2);
            float damage = Math.min(14.0F, dist * 0.5F);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                    t -> t != player && t.isAlive() && !(t instanceof CivilianEntity))) {
                e.hurt(player.damageSources().playerAttack(player), damage);
                Vec3 away = e.position().subtract(player.position());
                if (away.lengthSqr() > 1.0E-4) {
                    e.setDeltaMovement(away.normalize().scale(0.9).add(0, 0.4, 0));
                    e.hurtMarked = true;
                }
            }
            for (int i = 0; i < 28; i++) {
                double ang = i / 28.0 * Math.PI * 2;
                level.sendParticles(ParticleTypes.CLOUD, player.getX() + Math.cos(ang) * radius, player.getY() + 0.2,
                        player.getZ() + Math.sin(ang) * radius, 1, 0, 0, 0, 0);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.7F, 1.2F);
        }
        event.setCanceled(true); // spider-people land on their feet
    }
}
