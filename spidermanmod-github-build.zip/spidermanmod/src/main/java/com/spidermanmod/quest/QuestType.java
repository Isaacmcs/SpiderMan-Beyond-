package com.spidermanmod.quest;

/** What a quest asks of you. */
public enum QuestType {
    /** Kill {count} of the entity type {target} (e.g. spidermanmod:street_thug). */
    KILL,
    /** Defeat the boss {target}; it spawns in its arena when you get close. */
    BOSS,
    /** Chat with {count} civilians. */
    TALK,
    /** Buy {count} items from vendors. */
    BUY,
    /** Web-swing {count} blocks. */
    SWING,
    /** Reach height Y={count} in the city. */
    ALTITUDE
}
