package com.spidermanmod.quest;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.entity.SecurityGuardEntity;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.OpenDialoguePacket;
import com.spidermanmod.registry.ModDimensions;
import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The origin story - the first quest. Stored per player as PlayerUpgrades.originStage:
 *
 *  0 NOT_STARTED  intro dialogue (first time in the city dimension, or /spidey origin start)
 *  1 INFILTRATE   sneak into Helix Research Center AFTER DARK, go down the vault ladder, open the specimen case
 *  2 ESCAPE       alarm! guards hunt you. Get 70+ blocks away. (The spider is secretly on you.)
 *  3 GO_HOME      head back to the apartment (spawn intersection)
 *  4 REST         you get bitten on the way home and crush the spider. Sleep / wait for the next day.
 *  5 COMPLETE     you wake up with spider powers: wall climbing, spider-sense, agility.
 */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public final class OriginQuest {
    public static final int NOT_STARTED = 0;
    public static final int INFILTRATE = 1;
    public static final int ESCAPE = 2;
    public static final int GO_HOME = 3;
    public static final int REST = 4;
    public static final int COMPLETE = PlayerUpgrades.ORIGIN_COMPLETE;

    public static final BlockPos HOME = new BlockPos(1, CityBlockFeature.GROUND_Y + 1, 1);
    public static final double ESCAPE_DISTANCE = 70.0;
    public static final double HOME_RADIUS = 14.0;
    private static final int MAX_GUARDS = 4;

    private static final Map<UUID, Long> NEXT_GUARD_SPAWN = new ConcurrentHashMap<>();

    private OriginQuest() { }

    // ------------------------------------------------------------------ transitions

    public static void start(ServerPlayer player) {
        PlayerUpgrades.get(player).ifPresent(u -> {
            if (u.getOriginStage() != NOT_STARTED) return;
            u.setOriginStage(INFILTRATE);
            CapabilityEvents.sync(player);
            say(player, "origin.started");
        });
    }

    /** Called when a player right-clicks the Specimen Case in the vault. */
    public static void tryOpenCase(ServerPlayer player) {
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null) return;
        ServerLevel level = player.serverLevel();

        int stage = u.getOriginStage();
        if (stage == NOT_STARTED) { say(player, "origin.case_idle"); return; }
        if (stage != INFILTRATE) { say(player, "origin.case_empty"); return; }
        if (!isNight(level)) { say(player, "origin.case_locked"); return; }

        BlockPos c = CityBlockFeature.specimenCase();
        level.playSound(null, c, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F, 0.8F);
        level.sendParticles(ParticleTypes.CLOUD, c.getX() + 0.5, c.getY() + 0.8, c.getZ() + 0.5, 25, 0.3, 0.3, 0.3, 0.05);

        u.setOriginStage(ESCAPE);
        CapabilityEvents.sync(player);

        say(player, "origin.case_opened");   // the spider skitters away... (it's actually on you)
        say(player, "origin.alarm");
        title(player, "origin.title.alarm", "origin.title.alarm.sub", ChatFormatting.RED);

        for (SecurityGuardEntity g : level.getEntitiesOfClass(SecurityGuardEntity.class, new AABB(c).inflate(60.0))) {
            g.alert(player);
        }
        ensureGuards(level, player, true);
    }

    private static void bite(ServerPlayer player, PlayerUpgrades u) {
        ServerLevel level = player.serverLevel();
        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 0));
        level.playSound(null, player.blockPosition(), SoundEvents.SPIDER_HURT, SoundSource.PLAYERS, 1.0F, 1.2F);

        u.setOriginStage(REST);
        u.setOriginStamp(level.getDayTime() / 24000L);
        CapabilityEvents.sync(player);

        title(player, "origin.title.bite", "origin.title.bite.sub", ChatFormatting.DARK_GREEN);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenDialoguePacket(OpenDialoguePacket.ORIGIN_BITE));
    }

    private static void awaken(ServerPlayer player, PlayerUpgrades u) {
        u.setOriginStage(COMPLETE);
        u.setWallClimbUnlocked(true);
        u.addTokens(5);
        CapabilityEvents.sync(player);

        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 0.7F);
        title(player, "origin.title.awaken", "origin.title.awaken.sub", ChatFormatting.GOLD);
        say(player, "origin.powers");
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenDialoguePacket(OpenDialoguePacket.ORIGIN_AWAKEN));
    }

    // admin helpers (used by /spidey origin ...)
    public static void skip(ServerPlayer player) {
        PlayerUpgrades.get(player).ifPresent(u -> {
            u.setOriginStage(COMPLETE);
            u.setWallClimbUnlocked(true);
        });
        CapabilityEvents.sync(player);
    }

    public static void reset(ServerPlayer player) {
        PlayerUpgrades.get(player).ifPresent(u -> {
            u.setOriginStage(NOT_STARTED);
            u.setWallClimbUnlocked(false);
            u.setWallRunUnlocked(false);
        });
        CapabilityEvents.sync(player);
    }

    // ------------------------------------------------------------------ events

    /** First time in the city: the story begins. */
    @SubscribeEvent
    public static void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getTo() != ModDimensions.SPIDERMAN_CITY) return;
        PlayerUpgrades.get(player).ifPresent(u -> {
            if (u.getOriginStage() == NOT_STARTED) {
                CapabilityEvents.sync(player);
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenDialoguePacket(OpenDialoguePacket.ORIGIN_INTRO));
            }
        });
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player) || player.tickCount % 20 != 0) return;
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null) return;
        int stage = u.getOriginStage();
        if (stage <= NOT_STARTED || stage >= COMPLETE) return;

        ServerLevel level = player.serverLevel();
        boolean inCity = level.dimension() == ModDimensions.SPIDERMAN_CITY;

        switch (stage) {
            case INFILTRATE -> {
                if (inCity && distToCenter(player) < 60.0) ensureGuards(level, player, false);
            }
            case ESCAPE -> {
                if (!inCity) break;
                BlockPos center = CityBlockFeature.researchCenter();
                level.playSound(null, center, SoundEvents.BELL_BLOCK, SoundSource.HOSTILE, 4.0F, 0.6F); // alarm
                double d = distToCenter(player);
                if (d > ESCAPE_DISTANCE) {
                    u.setOriginStage(GO_HOME);
                    CapabilityEvents.sync(player);
                    say(player, "origin.escaped");
                } else if (d < 60.0) {
                    ensureGuards(level, player, false);
                }
            }
            case GO_HOME -> {
                double dx = player.getX() - (HOME.getX() + 0.5);
                double dz = player.getZ() - (HOME.getZ() + 0.5);
                if (inCity && Math.sqrt(dx * dx + dz * dz) <= HOME_RADIUS) bite(player, u);
            }
            case REST -> {
                if (level.getDayTime() / 24000L > u.getOriginStamp()) awaken(player, u);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void ensureGuards(ServerLevel level, ServerPlayer player, boolean force) {
        long now = level.getGameTime();
        if (!force && now < NEXT_GUARD_SPAWN.getOrDefault(player.getUUID(), 0L)) return;

        BlockPos ctr = CityBlockFeature.researchCenter();
        int have = level.getEntitiesOfClass(SecurityGuardEntity.class, new AABB(ctr).inflate(40.0)).size();
        for (int i = 0; i < CityBlockFeature.GUARD_SPAWNS.length && have < MAX_GUARDS; i++) {
            BlockPos pos = CityBlockFeature.guardSpawn(i);
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos).isAir()) continue;
            SecurityGuardEntity g = ModEntities.SECURITY_GUARD.get().create(level);
            if (g == null) continue;
            g.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.getRandom().nextFloat() * 360.0F, 0.0F);
            g.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
            if (force) g.alert(player);
            level.addFreshEntity(g);
            have++;
        }
        NEXT_GUARD_SPAWN.put(player.getUUID(), now + 600);
    }

    private static double distToCenter(ServerPlayer p) {
        BlockPos c = CityBlockFeature.researchCenter();
        double dx = p.getX() - (c.getX() + 0.5);
        double dz = p.getZ() - (c.getZ() + 0.5);
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Night = from dusk (13000) to just before dawn (23000). */
    public static boolean isNight(ServerLevel level) {
        long t = level.getDayTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    private static void say(ServerPlayer player, String key) {
        player.sendSystemMessage(Component.translatable(key).withStyle(ChatFormatting.ITALIC, ChatFormatting.GRAY));
    }

    private static void title(ServerPlayer player, String titleKey, String subKey, ChatFormatting color) {
        player.connection.send(new ClientboundSetTitlesAnimationPacket(8, 70, 20));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.translatable(titleKey).withStyle(color, ChatFormatting.BOLD)));
        player.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable(subKey).withStyle(ChatFormatting.GRAY)));
    }
}
