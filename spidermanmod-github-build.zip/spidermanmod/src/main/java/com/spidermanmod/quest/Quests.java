package com.spidermanmod.quest;

import com.spidermanmod.capability.PlayerUpgrades;

import java.util.List;

/** The mission list: a main story line of boss fights plus side jobs. */
public final class Quests {
    private static final String THUG = "spidermanmod:street_thug";

    public static final List<QuestDef> ALL = List.of(
            // ---------------- main story ----------------
            kill("m1_thugs", true, "Cleaning Up Chinatown",
                    "Crime is spiking in the district. Captain Watanabe wants the street thugs off the corners.",
                    THUG, 8, 250, 4, "origin"),
            boss("m2_rhino", "Horn of the Rhino",
                    "A heavily armoured brute is smashing through the docks. He charges in a straight line - sidestep and hit him when he stumbles.",
                    "spidermanmod:rhino", 600, 8, "m1_thugs", -8, 6),
            boss("m3_electro", "Power Surge",
                    "Someone is feeding off the city grid. Electro hurls lightning and blinks around. Close the gap, fast.",
                    "spidermanmod:electro", 700, 8, "m2_rhino", 7, -9),
            boss("m4_vulture", "Wings Over the City",
                    "A flying thief is dive-bombing rooftops. Wait for the dive, then strike when he recovers.",
                    "spidermanmod:vulture", 800, 10, "m3_electro", -9, -8),
            boss("m5_octopus", "Eight Arms",
                    "A scientist with four mechanical arms is tearing up a tech park. Watch for the slam markers and the grab.",
                    "spidermanmod:doctor_octopus", 1000, 12, "m4_vulture", 11, 3),
            boss("m6_goblin", "Pumpkin Night",
                    "The Green Goblin is back, raining bombs from the sky. Stay moving.",
                    "spidermanmod:green_goblin", 1200, 15, "m5_octopus", 0, 12),
            boss("m7_kingpin", "The Big Man",
                    "The man behind all of it. He calls for backup as he weakens. End it.",
                    "spidermanmod:kingpin", 2500, 25, "m6_goblin", -12, 0),

            // ---------------- side jobs ----------------
            kill("s1_watch", false, "Neighborhood Watch", "Take down 12 thugs hassling civilians.", THUG, 12, 150, 2, "origin"),
            simple("s2_chat", "Friendly Neighborhood", "Say hello to 4 civilians. People like seeing their hero.",
                    QuestType.TALK, 4, 60, 1),
            simple("s3_lunch", "Lunch Break", "Even heroes get hungry. Buy 2 items from street vendors.",
                    QuestType.BUY, 2, 20, 3),
            simple("s4_commute", "Web-Slinger's Commute", "Swing 800 blocks across the city.",
                    QuestType.SWING, 800, 120, 3),
            simple("s5_rooftops", "Rooftop View", "Climb or swing above Y=150 in the city.",
                    QuestType.ALTITUDE, 150, 100, 2),
            kill("s6_backinbusiness", false, "Back in Business", "Clear out 25 more thugs once the first wave is down.",
                    THUG, 25, 400, 6, "m1_thugs"));

    private Quests() { }

    private static QuestDef kill(String id, boolean main, String title, String desc, String target, int count,
                                 int money, int tokens, String requires) {
        return new QuestDef(id, main, title, desc, QuestType.KILL, target, count, money, tokens, requires, 0, 0);
    }

    private static QuestDef boss(String id, String title, String desc, String target, int money, int tokens,
                                 String requires, int chunkX, int chunkZ) {
        return new QuestDef(id, true, title, desc, QuestType.BOSS, target, 1, money, tokens, requires, chunkX, chunkZ);
    }

    private static QuestDef simple(String id, String title, String desc, QuestType type, int count, int money, int tokens) {
        return new QuestDef(id, false, title, desc, type, "", count, money, tokens, "origin", 0, 0);
    }

    public static QuestDef byId(String id) {
        for (QuestDef d : ALL) {
            if (d.id().equals(id)) return d;
        }
        return null;
    }

    public static boolean prerequisiteMet(QuestDef d, PlayerUpgrades u) {
        if (d.requires().isEmpty()) return true;
        if (d.requires().equals("origin")) return u.hasSpiderPowers();
        return u.getQuestState(d.requires()) == PlayerUpgrades.QUEST_DONE;
    }

    /** Not taken yet and its prerequisite is finished. */
    public static boolean isAvailable(QuestDef d, PlayerUpgrades u) {
        return u.getQuestState(d.id()) == 0 && prerequisiteMet(d, u);
    }
}
