package com.spidermanmod.quest;

import com.spidermanmod.world.CityBlockFeature;
import net.minecraft.core.BlockPos;

/**
 * One mission.
 *
 * @param requires  "" (none), "origin" (spider powers) or the id of a quest that must be finished first
 * @param arenaChunkX/arenaChunkZ  boss quests only: the chunk whose road intersection is the boss arena
 */
public record QuestDef(String id, boolean main, String title, String description, QuestType type, String target,
                       int count, int rewardMoney, int rewardTokens, String requires, int arenaChunkX, int arenaChunkZ) {

    /** Boss arena = the street intersection at the corner of that chunk (always open asphalt). */
    public BlockPos arena() {
        return new BlockPos(arenaChunkX * 16 + 1, CityBlockFeature.GROUND_Y + 1, arenaChunkZ * 16 + 1);
    }

    public String objective() {
        return switch (type) {
            case KILL -> "Defeat " + count + " " + prettyTarget();
            case BOSS -> "Defeat " + prettyTarget();
            case TALK -> "Chat with " + count + " civilians";
            case BUY -> "Buy " + count + " items from vendors";
            case SWING -> "Web-swing " + count + " blocks";
            case ALTITUDE -> "Reach height Y=" + count + " in the city";
        };
    }

    private String prettyTarget() {
        String name = target.contains(":") ? target.substring(target.indexOf(':') + 1) : target;
        StringBuilder sb = new StringBuilder();
        for (String part : name.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
