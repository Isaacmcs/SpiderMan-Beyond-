package com.spidermanmod.quest;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.registry.ModDimensions;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Server-side quest log logic: accepting, tracking progress, completing, and spawning bosses in their arenas. */
public final class QuestManager {
    private static final int MAX_ACTIVE_SIDE = 3;
    private static final Map<String, Long> NEXT_BOSS_SPAWN = new ConcurrentHashMap<>();

    private QuestManager() { }

    public static void accept(ServerPlayer player, String id) {
        QuestDef d = Quests.byId(id);
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (d == null || u == null) return;

        if (!Quests.isAvailable(d, u)) {
            say(player, "That mission isn't available.", ChatFormatting.RED);
            return;
        }
        int activeSide = 0;
        for (QuestDef o : Quests.ALL) {
            if (u.getQuestState(o.id()) != PlayerUpgrades.QUEST_ACTIVE) continue;
            if (d.main() && o.main()) {
                say(player, "Finish your current story mission first: " + o.title(), ChatFormatting.RED);
                return;
            }
            if (!d.main() && !o.main()) activeSide++;
        }
        if (!d.main() && activeSide >= MAX_ACTIVE_SIDE) {
            say(player, "You can only have " + MAX_ACTIVE_SIDE + " side jobs at once.", ChatFormatting.RED);
            return;
        }

        u.setQuest(d.id(), PlayerUpgrades.QUEST_ACTIVE, 0);
        CapabilityEvents.sync(player);
        player.sendSystemMessage(Component.literal("Mission accepted: ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(d.title()).withStyle(ChatFormatting.WHITE))
                .append(Component.literal("  -  " + d.objective()).withStyle(ChatFormatting.GRAY)));
        if (d.type() == QuestType.BOSS) {
            BlockPos a = d.arena();
            player.sendSystemMessage(Component.literal("The target is at about X " + a.getX() + ", Z " + a.getZ()
                    + " in the city. Follow the tracker in the top-left.").withStyle(ChatFormatting.ITALIC, ChatFormatting.GRAY));
        }
    }

    /** Adds progress to every active quest of this type whose target matches ("" matches anything). */
    public static void progress(ServerPlayer player, QuestType type, String target, int amount) {
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null || amount <= 0) return;

        boolean changed = false;
        for (QuestDef d : Quests.ALL) {
            if (d.type() != type || u.getQuestState(d.id()) != PlayerUpgrades.QUEST_ACTIVE) continue;
            if (!d.target().isEmpty() && !d.target().equals(target)) continue;

            int now = Math.min(d.count(), u.getQuestProgress(d.id()) + amount);
            u.setQuest(d.id(), PlayerUpgrades.QUEST_ACTIVE, now);
            changed = true;
            if (now >= d.count()) complete(player, u, d);
        }
        if (changed) CapabilityEvents.sync(player);
    }

    public static void complete(ServerPlayer player, PlayerUpgrades u, QuestDef d) {
        u.setQuest(d.id(), PlayerUpgrades.QUEST_DONE, d.count());
        u.addMoney(d.rewardMoney());
        u.addTokens(d.rewardTokens());
        CapabilityEvents.sync(player);

        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.connection.send(new ClientboundSetTitlesAnimationPacket(8, 60, 20));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.literal(d.main() ? "MISSION COMPLETE" : "JOB DONE")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)));
        player.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(d.title()).withStyle(ChatFormatting.GRAY)));
        player.sendSystemMessage(Component.literal("Reward: $" + d.rewardMoney() + " and " + d.rewardTokens() + " Hero Tokens.")
                .withStyle(ChatFormatting.YELLOW));
    }

    /** Boss quests: when you get near the arena and the boss isn't there, it appears. */
    public static void tickArenas(ServerPlayer player, PlayerUpgrades u) {
        ServerLevel level = player.serverLevel();
        if (level.dimension() != ModDimensions.SPIDERMAN_CITY) return;

        for (QuestDef d : Quests.ALL) {
            if (d.type() != QuestType.BOSS || u.getQuestState(d.id()) != PlayerUpgrades.QUEST_ACTIVE) continue;
            BlockPos a = d.arena();
            double dx = player.getX() - a.getX();
            double dz = player.getZ() - a.getZ();
            if (dx * dx + dz * dz > 80.0 * 80.0 || !level.hasChunkAt(a)) continue;

            ResourceLocation key = new ResourceLocation(d.target());
            boolean present = !level.getEntitiesOfClass(Mob.class, new AABB(a).inflate(110.0),
                    m -> key.equals(ForgeRegistries.ENTITY_TYPES.getKey(m.getType()))).isEmpty();
            if (present) continue;

            String cooldownKey = player.getUUID() + ":" + d.id();
            long now = level.getGameTime();
            if (now < NEXT_BOSS_SPAWN.getOrDefault(cooldownKey, 0L)) continue;
            NEXT_BOSS_SPAWN.put(cooldownKey, now + 600);

            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(key);
            if (type == null) continue;
            Entity e = type.create(level);
            if (!(e instanceof Mob boss)) continue;
            boolean flying = d.target().endsWith("vulture") || d.target().endsWith("green_goblin");
            boss.moveTo(a.getX() + 0.5, a.getY() + (flying ? 10 : 0), a.getZ() + 0.5, level.getRandom().nextFloat() * 360.0F, 0.0F);
            boss.finalizeSpawn(level, level.getCurrentDifficultyAt(a), MobSpawnType.EVENT, null, null);
            level.addFreshEntity(boss);
            boss.setTarget(player);
            say(player, "A boss has appeared nearby!", ChatFormatting.RED);
        }
    }

    private static void say(ServerPlayer player, String text, ChatFormatting color) {
        player.sendSystemMessage(Component.literal(text).withStyle(color));
    }
}
