package com.spidermanmod.quest;

import com.spidermanmod.SpiderManMod;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.registry.ModDimensions;
import com.spidermanmod.swing.SwingTracker;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Feeds game events into the quest log. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public class QuestEvents {
    private static final Map<UUID, Vec3> LAST_POS = new ConcurrentHashMap<>();
    private static final Map<UUID, Double> SWING_ACC = new ConcurrentHashMap<>();

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(event.getEntity().getType());
        if (key == null) return;
        QuestManager.progress(player, QuestType.KILL, key.toString(), 1);
        QuestManager.progress(player, QuestType.BOSS, key.toString(), 1);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;

        // swing distance (every tick)
        Vec3 now = player.position();
        Vec3 last = LAST_POS.put(player.getUUID(), now);
        if (last != null && SwingTracker.isSwinging(player)) {
            double acc = SWING_ACC.merge(player.getUUID(), Math.min(3.0, now.distanceTo(last)), Double::sum);
            if (acc >= 1.0) {
                SWING_ACC.put(player.getUUID(), acc - Math.floor(acc));
                QuestManager.progress(player, QuestType.SWING, "", (int) Math.floor(acc));
            }
        }

        if (player.tickCount % 20 != 0) return;
        PlayerUpgrades u = PlayerUpgrades.get(player).orElse(null);
        if (u == null || !u.hasSpiderPowers()) return;

        // altitude quests
        if (player.level().dimension() == ModDimensions.SPIDERMAN_CITY) {
            for (QuestDef d : Quests.ALL) {
                if (d.type() == QuestType.ALTITUDE && u.getQuestState(d.id()) == PlayerUpgrades.QUEST_ACTIVE
                        && player.getY() >= d.count()) {
                    QuestManager.complete(player, u, d);
                }
            }
        }
        QuestManager.tickArenas(player, u);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        LAST_POS.remove(event.getEntity().getUUID());
        SWING_ACC.remove(event.getEntity().getUUID());
    }
}
