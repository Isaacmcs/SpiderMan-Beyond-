package com.spidermanmod.entity;

import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Thrown web blob: knocks the target back and pins it with a temporary cobweb at its feet. */
public class ImpactWebEntity extends ThrowableItemProjectile {
    public static final int WEB_LIFETIME_TICKS = 100; // 5 seconds

    public ImpactWebEntity(EntityType<? extends ImpactWebEntity> type, Level level) {
        super(type, level);
    }

    public ImpactWebEntity(Level level, LivingEntity owner) {
        super(ModEntities.IMPACT_WEB.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.IMPACT_WEB.get();
    }

    @Override
    protected float getGravity() {
        return 0.015F;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide || !(result.getEntity() instanceof LivingEntity target)) return;

        target.hurt(damageSources().thrown(this, getOwner()), 1.0F);

        Vec3 motion = getDeltaMovement();
        target.knockback(0.9, -motion.x, -motion.z); // pushes the target along the throw direction

        BlockPos feet = target.blockPosition();
        BlockState state = level().getBlockState(feet);
        if (state.isAir() || state.canBeReplaced()) {
            level().setBlockAndUpdate(feet, Blocks.COBWEB.defaultBlockState());
            TempWebManager.schedule((ServerLevel) level(), feet, WEB_LIFETIME_TICKS);
        }
    }

    /** Splats a temporary web onto the face that was hit. */
    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (level().isClientSide) return;
        BlockPos pos = result.getBlockPos().relative(result.getDirection());
        if (level().getBlockState(pos).isAir()) {
            level().setBlockAndUpdate(pos, Blocks.COBWEB.defaultBlockState());
            TempWebManager.schedule((ServerLevel) level(), pos, WEB_LIFETIME_TICKS);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.ITEM_SNOWBALL,
                    getX(), getY(), getZ(), 8, 0.2, 0.2, 0.2, 0.02);
            discard();
        }
    }
}
