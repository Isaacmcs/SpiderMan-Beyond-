package com.spidermanmod.entity;

import com.spidermanmod.SpiderManMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Removes the cobwebs spawned by Impact Webs after a short time. */
@Mod.EventBusSubscriber(modid = SpiderManMod.MODID)
public final class TempWebManager {
    private record Entry(ResourceKey<Level> dimension, BlockPos pos, int expireTick) { }

    private static final List<Entry> ENTRIES = new ArrayList<>();

    private TempWebManager() { }

    public static void schedule(ServerLevel level, BlockPos pos, int lifetimeTicks) {
        ENTRIES.add(new Entry(level.dimension(), pos.immutable(), level.getServer().getTickCount() + lifetimeTicks));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ENTRIES.isEmpty()) return;
        MinecraftServer server = event.getServer();
        int now = server.getTickCount();
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (now >= e.expireTick()) {
                removeWeb(server, e);
                it.remove();
            }
        }
    }

    /** Don't leave webs behind in the world when the server shuts down. */
    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        for (Entry e : ENTRIES) {
            removeWeb(event.getServer(), e);
        }
        ENTRIES.clear();
    }

    private static void removeWeb(MinecraftServer server, Entry e) {
        ServerLevel level = server.getLevel(e.dimension());
        if (level != null && level.getBlockState(e.pos()).is(Blocks.COBWEB)) {
            level.removeBlock(e.pos(), false);
        }
    }
}
