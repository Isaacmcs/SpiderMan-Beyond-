package com.spidermanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Electro: shoots lightning arcs, discharges a shock pulse when you get close, and blinks away when pressed. */
public class ElectroEntity extends VillainBoss {
    public ElectroEntity(EntityType<? extends ElectroEntity> type, Level level) {
        super(type, level, BossEvent.BossBarColor.BLUE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return bossAttributes(180.0, 4.0, 6.0, 0.3);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new LightningGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypes.LIGHTNING_BOLT)) return false; // he IS the lightning
        return super.hurt(source, amount);
    }

    private static class LightningGoal extends Goal {
        private final ElectroEntity electro;
        private int nextBolt = 60;
        private int nextPulse = 40;
        private int nextBlink = 140;

        LightningGoal(ElectroEntity electro) {
            this.electro = electro;
            setFlags(EnumSet.of(Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return electro.getTarget() != null;
        }

        @Override
        public void tick() {
            LivingEntity target = electro.getTarget();
            if (target == null) return;
            ServerLevel level = (ServerLevel) electro.level();
            electro.getLookControl().setLookAt(target, 40.0F, 40.0F);
            double d = electro.distanceTo(target);
            int t = electro.tickCount;

            if (d < 4.5 && t >= nextPulse) { // overload pulse
                electro.shockRing(level, electro.position(), 5.0, 6.0F, 1.3, ParticleTypes.ELECTRIC_SPARK);
                electro.playSound(SoundEvents.TRIDENT_THUNDER, 1.2F, 1.2F);
                nextPulse = t + 60;
            } else if (d < 26.0 && electro.hasLineOfSight(target) && t >= nextBolt) { // lightning arc
                Vec3 from = electro.getEyePosition();
                Vec3 to = target.position().add(0, target.getBbHeight() * 0.5, 0);
                int steps = (int) Math.max(4, from.distanceTo(to) * 2);
                for (int i = 0; i <= steps; i++) {
                    Vec3 p = from.lerp(to, i / (double) steps);
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.08, 0.08, 0.08, 0.0);
                }
                target.hurt(electro.damageSources().lightningBolt(), 7.0F);
                electro.playSound(SoundEvents.LIGHTNING_BOLT_IMPACT, 0.7F, 1.4F);
                nextBolt = t + 35;
            }

            if (t >= nextBlink && electro.hurtTime > 0) { // blink when pressed
                double bx = target.getX() + (electro.getRandom().nextDouble() - 0.5) * 14.0;
                double bz = target.getZ() + (electro.getRandom().nextDouble() - 0.5) * 14.0;
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, electro.getX(), electro.getY() + 1, electro.getZ(), 20, 0.4, 0.8, 0.4, 0.3);
                if (electro.randomTeleport(bx, target.getY(), bz, true)) {
                    electro.playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.6F);
                }
                nextBlink = t + 120;
            }
        }
    }
}
