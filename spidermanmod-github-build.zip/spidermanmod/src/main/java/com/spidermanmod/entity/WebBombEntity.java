package com.spidermanmod.entity;

import com.spidermanmod.registry.ModEntities;
import com.spidermanmod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Bursts into a ball of temporary cobwebs and slows every living thing nearby. */
public class WebBombEntity extends ThrowableItemProjectile {
    private static final int WEB_LIFETIME_TICKS = 140; // 7 seconds
    private static final double EFFECT_RADIUS = 4.0;

    public WebBombEntity(EntityType<? extends WebBombEntity> type, Level level) {
        super(type, level);
    }

    public WebBombEntity(Level level, LivingEntity owner) {
        super(ModEntities.WEB_BOMB.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.WEB_BOMB.get();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide) return;

        ServerLevel sl = (ServerLevel) level();
        Vec3 c = result.getLocation();
        BlockPos center = BlockPos.containing(c);

        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx * dx + dy * dy + dz * dz > 5) continue; // rough sphere
                    BlockPos bp = center.offset(dx, dy, dz);
                    if (sl.getBlockState(bp).isAir()) {
                        sl.setBlockAndUpdate(bp, Blocks.COBWEB.defaultBlockState());
                        TempWebManager.schedule(sl, bp, WEB_LIFETIME_TICKS);
                    }
                }
            }
        }

        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(center).inflate(EFFECT_RADIUS),
                t -> t != getOwner() && t.isAlive())) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
            e.hurt(damageSources().thrown(this, getOwner()), 2.0F);
        }

        sl.sendParticles(ParticleTypes.ITEM_SNOWBALL, c.x, c.y, c.z, 40, 1.2, 0.8, 1.2, 0.05);
        sl.playSound(null, center, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.0F, 0.7F);
        discard();
    }
}
