package com.spidermanmod.entity;

import com.spidermanmod.registry.ModEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

/** Goblin's pumpkin bomb: a non-block-breaking explosion on impact. */
public class PumpkinBombEntity extends ThrowableItemProjectile {
    public static final float EXPLOSION_POWER = 2.5F;

    public PumpkinBombEntity(EntityType<? extends PumpkinBombEntity> type, Level level) {
        super(type, level);
    }

    public PumpkinBombEntity(Level level, LivingEntity owner) {
        super(ModEntities.PUMPKIN_BOMB.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.JACK_O_LANTERN;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount > 200) {
            discard();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            level().explode(this, getX(), getY(), getZ(), EXPLOSION_POWER, Level.ExplosionInteraction.NONE);
            discard();
        }
    }
}
