package com.spidermanmod.entity;

import com.spidermanmod.capability.CapabilityEvents;
import com.spidermanmod.capability.PlayerUpgrades;
import com.spidermanmod.event.SpideyVoiceEventHandler;
import com.spidermanmod.network.ModNetwork;
import com.spidermanmod.network.OpenDialoguePacket;
import com.spidermanmod.quest.QuestManager;
import com.spidermanmod.quest.QuestType;
import com.spidermanmod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.Locale;

/**
 * City civilian with a role:
 *  PEDESTRIAN - strolls.  JOGGER - jogs about quickly.  VENDOR - stays put and sells you street food.
 *  TOURIST - slow stroller with a map.  PHOTOGRAPHER - follows "Spidey" at a distance snapping photos.
 * All of them flee monsters (and the Green Goblin) and panic when hurt. Chatting while "Spidey"
 * (holding the Web Shooter / wearing a suit piece / having powers) earns +1 Hero Token once per civilian.
 */
public class CivilianEntity extends PathfinderMob {
    public enum Role {
        PEDESTRIAN, JOGGER, VENDOR, TOURIST, PHOTOGRAPHER;

        public String id() { return name().toLowerCase(Locale.ROOT); }
    }

    public static final int VARIANTS = 16;
    private static final int LINES = 5;
    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(CivilianEntity.class, EntityDataSerializers.INT);

    private Role role = Role.PEDESTRIAN;
    private boolean thanked;
    private boolean gifted;
    private int chatCooldown;

    public CivilianEntity(EntityType<? extends CivilianEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.26);
    }

    /** Spawns one civilian standing at the given block position. */
    public static CivilianEntity spawnAt(ServerLevel level, BlockPos pos) {
        CivilianEntity c = ModEntities.CIVILIAN.get().create(level);
        if (c == null) return null;
        c.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.getRandom().nextFloat() * 360.0F, 0.0F);
        c.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.NATURAL, null, null);
        level.addFreshEntity(c);
        return c;
    }

    public Role getRole() {
        return role == null ? Role.PEDESTRIAN : role;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.6));
        goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Monster.class, 14.0F, 1.0, 1.4));
        goalSelector.addGoal(4, new PhotographerGoal());
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8) {
            @Override
            public boolean canUse() {
                Role r = getRole();
                return (r == Role.PEDESTRIAN || r == Role.TOURIST) && super.canUse();
            }
        });
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.3) {
            @Override
            public boolean canUse() {
                return getRole() == Role.JOGGER && super.canUse();
            }
        });
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    // ---- appearance / setup ----
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(entityData.get(DATA_VARIANT), VARIANTS);
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag tag) {
        entityData.set(DATA_VARIANT, random.nextInt(VARIANTS));

        int r = random.nextInt(100);
        role = r < 45 ? Role.PEDESTRIAN : r < 60 ? Role.JOGGER : r < 72 ? Role.VENDOR : r < 87 ? Role.TOURIST : Role.PHOTOGRAPHER;
        switch (role) {
            case VENDOR -> setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BREAD));
            case TOURIST -> setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MAP));
            case PHOTOGRAPHER -> setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.SPYGLASS));
            default -> { }
        }
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        return super.finalizeSpawn(level, difficulty, reason, spawnData, tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", entityData.get(DATA_VARIANT));
        tag.putInt("Role", getRole().ordinal());
        tag.putBoolean("Thanked", thanked);
        tag.putBoolean("Gifted", gifted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_VARIANT, tag.getInt("Variant"));
        role = Role.values()[Mth.clamp(tag.getInt("Role"), 0, Role.values().length - 1)];
        thanked = tag.getBoolean("Thanked");
        gifted = tag.getBoolean("Gifted");
    }

    // ---- interaction ----
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (chatCooldown > 0) chatCooldown--;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;

        if (!level().isClientSide && player instanceof ServerPlayer sp && chatCooldown <= 0) {
            chatCooldown = 40;
            boolean hero = SpideyVoiceEventHandler.isSpidey(sp)
                    || PlayerUpgrades.get(sp).map(PlayerUpgrades::hasSpiderPowers).orElse(false);

            String key;
            if (hero) {
                key = "civilian.spidermanmod.hero." + random.nextInt(LINES);
            } else if (getRole() != Role.PEDESTRIAN && random.nextBoolean()) {
                key = "civilian.spidermanmod.role." + getRole().id() + "." + random.nextInt(3);
            } else {
                key = "civilian.spidermanmod.line." + random.nextInt(LINES);
            }
            sp.sendSystemMessage(Component.translatable("message.spidermanmod.civilian_say", Component.translatable(key)));
            playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.0F);

            QuestManager.progress(sp, QuestType.TALK, "", 1);
            if (getRole() == Role.VENDOR) { // street food costs money
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new OpenDialoguePacket(OpenDialoguePacket.SHOP));
            }
            if (hero && !thanked) {
                thanked = true;
                PlayerUpgrades.get(sp).ifPresent(u -> u.addTokens(1));
                CapabilityEvents.sync(sp);
                ((ServerLevel) level()).sendParticles(ParticleTypes.HAPPY_VILLAGER,
                        getX(), getY() + 1.2, getZ(), 8, 0.3, 0.4, 0.3, 0.0);
                sp.displayClientMessage(Component.translatable("message.spidermanmod.tokens_gained", 1), true);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return true;
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.VILLAGER_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.VILLAGER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.VILLAGER_DEATH; }

    /** Photographers trail a nearby "Spidey" at a distance and snap pictures. */
    private class PhotographerGoal extends Goal {
        private Player target;
        private int snapTimer;

        PhotographerGoal() {
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        private boolean isHero(Player p) {
            return p instanceof ServerPlayer sp && (SpideyVoiceEventHandler.isSpidey(sp)
                    || PlayerUpgrades.get(sp).map(PlayerUpgrades::hasSpiderPowers).orElse(false));
        }

        @Override
        public boolean canUse() {
            if (getRole() != Role.PHOTOGRAPHER) return false;
            Player p = level().getNearestPlayer(CivilianEntity.this, 12.0);
            if (p == null || !isHero(p)) return false;
            target = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && distanceToSqr(target) < 196.0 && isHero(target);
        }

        @Override
        public void start() {
            snapTimer = 20;
        }

        @Override
        public void tick() {
            getLookControl().setLookAt(target, 30.0F, 30.0F);
            if (distanceToSqr(target) > 36.0) {
                getNavigation().moveTo(target, 1.0);
            } else {
                getNavigation().stop();
            }
            if (--snapTimer <= 0) {
                snapTimer = 50 + random.nextInt(40);
                playSound(SoundEvents.TRIPWIRE_CLICK_ON, 1.0F, 1.6F);
                if (level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.FLASH, getX(), getEyeY(), getZ(), 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
        }

        @Override
        public void stop() {
            target = null;
            getNavigation().stop();
        }
    }
}
