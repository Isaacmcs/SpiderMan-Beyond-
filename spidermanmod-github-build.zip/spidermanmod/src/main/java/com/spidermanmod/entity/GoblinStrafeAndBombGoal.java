package com.spidermanmod.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Orbit ~6 blocks above the target and drop a Pumpkin Bomb every 50 ticks (2.5 s). */
public class GoblinStrafeAndBombGoal extends Goal {
    private static final double HOVER_HEIGHT = 6.0;
    private static final double ORBIT_RADIUS = 8.0;
    private static final double ORBIT_SPEED = 0.06; // radians / tick
    private static final int BOMB_INTERVAL = 50;

    private final GreenGoblinEntity goblin;
    private double angle;
    private int bombTimer;

    public GoblinStrafeAndBombGoal(GreenGoblinEntity goblin) {
        this.goblin = goblin;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = goblin.getTarget();
        return target != null && target.isAlive();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        angle = goblin.getRandom().nextDouble() * Math.PI * 2;
        bombTimer = BOMB_INTERVAL;
    }

    @Override
    public void tick() {
        LivingEntity target = goblin.getTarget();
        if (target == null) return;

        angle += ORBIT_SPEED;
        Vec3 desired = new Vec3(
                target.getX() + Math.cos(angle) * ORBIT_RADIUS,
                target.getY() + HOVER_HEIGHT,
                target.getZ() + Math.sin(angle) * ORBIT_RADIUS);

        Vec3 delta = desired.subtract(goblin.position());
        Vec3 push = delta.scale(0.12);
        double len = push.length();
        if (len > 0.7) push = push.scale(0.7 / len);
        goblin.setDeltaMovement(goblin.getDeltaMovement().scale(0.5).add(push.scale(0.6)));
        goblin.getLookControl().setLookAt(target, 30.0F, 30.0F);

        if (--bombTimer <= 0) {
            bombTimer = BOMB_INTERVAL;
            dropBomb(target);
        }
    }

    private void dropBomb(LivingEntity target) {
        PumpkinBombEntity bomb = new PumpkinBombEntity(goblin.level(), goblin);
        bomb.setPos(goblin.getX(), goblin.getY() + 0.5, goblin.getZ());

        // Lead the target a little so the bombs rain around it instead of behind it.
        Vec3 aim = target.position().add(target.getDeltaMovement().scale(8)).add(0, target.getBbHeight() * 0.5, 0);
        Vec3 dir = aim.subtract(bomb.position());
        bomb.shoot(dir.x, dir.y, dir.z, 0.9F, 3.0F);
        goblin.level().addFreshEntity(bomb);
    }
}
