package com.spidermanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.EnumSet;

/** Kingpin: the final boss. Huge, tanky, slams the ground, and calls for thugs at 75%, 50% and 25% health. */
public class KingpinEntity extends VillainBoss {
    private int phase;

    public KingpinEntity(EntityType<? extends KingpinEntity> type, Level level) {
        super(type, level, BossEvent.BossBarColor.PURPLE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return bossAttributes(400.0, 12.0, 14.0, 0.25).add(Attributes.KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new SlamGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        float frac = getHealth() / getMaxHealth();
        int due = frac <= 0.25F ? 3 : frac <= 0.5F ? 2 : frac <= 0.75F ? 1 : 0;
        while (phase < due) {
            phase++;
            summonThugs(2);
            if (level() instanceof ServerLevel sl) {
                for (ServerPlayer p : sl.players()) {
                    if (p.distanceToSqr(this) < 50.0 * 50.0) {
                        p.sendSystemMessage(Component.literal("<Kingpin> Boys! Get in here!"));
                    }
                }
            }
        }
    }

    private static class SlamGoal extends Goal {
        private final KingpinEntity boss;
        private int next = 80;

        SlamGoal(KingpinEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return boss.getTarget() != null;
        }

        @Override
        public void tick() {
            LivingEntity target = boss.getTarget();
            if (target == null || boss.tickCount < next || boss.distanceTo(target) > 5.0) return;
            ServerLevel level = (ServerLevel) boss.level();
            boss.shockRing(level, boss.position(), 4.5, 8.0F, 1.2, ParticleTypes.EXPLOSION);
            boss.playSound(SoundEvents.IRON_GOLEM_ATTACK, 2.0F, 0.5F);
            next = boss.tickCount + 90;
        }
    }
}
