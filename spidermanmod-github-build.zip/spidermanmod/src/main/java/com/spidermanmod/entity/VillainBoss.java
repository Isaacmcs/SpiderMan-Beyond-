package com.spidermanmod.entity;

import com.spidermanmod.registry.ModEntities;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** Shared plumbing for the supervillains: boss bar, persistence and an area-shock helper. */
public abstract class VillainBoss extends Monster {
    private final ServerBossEvent bossEvent;

    protected VillainBoss(EntityType<? extends VillainBoss> type, Level level, BossEvent.BossBarColor color) {
        super(type, level);
        this.bossEvent = new ServerBossEvent(getDisplayName(), color, BossEvent.BossBarOverlay.PROGRESS);
        setPersistenceRequired();
        xpReward = 150;
    }

    protected static AttributeSupplier.Builder bossAttributes(double health, double armor, double damage, double speed) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ARMOR, armor)
                .add(Attributes.ATTACK_DAMAGE, damage)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    /** Damages and launches everything non-hostile within {@code radius} of {@code center}, with a particle ring. */
    protected void shockRing(ServerLevel level, Vec3 center, double radius, float damage, double knock, ParticleOptions particle) {
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(radius),
                t -> t != this && !(t instanceof Monster) && t.isAlive())) {
            e.hurt(damageSources().mobAttack(this), damage);
            Vec3 away = e.position().subtract(center);
            if (away.lengthSqr() > 1.0E-4) {
                e.setDeltaMovement(away.normalize().scale(knock).add(0, 0.4, 0));
                e.hurtMarked = true;
            }
        }
        for (int i = 0; i < 28; i++) {
            double ang = i / 28.0 * Math.PI * 2;
            level.sendParticles(particle, center.x + Math.cos(ang) * radius, center.y + 0.2,
                    center.z + Math.sin(ang) * radius, 1, 0, 0, 0, 0);
        }
    }

    /** Spawns two street thugs next to the boss (used by Kingpin's phases). */
    protected void summonThugs(int count) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (int i = 0; i < count; i++) {
            StreetThugEntity t = ModEntities.STREET_THUG.get().create(sl);
            if (t == null) continue;
            t.moveTo(getX() + (random.nextDouble() - 0.5) * 6, getY(), getZ() + (random.nextDouble() - 0.5) * 6,
                    random.nextFloat() * 360.0F, 0.0F);
            t.finalizeSpawn(sl, sl.getCurrentDifficultyAt(blockPosition()), net.minecraft.world.entity.MobSpawnType.EVENT, null, null);
            if (getTarget() != null) t.setTarget(getTarget());
            sl.addFreshEntity(t);
        }
    }
}
