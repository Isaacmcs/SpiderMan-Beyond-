package com.spidermanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Doctor Octopus: marks a spot with crit particles, then slams it with his tentacles (move out!),
 * and yanks you toward him from a distance.
 */
public class DoctorOctopusEntity extends VillainBoss {
    public DoctorOctopusEntity(EntityType<? extends DoctorOctopusEntity> type, Level level) {
        super(type, level, BossEvent.BossBarColor.GREEN);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return bossAttributes(240.0, 6.0, 9.0, 0.24);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new TentacleGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    private static class TentacleGoal extends Goal {
        private final DoctorOctopusEntity boss;
        private int nextSlam = 60;
        private int nextGrab = 100;
        private int slamAt = -1;
        private Vec3 slamPos = Vec3.ZERO;

        TentacleGoal(DoctorOctopusEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return boss.getTarget() != null;
        }

        @Override
        public void tick() {
            LivingEntity target = boss.getTarget();
            if (target == null) return;
            ServerLevel level = (ServerLevel) boss.level();
            boss.getLookControl().setLookAt(target, 40.0F, 40.0F);
            int t = boss.tickCount;
            double d = boss.distanceTo(target);

            if (slamAt >= 0) { // telegraph, then slam
                for (int i = 0; i < 10; i++) {
                    double ang = i / 10.0 * Math.PI * 2;
                    level.sendParticles(ParticleTypes.CRIT, slamPos.x + Math.cos(ang) * 4.0, slamPos.y + 0.2,
                            slamPos.z + Math.sin(ang) * 4.0, 1, 0, 0, 0, 0);
                }
                if (t >= slamAt) {
                    boss.shockRing(level, slamPos, 4.5, 9.0F, 1.0, ParticleTypes.EXPLOSION);
                    boss.playSound(SoundEvents.IRON_GOLEM_ATTACK, 1.5F, 0.6F);
                    slamAt = -1;
                    nextSlam = t + 80;
                }
            } else if (t >= nextSlam && d < 12.0) {
                slamPos = target.position();
                slamAt = t + 22;
                boss.playSound(SoundEvents.PISTON_EXTEND, 1.5F, 0.6F);
            }

            if (t >= nextGrab && d > 6.0 && d < 18.0 && boss.hasLineOfSight(target)) { // tentacle grab
                Vec3 to = boss.position().subtract(target.position());
                if (to.lengthSqr() > 1.0E-4) {
                    target.setDeltaMovement(to.normalize().scale(1.1).add(0, 0.3, 0));
                    target.hurtMarked = true;
                }
                Vec3 from = boss.getEyePosition();
                Vec3 end = target.position().add(0, target.getBbHeight() * 0.5, 0);
                int steps = (int) Math.max(4, from.distanceTo(end) * 2);
                for (int i = 0; i <= steps; i++) {
                    Vec3 p = from.lerp(end, i / (double) steps);
                    level.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
                }
                boss.playSound(SoundEvents.CHAIN_BREAK, 1.2F, 0.8F);
                nextGrab = t + 140;
            }
        }
    }
}
