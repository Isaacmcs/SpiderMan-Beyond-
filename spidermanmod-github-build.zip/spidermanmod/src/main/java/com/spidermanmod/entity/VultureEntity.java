package com.spidermanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Vulture: circles overhead, then dive-bombs. After each dive he pulls up in a wing-gust - the moment to hit back. */
public class VultureEntity extends VillainBoss {
    public VultureEntity(EntityType<? extends VultureEntity> type, Level level) {
        super(type, level, BossEvent.BossBarColor.GREEN);
        setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return bossAttributes(200.0, 4.0, 10.0, 0.3);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new DiveGoal(this));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 32.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void die(DamageSource source) {
        setNoGravity(false);
        super.die(source);
    }

    private static class DiveGoal extends Goal {
        private static final int HOVER = 0, DIVE = 1, RECOVER = 2;

        private final VultureEntity boss;
        private int state = HOVER;
        private int timer = 60;
        private double angle;
        private Vec3 diveDir = Vec3.ZERO;

        DiveGoal(VultureEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = boss.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            angle = boss.getRandom().nextDouble() * Math.PI * 2;
            state = HOVER;
            timer = 60;
        }

        @Override
        public void tick() {
            LivingEntity target = boss.getTarget();
            if (target == null) return;
            ServerLevel level = (ServerLevel) boss.level();
            boss.getLookControl().setLookAt(target, 30.0F, 30.0F);

            switch (state) {
                case HOVER -> {
                    angle += 0.07;
                    Vec3 desired = new Vec3(target.getX() + Math.cos(angle) * 10.0, target.getY() + 10.0,
                            target.getZ() + Math.sin(angle) * 10.0);
                    Vec3 push = desired.subtract(boss.position()).scale(0.1);
                    if (push.length() > 0.7) push = push.normalize().scale(0.7);
                    boss.setDeltaMovement(boss.getDeltaMovement().scale(0.5).add(push.scale(0.6)));
                    if (--timer <= 0 && boss.hasLineOfSight(target)) {
                        diveDir = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(boss.position()).normalize();
                        state = DIVE;
                        timer = 30;
                        boss.playSound(SoundEvents.PHANTOM_SWOOP, 2.0F, 0.6F);
                    }
                }
                case DIVE -> {
                    boss.setDeltaMovement(diveDir.scale(1.1));
                    level.sendParticles(ParticleTypes.CLOUD, boss.getX(), boss.getY() + 1, boss.getZ(), 2, 0.2, 0.2, 0.2, 0.01);
                    boolean close = boss.distanceTo(target) < 2.2;
                    if (close || boss.horizontalCollision || boss.verticalCollision || --timer <= 0) {
                        if (close) {
                            target.hurt(boss.damageSources().mobAttack(boss), 10.0F);
                            target.setDeltaMovement(diveDir.x * 1.2, 0.5, diveDir.z * 1.2);
                            target.hurtMarked = true;
                        }
                        boss.shockRing(level, boss.position(), 4.0, 3.0F, 1.2, ParticleTypes.CLOUD);
                        state = RECOVER;
                        timer = 28;
                    }
                }
                case RECOVER -> {
                    boss.setDeltaMovement(boss.getDeltaMovement().scale(0.5).add(0, 0.35, 0));
                    if (--timer <= 0) {
                        state = HOVER;
                        timer = 70 + boss.getRandom().nextInt(40);
                    }
                }
                default -> { }
            }
        }
    }
}
