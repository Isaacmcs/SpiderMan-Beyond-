package com.spidermanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Rhino: heavily armoured bruiser. He telegraphs a charge (rearing + dust), then runs in a straight line.
 * Dodge sideways - if he hits a wall he is stunned and wide open.
 */
public class RhinoEntity extends VillainBoss {
    public RhinoEntity(EntityType<? extends RhinoEntity> type, Level level) {
        super(type, level, BossEvent.BossBarColor.WHITE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return bossAttributes(220.0, 10.0, 10.0, 0.26).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new ChargeGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 24.0F));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    private static class ChargeGoal extends Goal {
        private static final int IDLE = 0, WINDUP = 1, CHARGE = 2, STUNNED = 3;

        private final RhinoEntity rhino;
        private int state = IDLE;
        private int timer;
        private int nextCharge = 80;
        private Vec3 dir = Vec3.ZERO;

        ChargeGoal(RhinoEntity rhino) {
            this.rhino = rhino;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = rhino.getTarget();
            if (t == null || !rhino.onGround() || rhino.tickCount < nextCharge) return false;
            double d = rhino.distanceTo(t);
            return d > 5.0 && d < 28.0;
        }

        @Override
        public boolean canContinueToUse() {
            return state != IDLE && rhino.getTarget() != null;
        }

        @Override
        public void start() {
            state = WINDUP;
            timer = 25;
            rhino.getNavigation().stop();
            rhino.playSound(SoundEvents.RAVAGER_ROAR, 1.5F, 0.7F);
        }

        @Override
        public void tick() {
            LivingEntity target = rhino.getTarget();
            if (target == null) return;
            ServerLevel level = (ServerLevel) rhino.level();

            switch (state) {
                case WINDUP -> {
                    rhino.getNavigation().stop();
                    rhino.getLookControl().setLookAt(target, 60.0F, 60.0F);
                    if (rhino.tickCount % 3 == 0) {
                        level.sendParticles(ParticleTypes.CLOUD, rhino.getX(), rhino.getY() + 0.1, rhino.getZ(), 4, 0.5, 0.05, 0.5, 0.02);
                    }
                    if (--timer <= 0) {
                        Vec3 to = target.position().subtract(rhino.position());
                        dir = new Vec3(to.x, 0, to.z).normalize();
                        state = CHARGE;
                        timer = 30;
                    }
                }
                case CHARGE -> {
                    rhino.setDeltaMovement(dir.x * 0.95, rhino.getDeltaMovement().y, dir.z * 0.95);
                    level.sendParticles(ParticleTypes.CLOUD, rhino.getX(), rhino.getY() + 0.1, rhino.getZ(), 2, 0.3, 0.05, 0.3, 0.02);

                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, rhino.getBoundingBox().inflate(0.6),
                            t -> t != rhino && !(t instanceof Monster) && t.isAlive())) {
                        e.hurt(rhino.damageSources().mobAttack(rhino), 14.0F);
                        e.setDeltaMovement(dir.x * 1.6, 0.5, dir.z * 1.6);
                        e.hurtMarked = true;
                        state = STUNNED;
                        timer = 30;
                        break;
                    }
                    if (state == CHARGE && rhino.horizontalCollision && timer < 28) { // ran into a wall
                        rhino.playSound(SoundEvents.RAVAGER_STUNNED, 1.5F, 0.8F);
                        level.sendParticles(ParticleTypes.EXPLOSION, rhino.getX() + dir.x, rhino.getY() + 1.0, rhino.getZ() + dir.z, 2, 0.2, 0.2, 0.2, 0.0);
                        state = STUNNED;
                        timer = 60; // longer stun: his mistake
                    }
                    if (state == CHARGE && --timer <= 0) {
                        state = IDLE;
                    }
                }
                case STUNNED -> {
                    rhino.getNavigation().stop();
                    rhino.setDeltaMovement(rhino.getDeltaMovement().multiply(0.5, 1.0, 0.5));
                    if (--timer <= 0) state = IDLE;
                }
                default -> { }
            }
        }

        @Override
        public void stop() {
            state = IDLE;
            nextCharge = rhino.tickCount + 100;
        }
    }
}
