package com.spidermanmod.block;

import com.spidermanmod.quest.OriginQuest;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** The sealed glass case in Helix Research Center's vault. Opening it (at night) starts the escape. */
public class SpecimenCaseBlock extends Block {
    public SpecimenCaseBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            OriginQuest.tryOpenCase(sp);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
