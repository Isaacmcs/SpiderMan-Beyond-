#!/bin/sh
cd "$(dirname "$0")"
chmod +x gradlew
./gradlew build && cp build/libs/spidermanmod-0.1.0-beta.jar . && echo "DONE: spidermanmod-0.1.0-beta.jar"
