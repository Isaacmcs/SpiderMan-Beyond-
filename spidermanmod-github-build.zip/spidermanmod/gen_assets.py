import json, os, subprocess, zlib, struct
from PIL import Image, ImageDraw

RES = "src/main/resources"
A = f"{RES}/assets/spidermanmod"
D = f"{RES}/data/spidermanmod"

def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

SUITS = {
    "classic":  dict(p=(0xC8,0x10,0x2E), s=(0x1F,0x3A,0x93), name="Classic"),
    "advanced": dict(p=(0xB7,0x1C,0x1C), s=(0xF2,0xF2,0xF2), name="Advanced"),
    "symbiote": dict(p=(0x0D,0x0D,0x0D), s=(0x2B,0x2B,0x2B), name="Symbiote"),
}
PIECES = {"helmet": "Mask", "chestplate": "Top", "leggings": "Pants", "boots": "Boots"}

# ---------- item models ----------
for n in ["web_shooter", "impact_web", "outpost_radio"]:
    wj(f"{A}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"spidermanmod:item/{n}"}})
wj(f"{A}/models/item/green_goblin_spawn_egg.json", {"parent": "minecraft:item/template_spawn_egg"})
for suit in SUITS:
    for piece in PIECES:
        wj(f"{A}/models/item/{suit}_{piece}.json", {
            "parent": "minecraft:item/generated",
            "textures": {"layer0": f"minecraft:item/leather_{piece}", "layer1": f"minecraft:item/leather_{piece}_overlay"}})

# ---------- lang ----------
lang = {
    "itemGroup.spidermanmod": "Spider-Man: Beyond the Web",
    "item.spidermanmod.web_shooter": "Web Shooter",
    "item.spidermanmod.impact_web": "Impact Web",
    "item.spidermanmod.outpost_radio": "Chinatown Outpost Radio",
    "item.spidermanmod.green_goblin_spawn_egg": "Green Goblin Spawn Egg",
    "entity.spidermanmod.green_goblin": "Green Goblin",
    "entity.spidermanmod.impact_web": "Impact Web",
    "entity.spidermanmod.pumpkin_bomb": "Pumpkin Bomb",
    "key.spidermanmod.upgrades": "Open Upgrades Menu",
    "key.categories.spidermanmod": "Spider-Man: Beyond the Web",
    "gui.spidermanmod.upgrades.title": "HERO UPGRADES",
    "gui.spidermanmod.tokens": "Hero Tokens: %s",
    "gui.spidermanmod.node.point_launch": "Point Launch",
    "gui.spidermanmod.node.point_launch.desc": "Sneak + use the Web Shooter to zip to your target.",
    "gui.spidermanmod.node.air_combo": "Air Combo",
    "gui.spidermanmod.node.air_combo.desc": "Airborne hits deal +50% damage and juggle enemies.",
    "gui.spidermanmod.node.web_capacity": "Web Capacity Lv. %s/%s",
    "gui.spidermanmod.node.web_capacity.desc": "Impact Webs recharge faster.",
    "gui.spidermanmod.unlock": "Unlock (%s)",
    "gui.spidermanmod.upgrade": "Upgrade (%s)",
    "gui.spidermanmod.unlocked": "Unlocked",
    "gui.spidermanmod.maxed": "Maxed",
    "gui.spidermanmod.suit_customizer": "Suit Customizer [WIP]",
    "message.spidermanmod.no_anchor": "No anchor point in range.",
    "message.spidermanmod.point_locked": "Point Launch is not unlocked yet (U to open upgrades).",
    "message.spidermanmod.cannot_buy": "Not enough Hero Tokens, or already owned.",
    "message.spidermanmod.tokens_gained": "+%s Hero Tokens",
    "message.spidermanmod.quest_accepted": "Quest accepted! +%s Hero Tokens.",
    "message.spidermanmod.quest_already": "You've already taken Captain Watanabe's job.",
}
for suit, d in SUITS.items():
    for piece, label in PIECES.items():
        lang[f"item.spidermanmod.{suit}_{piece}"] = f"{d['name']} Suit {label}"
sounds = ["spidey_swing_woohoo","spidey_swing_fast","spidey_swing_joke","spidey_hurt_1","spidey_hurt_2",
          "yuri_intro","yuri_query","yuri_accept","yuri_decline"]
for s in sounds:
    lang[f"subtitles.spidermanmod.{s}"] = s.replace("_", " ").capitalize()
wj(f"{A}/lang/en_us.json", lang)

# ---------- sounds.json + placeholder ogg beeps ----------
snd = {}
freq = {"spidey_swing_woohoo":660,"spidey_swing_fast":740,"spidey_swing_joke":520,"spidey_hurt_1":220,"spidey_hurt_2":196,
        "yuri_intro":330,"yuri_query":350,"yuri_accept":392,"yuri_decline":294}
for s in sounds:
    snd[s] = {"subtitle": f"subtitles.spidermanmod.{s}", "sounds": [{"name": f"spidermanmod:voice/{s}", "stream": False}]}
    out = f"{A}/sounds/voice/{s}.ogg"
    subprocess.run(["ffmpeg","-y","-loglevel","error","-f","lavfi","-i",f"sine=frequency={freq[s]}:duration=0.35",
                    "-af","afade=t=out:st=0.2:d=0.15,volume=0.4","-ac","1","-c:a","libvorbis",out], check=False)
wj(f"{A}/sounds.json", snd)

# ---------- textures ----------
def img(w,h): return Image.new("RGBA",(w,h),(0,0,0,0))

# web shooter 16x16
im = img(16,16); d = ImageDraw.Draw(im)
d.rectangle([2,5,11,11], fill=(70,72,82,255), outline=(30,30,36,255))
d.rectangle([3,8,10,8], fill=(200,30,45,255))
d.rectangle([12,7,14,8], fill=(190,190,200,255))
d.point([(6,6),(7,6)], fill=(235,235,240,255))
d.rectangle([4,12,9,13], fill=(50,50,58,255))
im.save(f"{A}/textures/item/web_shooter.png")

# impact web 16x16
im = img(16,16); d = ImageDraw.Draw(im)
d.ellipse([2,2,13,13], fill=(236,238,244,255), outline=(170,175,190,255))
for line in [(8,2,8,13),(2,8,13,8),(3,3,12,12),(3,12,12,3)]:
    d.line(line, fill=(190,195,210,255))
d.ellipse([5,5,10,10], outline=(190,195,210,255))
im.save(f"{A}/textures/item/impact_web.png")

# outpost radio 16x16
im = img(16,16); d = ImageDraw.Draw(im)
d.rectangle([4,5,11,14], fill=(42,42,52,255), outline=(20,20,26,255))
d.rectangle([5,6,10,8], fill=(70,200,100,255))
d.point([(6,11),(9,11),(6,13),(9,13)], fill=(150,150,160,255))
d.line([(10,1),(10,4)], fill=(170,170,180,255))
d.point([(10,1)], fill=(70,140,255,255))
im.save(f"{A}/textures/item/outpost_radio.png")

# goblin 64x64 (zombie UV layout)
im = img(64,64); d = ImageDraw.Draw(im)
skin=(88,168,74,255); tunic=(88,40,130,255); dark=(48,22,74,255)
d.rectangle([0,0,63,63], fill=skin)
d.rectangle([16,16,39,31], fill=tunic)     # body
d.rectangle([0,16,15,31], fill=dark)       # leg
d.rectangle([16,48,31,63], fill=dark)      # other leg
d.rectangle([40,16,55,31], fill=skin)      # arm
d.rectangle([32,48,47,63], fill=skin)      # other arm
d.rectangle([20,16,27,19], fill=(30,18,50,255))  # belt hint
for x,y in [(9,11),(10,11),(13,11),(14,11)]: d.point((x,y), fill=(255,230,60,255))
d.rectangle([10,14,13,14], fill=(30,60,25,255))
im.save(f"{A}/textures/entity/green_goblin.png")

# armour layers 64x32
for suit, c in SUITS.items():
    p = c["p"]+(255,); s = c["s"]+(255,)
    for layer in (1,2):
        im = Image.new("RGBA",(64,32),p); d = ImageDraw.Draw(im)
        d.rectangle([0,16,15,31], fill=s)      # legs / boots
        d.rectangle([16,16,39,31], fill=p)     # body
        if layer == 1:
            for x,y in [(9,10),(10,10),(9,11),(10,11),(13,10),(14,10),(13,11),(14,11)]:
                d.point((x,y), fill=(255,255,255,255))
            d.rectangle([22,20,25,24], fill=s)  # chest emblem hint
        im.save(f"{A}/textures/models/armor/{suit}_layer_{layer}.png")

# ---------- data: biome / dimension ----------
wj(f"{D}/worldgen/biome/city_district.json", {
    "temperature": 0.8, "downfall": 0.3, "has_precipitation": True,
    "effects": {"sky_color": 7907327, "fog_color": 12638463, "water_color": 4159204, "water_fog_color": 329011},
    "spawners": {k: [] for k in ["monster","creature","ambient","axolotls","underground_water_creature","water_creature","water_ambient","misc"]},
    "spawn_costs": {},
    "carvers": {"air": []},
    "features": [[],[],[],[],["spidermanmod:city_block"],[],[],[],[],[],[]],
})
wj(f"{D}/worldgen/configured_feature/city_block.json", {"type": "spidermanmod:city_block", "config": {}})
wj(f"{D}/worldgen/placed_feature/city_block.json", {"feature": "spidermanmod:city_block", "placement": []})
wj(f"{D}/dimension_type/spiderman_city.json", {
    "ultrawarm": False, "natural": True, "coordinate_scale": 1.0, "has_skylight": True, "has_ceiling": False,
    "ambient_light": 0.0, "piglin_safe": False, "bed_works": True, "respawn_anchor_works": False, "has_raids": False,
    "min_y": -64, "height": 384, "logical_height": 384, "infiniburn": "#minecraft:infiniburn_overworld",
    "effects": "minecraft:overworld",
    "monster_spawn_light_level": {"type": "minecraft:uniform", "value": {"min_inclusive": 0, "max_inclusive": 7}},
    "monster_spawn_block_light_limit": 0,
})
wj(f"{D}/dimension/spiderman_city.json", {
    "type": "spidermanmod:spiderman_city",
    "generator": {"type": "minecraft:flat", "settings": {
        "biome": "spidermanmod:city_district", "features": True, "lakes": False, "structure_overrides": [],
        "layers": [{"block": "minecraft:bedrock", "height": 1}, {"block": "minecraft:stone", "height": 126}]}},
})
print("assets generated")
