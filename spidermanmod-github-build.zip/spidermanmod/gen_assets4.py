"""Run AFTER gen_assets.py, gen_assets2.py and gen_assets3.py.
Update 4: food, villains, abilities, wings, mission board lang + textures."""
import json, os
from PIL import Image, ImageDraw

RES = "src/main/resources"
A = f"{RES}/assets/spidermanmod"

def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

# ---------- lang ----------
lp = f"{A}/lang/en_us.json"
lang = json.load(open(lp))
lang.update({
    "item.spidermanmod.hot_dog": "Hot Dog",
    "item.spidermanmod.pizza_slice": "Pizza Slice",
    "item.spidermanmod.burger": "Burger",
    "item.spidermanmod.energy_bar": "Energy Bar",
    "item.spidermanmod.coffee": "Coffee",
    "entity.spidermanmod.street_thug": "Street Thug",
    "entity.spidermanmod.rhino": "Rhino",
    "entity.spidermanmod.electro": "Electro",
    "entity.spidermanmod.doctor_octopus": "Doctor Octopus",
    "entity.spidermanmod.vulture": "Vulture",
    "entity.spidermanmod.kingpin": "Kingpin",
    "key.spidermanmod.journal": "Mission Board",
    "key.spidermanmod.ability.focus_heal": "Focus Heal",
    "key.spidermanmod.ability.venom_strike": "Venom Strike",
    "key.spidermanmod.ability.camouflage": "Camouflage",
    "key.spidermanmod.ability.concussive_blast": "Concussive Blast",
    "key.spidermanmod.ability.symbiote_surge": "Symbiote Surge",
    "gui.spidermanmod.tab.movement": "Movement",
    "gui.spidermanmod.tab.abilities": "Abilities",
    "gui.spidermanmod.node.web_wings": "Web Wings",
    "gui.spidermanmod.node.web_wings.desc": "Hold Jump in the air to glide.",
    "gui.spidermanmod.node.focus_heal": "Focus Heal",
    "gui.spidermanmod.node.focus_heal.desc": "50 Focus: heal 8 HP. [G]",
    "gui.spidermanmod.node.venom_strike": "Venom Strike",
    "gui.spidermanmod.node.venom_strike.desc": "40 Focus: stunning shock burst. [H]",
    "gui.spidermanmod.node.camouflage": "Camouflage",
    "gui.spidermanmod.node.camouflage.desc": "50 Focus: invisible for 10s. [B]",
    "gui.spidermanmod.node.concussive_blast": "Concussive Blast",
    "gui.spidermanmod.node.concussive_blast.desc": "30 Focus: knockback shockwave. [N]",
    "gui.spidermanmod.node.symbiote_surge": "Symbiote Surge",
    "gui.spidermanmod.node.symbiote_surge.desc": "100 Focus, Symbiote suit. [Y]",
})
json.dump(lang, open(lp, "w"), indent=2)

# ---------- food item models + textures ----------
for n in ["hot_dog", "pizza_slice", "burger", "energy_bar", "coffee"]:
    wj(f"{A}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"spidermanmod:item/{n}"}})

def icon(): return Image.new("RGBA", (16, 16), (0, 0, 0, 0))

im = icon(); d = ImageDraw.Draw(im)              # hot dog
d.rounded_rectangle([1, 5, 14, 11], radius=3, fill=(222, 170, 100, 255), outline=(150, 100, 50, 255))
d.rectangle([2, 7, 13, 9], fill=(190, 60, 50, 255))
for x in range(3, 13, 2): d.point((x, 7 if x % 4 == 3 else 8), fill=(245, 205, 40, 255))
im.save(f"{A}/textures/item/hot_dog.png")

im = icon(); d = ImageDraw.Draw(im)              # pizza slice
d.polygon([(8, 14), (1, 3), (15, 3)], fill=(240, 190, 70, 255), outline=(170, 110, 40, 255))
d.rectangle([1, 2, 15, 3], fill=(200, 140, 60, 255))
for p in [(6, 5), (10, 5), (8, 8), (7, 10)]: d.ellipse([p[0] - 1, p[1] - 1, p[0] + 1, p[1] + 1], fill=(190, 40, 40, 255))
im.save(f"{A}/textures/item/pizza_slice.png")

im = icon(); d = ImageDraw.Draw(im)              # burger
d.rounded_rectangle([2, 3, 13, 6], radius=2, fill=(210, 150, 70, 255), outline=(140, 90, 40, 255))
d.rectangle([2, 7, 13, 7], fill=(90, 190, 70, 255))
d.rectangle([2, 8, 13, 9], fill=(110, 60, 35, 255))
d.rectangle([2, 10, 13, 10], fill=(245, 205, 40, 255))
d.rounded_rectangle([2, 11, 13, 13], radius=1, fill=(210, 150, 70, 255), outline=(140, 90, 40, 255))
im.save(f"{A}/textures/item/burger.png")

im = icon(); d = ImageDraw.Draw(im)              # energy bar
d.rectangle([2, 5, 13, 11], fill=(50, 110, 220, 255), outline=(25, 55, 130, 255))
d.polygon([(8, 6), (6, 9), (8, 9), (7, 11), (10, 8), (8, 8)], fill=(255, 235, 60, 255))
im.save(f"{A}/textures/item/energy_bar.png")

im = icon(); d = ImageDraw.Draw(im)              # coffee
d.polygon([(4, 4), (12, 4), (11, 14), (5, 14)], fill=(240, 240, 240, 255), outline=(150, 150, 150, 255))
d.rectangle([4, 4, 12, 5], fill=(90, 55, 30, 255))
d.rectangle([5, 8, 11, 10], fill=(150, 90, 50, 255))
d.rectangle([3, 3, 13, 3], fill=(235, 235, 235, 255))
im.save(f"{A}/textures/item/coffee.png")

# ---------- villain textures (64x64, zombie-style UV) ----------
def humanoid(name, skin, torso, arms, legs, head_top=None, head_sides=None, eyes=(30, 30, 40), extra=None):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 31, 15], fill=skin + (255,))
    if head_top: d.rectangle([8, 0, 15, 7], fill=head_top + (255,))
    if head_sides:
        d.rectangle([0, 8, 7, 10], fill=head_sides + (255,)); d.rectangle([16, 8, 31, 10], fill=head_sides + (255,))
        d.rectangle([8, 8, 15, 9], fill=head_sides + (255,))
    for x, y in [(9, 11), (10, 11), (13, 11), (14, 11)]: d.point((x, y), fill=eyes + (255,))
    d.rectangle([11, 13, 12, 13], fill=(150, 80, 80, 255))
    d.rectangle([16, 16, 39, 31], fill=torso + (255,))
    d.rectangle([40, 16, 55, 31], fill=arms + (255,))
    d.rectangle([0, 16, 15, 31], fill=legs + (255,))
    if extra: extra(d)
    im.save(f"{A}/textures/entity/{name}.png")

humanoid("street_thug", (226, 178, 140), (60, 60, 68), (60, 60, 68), (50, 70, 120),
         head_top=(60, 60, 68), head_sides=(60, 60, 68), eyes=(20, 20, 20),
         extra=lambda d: d.rectangle([8, 13, 15, 15], fill=(170, 40, 40, 255)))          # hood + red bandana

humanoid("rhino", (150, 150, 158), (95, 95, 108), (80, 80, 92), (65, 65, 78),
         head_top=(205, 205, 212), head_sides=(120, 120, 130), eyes=(220, 40, 40),
         extra=lambda d: (d.rectangle([10, 0, 13, 3], fill=(235, 235, 240, 255)),         # horn
                          d.rectangle([20, 18, 35, 20], fill=(60, 60, 72, 255))))          # chest plate

humanoid("electro", (130, 190, 250), (25, 95, 70), (25, 95, 70), (20, 70, 55),
         head_top=(255, 235, 70), head_sides=(255, 225, 60), eyes=(255, 255, 255),
         extra=lambda d: (d.line([(24, 17), (28, 23), (25, 23), (30, 30)], fill=(255, 235, 60, 255)),
                          d.line([(40, 17), (47, 24), (43, 24), (52, 30)], fill=(255, 235, 60, 255))))

humanoid("doctor_octopus", (225, 190, 150), (112, 82, 52), (112, 82, 52), (45, 40, 40),
         head_top=(95, 60, 35), head_sides=(95, 60, 35), eyes=(20, 20, 20),
         extra=lambda d: (d.rectangle([8, 10, 15, 10], fill=(15, 15, 18, 255)),            # dark glasses
                          d.rectangle([16, 16, 39, 18], fill=(55, 145, 65, 255)),           # green harness
                          d.rectangle([40, 16, 55, 17], fill=(55, 145, 65, 255))))

humanoid("vulture", (190, 205, 170), (60, 140, 72), (50, 120, 62), (40, 90, 50),
         head_top=(70, 150, 80), head_sides=(70, 150, 80), eyes=(255, 210, 40),
         extra=lambda d: d.rectangle([16, 16, 39, 17], fill=(235, 235, 225, 255)))         # feather collar

humanoid("kingpin", (232, 200, 170), (240, 240, 244), (240, 240, 244), (30, 30, 36),
         head_top=(232, 200, 170), eyes=(30, 30, 40),
         extra=lambda d: (d.rectangle([26, 16, 28, 31], fill=(25, 25, 30, 255)),            # black tie / vest line
                          d.rectangle([8, 10, 15, 10], fill=(15, 15, 18, 255))))
print("update-4 assets generated")
