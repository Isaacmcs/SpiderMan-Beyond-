@echo off
title Building Spider-Man mod
echo Building the mod. First run downloads Forge and takes 5-15 minutes. Keep this window open.
call gradlew.bat build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Take a screenshot of the red errors above and send it to Claude.
  pause
  exit /b 1
)
copy /Y build\libs\spidermanmod-0.1.0-beta.jar "%~dp0spidermanmod-0.1.0-beta.jar" >nul
echo.
echo DONE! Your mod is: %~dp0spidermanmod-0.1.0-beta.jar
echo Put that file in your Minecraft 1.20.1 Forge "mods" folder.
pause
