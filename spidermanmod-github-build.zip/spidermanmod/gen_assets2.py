"""Run AFTER gen_assets.py. Adds the update-2 content: weapons, civilians, wall upgrades, recipes."""
import json, os, random
from PIL import Image, ImageDraw

RES = "src/main/resources"
A = f"{RES}/assets/spidermanmod"
D = f"{RES}/data/spidermanmod"

def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

# ---------- lang ----------
lp = f"{A}/lang/en_us.json"
lang = json.load(open(lp))
lang.update({
    "item.spidermanmod.web_bomb": "Web Bomb",
    "item.spidermanmod.electro_gauntlets": "Electro-Web Gauntlets",
    "item.spidermanmod.web_blade": "Web Blade",
    "item.spidermanmod.civilian_spawn_egg": "Civilian Spawn Egg",
    "entity.spidermanmod.civilian": "Civilian",
    "entity.spidermanmod.web_bomb": "Web Bomb",
    "key.spidermanmod.web_pull": "Web Pull (yank target)",
    "gui.spidermanmod.node.point_launch.desc": "Sneak+use shooter: zip to target.",
    "gui.spidermanmod.node.air_combo.desc": "Air hits: +50% damage and juggle.",
    "gui.spidermanmod.node.web_capacity.desc": "Impact Webs recharge faster.",
    "gui.spidermanmod.node.wall_climb": "Wall Climb",
    "gui.spidermanmod.node.wall_climb.desc": "Sprint/jump into walls to cling.",
    "gui.spidermanmod.node.wall_run": "Wall Run",
    "gui.spidermanmod.node.wall_run.desc": "Airborne + sprint along walls.",
    "message.spidermanmod.civilian_say": "<Civilian> %s",
})
lines = ["Be careful out there, it's getting wild!", "Have you seen those thugs on the corner?",
         "I just want to get home safe.", "Is it true there's a goblin on a glider?", "Nice day, if you ignore the explosions."]
heroes = ["Spider-Man! Thank you for everything you do!", "I knew you'd show up. You always do.",
          "My kids think you're the coolest person alive.", "Watch yourself up there, hero.", "Keep swinging - we're counting on you!"]
for i, t in enumerate(lines): lang[f"civilian.spidermanmod.line.{i}"] = t
for i, t in enumerate(heroes): lang[f"civilian.spidermanmod.hero.{i}"] = t
json.dump(lang, open(lp, "w"), indent=2)

# ---------- item models ----------
for n in ["web_bomb", "electro_gauntlets"]:
    wj(f"{A}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"spidermanmod:item/{n}"}})
wj(f"{A}/models/item/web_blade.json", {"parent": "minecraft:item/handheld", "textures": {"layer0": "spidermanmod:item/web_blade"}})
wj(f"{A}/models/item/civilian_spawn_egg.json", {"parent": "minecraft:item/template_spawn_egg"})

# ---------- item textures ----------
def img(): return Image.new("RGBA", (16, 16), (0, 0, 0, 0))

im = img(); d = ImageDraw.Draw(im)   # web bomb
d.ellipse([2, 2, 13, 13], fill=(225, 228, 236, 255), outline=(120, 125, 140, 255))
for line in [(8, 2, 8, 13), (2, 8, 13, 8), (3, 3, 12, 12), (3, 12, 12, 3)]:
    d.line(line, fill=(165, 170, 188, 255))
d.ellipse([6, 6, 9, 9], fill=(210, 35, 50, 255))
d.rectangle([7, 0, 8, 2], fill=(90, 90, 100, 255))
im.save(f"{A}/textures/item/web_bomb.png")

im = img(); d = ImageDraw.Draw(im)   # electro gauntlets
d.rectangle([2, 6, 7, 13], fill=(52, 58, 80, 255), outline=(25, 28, 40, 255))
d.rectangle([9, 6, 14, 13], fill=(52, 58, 80, 255), outline=(25, 28, 40, 255))
d.rectangle([3, 3, 6, 5], fill=(80, 88, 115, 255))
d.rectangle([10, 3, 13, 5], fill=(80, 88, 115, 255))
for pts in [[(4, 8), (5, 10), (4, 10), (5, 12)], [(11, 8), (12, 10), (11, 10), (12, 12)]]:
    d.line(pts, fill=(90, 220, 255, 255))
im.save(f"{A}/textures/item/electro_gauntlets.png")

im = img(); d = ImageDraw.Draw(im)   # web blade (diagonal, handheld)
d.line([(3, 12), (12, 3)], fill=(205, 210, 220, 255), width=2)
d.line([(2, 13), (4, 11)], fill=(120, 80, 45, 255), width=2)
d.line([(5, 10), (8, 13)], fill=(60, 60, 70, 255), width=1)
d.line([(6, 9), (11, 4)], fill=(240, 244, 250, 255), width=1)
im.save(f"{A}/textures/item/web_blade.png")

# ---------- civilian skins (64x64, zombie-style UV layout) ----------
os.makedirs(f"{A}/textures/entity/civilian", exist_ok=True)
SKINS = [(255, 224, 189), (234, 192, 134), (198, 134, 66), (141, 85, 36), (255, 205, 148), (224, 172, 105), (172, 112, 66), (110, 70, 40)]
HAIR = [(40, 28, 20), (90, 55, 25), (200, 160, 70), (25, 25, 30), (150, 60, 30), (120, 120, 125), (60, 40, 30), (20, 20, 20)]
SHIRT = [(200, 60, 60), (60, 120, 200), (70, 170, 90), (230, 190, 60), (150, 80, 180), (240, 240, 240), (60, 60, 70), (230, 120, 60)]
PANTS = [(50, 60, 100), (70, 70, 75), (95, 70, 45), (30, 30, 35), (60, 90, 70), (110, 110, 120), (45, 55, 85), (80, 55, 55)]
for i in range(8):
    random.seed(i)
    skin, hair, shirt, pants = SKINS[i], HAIR[(i * 3) % 8], SHIRT[i], PANTS[(i * 5) % 8]
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 31, 15], fill=skin + (255,))                    # head
    d.rectangle([8, 0, 15, 7], fill=hair + (255,))                     # top of head
    d.rectangle([0, 8, 7, 10], fill=hair + (255,))                     # hair on sides / back
    d.rectangle([16, 8, 31, 10], fill=hair + (255,))
    d.rectangle([8, 8, 15, 9], fill=hair + (255,))                     # fringe
    for x, y in [(9, 11), (10, 11), (13, 11), (14, 11)]: d.point((x, y), fill=(35, 35, 45, 255))
    d.rectangle([11, 13, 12, 13], fill=(170, 90, 90, 255))             # mouth
    d.rectangle([16, 16, 39, 31], fill=shirt + (255,))                 # body
    d.rectangle([40, 16, 55, 31], fill=skin + (255,))                  # arms
    d.rectangle([40, 16, 55, 22], fill=shirt + (255,))                 # sleeves
    d.rectangle([0, 16, 15, 31], fill=pants + (255,))                  # legs
    im.save(f"{A}/textures/entity/civilian/civilian_{i}.png")

# ---------- recipes ----------
def shaped(name, pattern, key, result, count=1, cat="equipment"):
    wj(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shaped", "category": cat, "pattern": pattern,
                                    "key": {k: {"item": v} for k, v in key.items()},
                                    "result": {"item": f"spidermanmod:{result}", "count": count}})
def shapeless(name, ingredients, result, count=1):
    wj(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
                                    "ingredients": [{"item": i} for i in ingredients],
                                    "result": {"item": f"spidermanmod:{result}", "count": count}})

shaped("web_shooter", ["SIS", "IRI", "SPS"],
       {"S": "minecraft:string", "I": "minecraft:iron_ingot", "R": "minecraft:redstone", "P": "minecraft:sticky_piston"}, "web_shooter")
shapeless("impact_web", ["minecraft:string"] * 4 + ["minecraft:slime_ball"], "impact_web")
shapeless("web_bomb", ["minecraft:gunpowder", "minecraft:slime_ball"] + ["minecraft:string"] * 3, "web_bomb", 2)
shaped("electro_gauntlets", ["CRC", "ILI", "I I"],
       {"C": "minecraft:copper_ingot", "R": "minecraft:redstone", "I": "minecraft:iron_ingot", "L": "minecraft:lightning_rod"}, "electro_gauntlets")
shaped("web_blade", ["I", "S", "X"], {"I": "minecraft:iron_ingot", "S": "minecraft:string", "X": "minecraft:stick"}, "web_blade")
shaped("outpost_radio", [" T ", "ICI", "III"],
       {"T": "minecraft:redstone_torch", "I": "minecraft:iron_ingot", "C": "minecraft:note_block"}, "outpost_radio")

wool = {"classic": "minecraft:red_wool", "advanced": "minecraft:white_wool", "symbiote": "minecraft:black_wool"}
shapes = {"helmet": ["XXX", "X X"], "chestplate": ["X X", "XXX", "XXX"], "leggings": ["XXX", "X X", "X X"], "boots": ["X X", "X X"]}
for suit, w in wool.items():
    for piece, pat in shapes.items():
        shaped(f"{suit}_{piece}", pat, {"X": w}, f"{suit}_{piece}")
print("update-2 assets generated")
